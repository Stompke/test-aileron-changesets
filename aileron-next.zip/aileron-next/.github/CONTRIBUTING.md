# Contributing

## Have something to contribute to this repository?

Whether you've identified a bug or created a fix for an existing one, created a new feature/component or have a need for one to be created, or just have a question, please first open an [issue](https://github.com/AAInternal/aileron/issues). We need to make sure we capture all the details and that multiple teams aren't working on the same change at the same time unless they are collaborating.

When creating a new issue consider the following labels that you can assign to the issue:

| Label | Description |
| ---- | ----------- |
| a11y | An accessibility issue or recommendation |
| bug | Something isn't working |
| documentation | Something is wrong or missing in the docs |
| feature | New feature or component needed |
| question | Additional information is needed |

> Note: you can apply more than one label to an issue if it is appropriate (example: `a11y` and `bug`).

## Code of Conduct

Please note we have a [code of conduct](https://github.com/AAInternal/aileron/blob/main/.github/CODE_OF_CONDUCT.md), follow it in all your interactions with the project.

## Getting started

If this is your first time using an internal package using [packages.aa.com](https://packages.aa.com),
please take a moment to read through the [Get Started](https://aileron.aa.com/developing/get-started)
guide before continuing.

## Create a branch<sup>*</sup>

If you have access to the ACL repo you can create a new branch for your work.  If not, then you can fork the repo and work that way.

To help with communicating what type of updates are being made, consider a branch naming convention that helps with that.  For example:

- Fixing a bug/defect?
  - *branch name:  bug/foo-bar*
- Adding a new feature/component?
  - *branch name:  feature/foo-bar*
- Just experimenting and want to collaborate?
  - *branch name:  goof/foo-bar*
- Taking care of some housekeeping items?
  - *branch name:  chore/foo-bar*

> <sup>*</sup> This is for contributers and members of the repository, if you are not a direct contributor or a member of the repository, please follow the section below for forking.

## Forking

As a person wanting to contribute to this project, we want to fork the repository and then make a pull request to the main repository when ready to merge.

### Setup

1. Click on **fork** at the top-right of the page.

2. Navigate to your fork, `https://github.com/<your-user-name>/aileron/`.

3. Click `Clone or Download` under the repository name.

4. Click the **Use HTTPS**, then click the *clippy* icon to copy the clone git url to your clipboard.

5. Open your terminal (eg. Terminal, iTerm2, Hyper...).

6. Type in **git clone** and then paste in the clone git url that you copied earlier. This will look like:

```sh
git clone https://github.com/<your-user-name>/aileron.git
```

7. Press **enter** and your local clone will be created.

```sh
$ git clone https://github.com/<your-user-name>/aileron.git
> Cloning into `aileron`...
> remote: Counting objects: 10, done.
> remote: Compressing objects: 100% (8/8), done.
> remove: Total 10 (delta 1), reused 10 (delta 1)
> Unpacking objects: 100% (10/10), done.
```

### Keeping in sync

Once you have cloned the repository from your *user-name* you will want to make sure that you can continue to get updates from the main repository.

1. Navigate to the [aileron](https://github.com/AAInternal/aileron) repository on GHE.

2. Click `Clone or Download` under the repository name.

3. Click the **Use SSH**, then click the *clippy* icon to copy the clone git url to your clipboard.

4. Open your terminal (eg. Terminal, iTerm2, Hyper...).

5. Change directories to the location of the fork that you **cloned in step 6 of setup**

```sh
cd
ls
cd path/to/local/clone/fork
```

6. Type in **git remote -v** and press **enter**. This will display your local cloned fork remote.

```sh
$ git remote -v
> origin  https://github.com/<your-user-name>/aileron.git (fetch)
> origin  https://github.com/<your-user-name>/aileron.git (push)
```

7. Type **git remote add upstream** and paste the url you copied in step 3 and press **enter**. It should looks something like:

```sh
git remote add upstream https://github.com/AAInternal/aileron.git
```

8. Type in **git remote -v** and press **enter**. This should have changed from earlier to:

```sh
$ git remote -v
> origin  https://github.com/<your-user-name>/aileron.git (fetch)
> origin  https://github.com/<your-user-name>/aileron.git (push)
> upstream  https://github.com/AAInternal/aileron.git (fetch)
> upstream  https://github.com/AAInternal/aileron.git (push)
```

9. (*Optional*) Since you are unable to push to *upstream*, to prevent accidentally doing this, you can set upstream push to something nonexistent. Type in **git remote --push set-url upstream no_push** and press **enter** to update the url for upstream push. To check the results type in **git remote -v** and press **enter**.

```sh
$ git remote -v
> origin  https://github.com/<your-user-name>/aileron.git (fetch)
> origin  https://github.com/<your-user-name>/aileron.git (push)
> upstream  https://github.com/AAInternal/aileron.git (fetch)
> upstream  no_push (push)
```

With this done, you will have two remote urls set to pull or push updates. To update your master branch on your fork, follow the steps provided:

```sh
# With a clean branch...
$ git checkout master
$ git rebase upstream/main
$ git push master
```

## What all components should have

Each component contributed should provide:

- Tests covering all functionality in `<component>.test.ts`
- Component Stories in `<component>.stories.ts`
- Interactive tests written within   `<component>.stories.ts` with `.play` function.
- Component Documentation in `README.md` of component

## Setting up local development workflow

- Pull down the appropriate repositories:

  ```sh
  git clone git@github.com/AAInternal/aileron.git
  ```

- After its completed cloning the repository, navigate into the directory

  ```sh
  cd aileron
  ```

- Install dependencies

  ```sh
  npm i
  ```

- Serve the app

  ```sh
  npm run build
  ```

  ```sh
  npm run storybook
  ```

Whenever you are developing/editing a component, you should run both of these commands `npm run build` and `npm run storybook`, in that order, to see the changes on your local storybook.

## Developing New Components

When you are developing a NEW component use the generate function to set up your files properly.

```sh
npm run generate <component-name>
```

## Pull Request Process

1. Ensure any install or build dependencies are removed before the end of the layer when doing a build.

2. See to it that you've a `component.spec.ts` file in your folder and have done the required testing on your component, 100% coverage is what we aim for but an exception can be made if a branch or two don't need to be tested.

3. Make sure that you have generated documentation for your component or service by running a build, and then adding any necessary parts surrounding it that weren't included.

4. Creating a Pull Request

- Make sure your PR title follows the conventional commit design <https://www.conventionalcommits.org/en/v1.0.0/>
- Create your PR to be merged into alpha
- At least 1 dev needs to approve before merge
- You may merge the Pull Request into alpha once you have the sign-off of another developer, or if you do not have permission to do that, you may request the reviewer to merge it for you.

## About Jest Test Cases

Every component should include a **{{your-component}}.component.spec.ts** file. We want to make sure that this component has a 100% coverage when you test it out with `npm test -- --coverage`. Please make sure you've resolved all the uncovered lines in your component. A component which is not tested correctly will not be merged in the repo.

## Our Responsibilities

Project maintainers are responsible for clarifying the standards of acceptable behavior and are expected to take appropriate and fair corrective action in response to any instances of unacceptable behavior.

Project maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct.

## Releases
Each Pull Request merge into `alpha`, `beta` and `release` all trigger the following:
- git tag version change (ex: 1.0.5-alpha.3 to 1.0.5-beta.0 )
- Automatic PR creation for the next release step (ex: PR to merge `beta` into `release`)
- Testing. Which differs between branches and stages of release.

Each Pull Request merge into `alpha`, `beta` and `release` all trigger the following:

- git tag version change (ex: 1.0.5-alpha.3 to 1.0.5-beta.0 )
- Automatic PR creation for the next release step (ex: PR to merge `beta` into `release`)
- Testing. Which differs between branches and stages of release.

Each Pull Request merge into `alpha`, `beta` and `release` all trigger the following:

- git tag version change (ex: 1.0.5-alpha.3 to 1.0.5-beta.0 )
- Automatic PR creation for the next release step (ex: PR to merge `beta` into `release`)
- Testing. Which differs between branches and stages of release.

Each Pull Request merge into `alpha`, `beta` and `release` all trigger the following:

- git tag version change (ex: 1.0.5-alpha.3 to 1.0.5-beta.0 )
- Automatic PR creation for the next release step (ex: PR to merge `beta` into `release`)
- Testing. Which differs between branches and stages of release.

The following the the steps for release:

- `alpha` into `beta`
- `beta` into `release`
- `release` into `main`

`main` Is the main production branch which is released automatically every 1st day of the month.

`main` contains the main production code and is triggered to release automatically every 1st of the month, or whenever manually triggered. This also creates a PR to merge `main` back into `alpha` to keep the `alpha` branch up to date.

## **Want to follow Aileron release notifications?**

Follow these slack channels:

- [#aileron-design-system](https://app.slack.com/client/T03QR2PHH/CDBGQU6AU):  For Full releases
- [#aileron-releases](https://app.slack.com/client/T03QR2PHH/C03PXF519R9): For commits made to `alpha`

Follow these slack channels:

- [#aileron-design-system](https://app.slack.com/client/T03QR2PHH/CDBGQU6AU):  For Full releases
- [#aileron-releases](https://app.slack.com/client/T03QR2PHH/C03PXF519R9): For commits made to `alpha`

Follow these slack channels:

- [#aileron-design-system](https://app.slack.com/client/T03QR2PHH/CDBGQU6AU):  For Full releases
- [#aileron-releases](https://app.slack.com/client/T03QR2PHH/C03PXF519R9): For commits made to `alpha`
