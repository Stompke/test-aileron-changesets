# Code of Conduct

## Our Pledge

In the interest of fostering an open and welcoming environment, we as
contributors and maintainers pledge to making participation in our project and
our community a productive experience for everyone. The Aileron Components Community is dedicated to providing a harassment-free working environment for all, regardless of gender, sexual orientation, disability, physical appearance, body size, race, or religion. We do not tolerate harassment of any form. All communication should be appropriate for a professional audience including people of many different backgrounds.

## Our Standards

These are the values to which people in the Aileron Component Library community should aspire:

- Be friendly and welcoming
- Be patient
- Be thoughtful (Productive communication requires effort. Think about how your words will be interpreted.
Remember that sometimes it is best to refrain entirely from commenting.)
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Be charitable (Interpret the arguments of others in good faith, do not seek to disagree.
When we do disagree, try to understand why.)
- Creating agnostic components which come of use to other teams as well
- Please test your components thoroughly. Before a component can be reusable it first has to be usable
- Comments go a long way
- Easy to understand, clean & neat piece of code.


## Reporting An Incident

Incidents that violate the Code of Conduct are damaging to the Aileron Component Library community, and they will not be tolerated. The silver lining is that, in many cases, these incidents present a chance for the offenders, and the teams at large, to grow, learn, and become better. You can report the incident inside issues with the title "Reporting An Incident".
