---
"@aileron/content-switcher": patch
---

fix(content-switch): added parts for all html elements
