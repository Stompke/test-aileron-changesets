---
"@aileron/tailwind": patch
---

docs(icons): added icons page along with examples
