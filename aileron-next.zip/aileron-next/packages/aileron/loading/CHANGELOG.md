# @aileron/loading

## 1.5.10-next.0

### Patch Changes

- d41e2d29: version bump
- Updated dependencies [d41e2d29]
  - @aileron/icon@2.0.1-next.0

## 1.5.9

### Patch Changes

- Updated dependencies [60066416]
  - @aileron/icon@2.0.0
