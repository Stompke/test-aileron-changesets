import { Loading } from './loading';
import { InlineLoading } from './inline-loading.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-loading': Loading;
    'adc-inline-loading': InlineLoading;
  }
}
