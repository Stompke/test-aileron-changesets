import type { Loading } from './loading';
import './loading';

describe('<adc-loading>', () => {
  let loading: Loading;
  beforeEach(() => {
    document.body.innerHTML = `
    <div style="display: flex; flex-direction: column; align-items: center;">
      <img role="img" alt="background" src="https://placeimg.com/1000/768/nature" />
      <adc-loading></adc-loading>
    </div>
    `;
    loading = document.querySelector('adc-loading') as Loading;
  });

  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(loading?.nodeType).toBe(1);
    });
    it('should have correct default values', () => {
      expect(loading?.assistiveText).toBe('Loading');
      expect(loading?.labelText).toBe('');
      expect(loading?.state).toBe('');
    });
    it('should focus with the firstUpdate', () => {
      expect(document.activeElement === loading).toBe(true);
    });
    it('should not render adc-icon without state', () => {
      const activeIcon = loading?.shadowRoot?.querySelector('adc-icon');
      expect(activeIcon).toBeNull();
    });
  });
  describe('when properties has been settled', () => {
    it('should display the labelText', async () => {
      loading.labelText = 'Loading...';
      await loading.updateComplete;

      expect(loading.textNode.textContent).toBe(loading.labelText);
    });
    it('should render active icon', async () => {
      loading.state = 'active';
      await loading.updateComplete;
      const activeIcon = loading?.shadowRoot?.querySelector(
        'adc-icon[icon="action:loader"]'
      );
      expect(activeIcon).not.toBeNull();
    });
    it('should render success icon', async () => {
      loading.state = 'success';
      await loading.updateComplete;
      const activeIcon = loading?.shadowRoot?.querySelector(
        'adc-icon[icon="signal:checkmark"]'
      );
      expect(activeIcon).not.toBeNull();
    });
    it('should render error icon', async () => {
      loading.state = 'error';
      await loading.updateComplete;
      const activeIcon = loading?.shadowRoot?.querySelector(
        'adc-icon[icon="signal:error"]'
      );
      expect(activeIcon).not.toBeNull();
    });
    it('should change hasFocus property to true after focus', async () => {
      const dispatchEventStub = vi.fn();

      loading.dispatchEvent = dispatchEventStub;
      const spanElement = loading?.shadowRoot?.querySelector(
        '#loadingLabel'
      ) as HTMLElement;
      spanElement?.focus();
      await loading.updateComplete;
      expect(loading.hasFocus).toBe(true);
    });

    it('should change hasFocus property to false after blur', async () => {
      const dispatchEventStub = vi.fn();

      loading.dispatchEvent = dispatchEventStub;

      const spanElement = loading?.shadowRoot?.querySelector(
        '#loadingLabel'
      ) as HTMLElement;
      spanElement?.focus();
      spanElement?.blur();

      await loading?.updateComplete;

      expect(loading.hasFocus).toBe(false);
    });
  });
});
