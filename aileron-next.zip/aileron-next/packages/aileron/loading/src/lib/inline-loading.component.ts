import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { emit } from '@aileron/shared/event';
import { FocusMixin } from '@aileron/shared/focus';
import { HostListenerMixin } from '@aileron/shared/host-listener';
import { html } from 'lit';
import { property, query, state } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Spinner indicating loading state.
 * @element adc-inline-loading
 * @summary The inline loading spinner is used to indicate loading state that is non-blocking.
 * @attr {"active"|"success"|"error"|""} [state=''] - Current state of the inline loading spinner.
 */
export class InlineLoading extends HostListenerMixin(
  FocusMixin(AileronElement)
) {
  static styles = [AileronElement.styles || [], styles];
  @state() protected hasFocus = false;

  @query('#inlineLoadingLabel') textNode!: HTMLButtonElement;

  /**
   * The assistive text for the spinner icon.
   * @ignore
   */
  @property({ attribute: 'assistive-text' }) assistiveText = 'Loading';

  @property() state = '';

  /**
   * Optional label/message for the loader.
   */
  @property({ attribute: 'label-text' }) labelText = '';

  focus(options?: FocusOptions): void {
    this.textNode.focus(options);
  }

  blur(): void {
    this.blur();
  }

  handleBlur(): void {
    this.hasFocus = false;

    emit(this, 'adc-blur');
  }

  handleFocus(): void {
    this.hasFocus = true;

    emit(this, 'adc-focus');
  }

  firstUpdated(): void {
    this.focus();
  }

  protected renderLoadingIcon(): TemplateResult {
    if (this.state === 'active') {
      return html`
        <div class="inline-flex mr-4">
          <adc-icon icon="action:loader"></adc-icon>
        </div>
      `;
    } else if (this.state === 'success') {
      return html`
        <div class="inline-flex mr-4">
          <div class="inline-flex text-green-070">
            <adc-icon icon="signal:checkmark" outlined></adc-icon>
          </div>
        </div>
      `;
    } else if (this.state === 'error') {
      return html`
        <div class="inline-flex mr-4">
          <div class="inline-flex text-red-070">
            <adc-icon icon="signal:error" outlined></adc-icon>
          </div>
        </div>
      `;
    }
    return html``;
  }

  render(): TemplateResult {
    return html`
      ${this.renderLoadingIcon()}
      <span
        id="inlineLoadingLabel"
        class="font-sans font-regular text-sm line-height-4 items-center text-neutral-000 inline-flex m-0 relative align-middle whitespace-nowrap focus:outline-blue-070 focus:outline focus:outline-1"
        tabindex="-1"
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
        >${this.labelText}</span
      >
    `;
  }
}

try {
  customElements.define('adc-inline-loading', InlineLoading);
} catch (error) {
  // do nothing
}
