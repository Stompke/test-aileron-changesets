import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { emit } from '@aileron/shared/event';
import { FocusMixin } from '@aileron/shared/focus';
import { HostListenerMixin } from '@aileron/shared/host-listener';
import { html } from 'lit';
import { property, query, state } from 'lit/decorators.js';
import logo from './assets/logo-flight-symbol';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * @ignore
 */
export const LOADING_STATE = {
  ACTIVE: 'active',
  SUCCESS: 'success',
  ERROR: 'error',
  NONE: '',
} as const;

type LoadingState = (typeof LOADING_STATE)[keyof typeof LOADING_STATE];

/**
 * Spinner indicating loading state.
 * @element adc-loading
 * @summary The loading spinner is used to indicate loading state that is page or module blocking.
 * @attr {"active"|"success"|"error"|""} [state=''] - Current state of the loading spinner.
 * @attr {string} [label-text=''] - Optional label/message for the loader.
 */
export class Loading extends HostListenerMixin(FocusMixin(AileronElement)) {
  static styles = [AileronElement.styles || [], styles];
  @state() protected hasFocus = false;
  @query('#loadingLabel') textNode!: HTMLButtonElement;
  /**
   * The assistive text for the spinner icon.
   * @ignore
   */
  @property({ attribute: 'assistive-text' }) assistiveText = 'Loading';

  @property() state: LoadingState = '';

  @property({ attribute: 'label-text' }) labelText = '';

  focus(options?: FocusOptions): void {
    this.textNode.focus(options);
  }

  blur(): void {
    this.blur();
  }

  handleBlur(): void {
    this.hasFocus = false;

    emit(this, 'adc-blur');
  }

  handleFocus(): void {
    this.hasFocus = true;

    emit(this, 'adc-focus');
  }

  firstUpdated(): void {
    this.focus();

    if (this.parentElement) {
      this.parentElement.style.position = 'relative';
    }
  }

  renderLoadingIcon(): TemplateResult {
    if (this.state === 'active') {
      return html` <adc-icon icon="action:loader" size="32"></adc-icon> `;
    } else if (this.state === 'success') {
      return html`
        <div class="inline-flex text-green-070">
          <adc-icon icon="signal:checkmark" outlined size="32"></adc-icon>
        </div>
      `;
    } else if (this.state === 'error') {
      return html`
        <div class="inline-flex text-red-070">
          <adc-icon icon="signal:error" outlined size="32"></adc-icon>
        </div>
      `;
    }
    return html``;
  }

  renderLoadingLogo(): TemplateResult {
    return logo;
  }

  render(): TemplateResult {
    return html`
      <div class="items-center text-center">
        <div class="flex justify-center">${this.renderLoadingLogo()}</div>
        <span
          id="loadingLabel"
          class="font-sans font-regular text-base line-height-6 items-center text-neutral-000 inline-flex relative align-middle whitespace-nowrap m-16 focus:outline-blue-070 focus:outline focus:outline-1"
          tabindex="-1"
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          >${this.labelText}</span
        >
        <div class="mb-16">${this.renderLoadingIcon()}</div>
      </div>
    `;
  }
}

try {
  customElements.define('adc-loading', Loading);
} catch (e) {
  // do nothing
}
