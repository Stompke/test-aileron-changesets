# @aileron/carousel

## 1.5.10-next.0

### Patch Changes

- d41e2d29: version bump

## 1.5.9

### Patch Changes

- 6ddd465c: fix: update the styles of multiple components
- cedc7699: fix: update all components for eslint
