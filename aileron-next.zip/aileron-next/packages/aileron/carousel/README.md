# @aileron/carousel

### For documentation, please visit our [Carousel documentation page](https://animated-doodle-g3kyvlm.pages.github.io/components/carousel/).

