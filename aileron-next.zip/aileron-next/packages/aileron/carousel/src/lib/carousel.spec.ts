import './carousel';
import type { Carousel } from './carousel';

describe('<adc-carousel>', () => {
  let carousel: Carousel;
  beforeEach(() => {
    document.body.innerHTML = `
    <h1>Custom element test</h1>
    <adc-carousel>      
      <adc-card>
        <h2>Card 1 Heading</h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
          ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
          sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
          est laborum.
        </p>
      </adc-card>
      <adc-card>
        <h2>Card 2 Heading</h2>
        <p>
          Lorem repellat iste porro quidem tempore cupiditate et. Et incidunt eum quidem laboriosam
          unde dolor sunt harum non. Quas animi eos.
        </p>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
          ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
          ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
          sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
          est laborum.
        </p>
      </adc-card>
      <adc-card>
        <h2>Card 3 Heading</h2>
        <p>
          Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat
          nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
          deserunt mollit anim id est laborum.
        </p>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
          ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate
          velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        </p>
      </adc-card>
      <adc-card>
        <h2>Card 4 Heading</h2>
        <p>
          Soluta eius perspiciatis culpa occaecati necessitatibus laudantium sunt. Ut non qui.
          Excepturi exercitationem qui. Pariatur enim at ut dolor quis odio ducimus et.
        </p>
        <p>
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
          dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </p>
      </adc-card>
    </adc-carousel>`;
    carousel = document.querySelector('adc-carousel') as Carousel;
  });

  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(carousel?.nodeType).toBe(1);
    });

    it('should have correct default values', () => {
      expect(carousel?.isPlayable).toBe(false);
      expect(carousel?.isPlaying).toBe(false);
      expect(carousel?.start).toBe(0);
      expect(carousel?.slideDelay).toBe(2000);
      expect(carousel?.pageSize).toBe(1);
    });
  });

  describe('when properties has been settled', () => {
    it('should render play button when isPlayable is true and isPlaying is false', async () => {
      carousel.isPlayable = true;
      carousel.isPlaying = false;
      await carousel?.updateComplete;
      const playButton = carousel?.shadowRoot?.querySelector(
        'adc-icon[icon="small:play"]'
      );

      expect(playButton).not.toBeNull();
    });

    it('should render pause button when isPlayable is true and isPlaying is true', async () => {
      carousel.isPlayable = true;
      carousel.isPlaying = true;
      await carousel?.updateComplete;
      const pauseButton = carousel?.shadowRoot?.querySelector(
        'adc-icon[icon="small:pause"]'
      );

      expect(pauseButton).not.toBeNull();
    });

    it('should return correct naviagation status', async () => {
      carousel.start = 1;
      carousel.pageSize = 2;
      await carousel?.updateComplete;
      const navigationElement = carousel?.shadowRoot?.querySelector(
        '.bx--carousel__navigation'
      );

      await carousel?.updateComplete;
      expect(navigationElement?.textContent?.trim()).toBe('2 / 3');
    });
  });

  describe('methods', () => {
    it('should back when click prev button', async () => {
      const button = carousel?.shadowRoot?.querySelector(
        '#nextButton'
      ) as HTMLButtonElement;
      button?.click();
      await carousel?.updateComplete;
      expect(carousel?.start).toBe(1);
    });
    it('should move forward when click next button', async () => {
      const button = carousel?.shadowRoot?.querySelector(
        '#prevButton'
      ) as HTMLButtonElement;
      carousel.start = 1;
      carousel.pageSize = 2;
      await carousel?.updateComplete;
      button?.click();
      await carousel?.updateComplete;
      expect(carousel?.start).toBe(0);
    });

    it('should move forward the Carousel when click play button', async () => {
      carousel.isPlayable = true;
      carousel.requestUpdate();
      carousel.isPlaying = false;
      await carousel?.updateComplete;
      const playButton = carousel?.shadowRoot?.querySelector(
        '#playbackToogle'
      ) as HTMLButtonElement;
      playButton?.click();
      await carousel?.updateComplete;
      expect(carousel?.isPlaying).toBe(true);
      expect(carousel?.playCarousel).not.toBeNull();
    });

    it('should stop the Carousel when click pause button', async () => {
      carousel.isPlaying = true;
      carousel.isPlayable = true;
      carousel.requestUpdate();
      await carousel?.updateComplete;
      const playButton = carousel?.shadowRoot?.querySelector(
        '#playbackToogle'
      ) as HTMLButtonElement;
      playButton?.click();
      await carousel?.updateComplete;
      expect(carousel?.isPlaying).toBe(false);
      expect(carousel?.playCarousel).toBeNull();
    });
  });
});
