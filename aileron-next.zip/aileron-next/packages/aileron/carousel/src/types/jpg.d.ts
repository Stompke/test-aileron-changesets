declare module '*.jpg';
