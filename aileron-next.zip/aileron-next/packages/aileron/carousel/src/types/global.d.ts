import { Carousel } from './carousel';

declare global {
  interface HTMLElementTagNameMap {
    'adc-carousel': Carousel;
  }
}
