# @aileron/number-input

### For Number Input documentation, please visit our link to all component documention at:
* [Number-Input](https://animated-doodle-g3kyvlm.pages.github.io/components/number-input/)
