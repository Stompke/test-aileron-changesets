import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { ValidityMixin } from '@aileron/shared/validity';
import { html } from 'lit';
import { property, query } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * @ignore
 */
export const NUMBER_INPUT_VALIDATION_STATUS = {
  EXCEEDED_MAXIMUM: 'exceeded_maximum',
  EXCEEDED_MINIMUM: 'exceeded_minimum',
} as const;

type NumberInputValidationStatus =
  (typeof NUMBER_INPUT_VALIDATION_STATUS)[keyof typeof NUMBER_INPUT_VALIDATION_STATUS];

/**
 * Number input.
 * @element adc-number-input
 * @summary Number input is a group of controls that allows the user to increment or decrement
 * a number that is managed by an input.
 * @fires {CustomEvent<{ value: number; }>} adc-number-input-input-value - Event fired when the
 * input value changes.
 * @slot validity-message - The validity message. If present and non-empty, this
 * input shows the UI of its invalid state.
 * @slot required-validity-message - The validity message when input is
 * required.
 * @slot validity-message-min - The validity message when value input is lower
 * than minimum value expected.
 * @slot validity-message-max - The validity message when value input is greater
 * than maximum value expected.
 * @attr {string} [min=''] The minimum value allowed in the input
 * @attr {string} [max=''] The maximum value allowed in the input
 * @attr {string} [step='1'] The step value to increment or decrement the input
 * @attr {string} [value=''] The value of the input
 */
export class NumberInput extends ValidityMixin(AileronElement) {
  static styles = [AileronElement.styles || [], styles];
  /**
   * The underlying input element
   */
  @query('input') _input!: HTMLInputElement;

  /**
   * Handles `input` event on the `<input>` in the shadow DOM.
   */
  _handleInput({ target }: Event): void {
    this.value = (target as HTMLInputElement).value;
  }

  /**
   * When not disabled, append name and value to formData event object.
   */
  handleFormdata(event: Event): void {
    const { formData } = event as any;
    const { disabled, name, value } = this;

    if (!disabled && name) {
      formData.append(name, value);
    }
  }

  /**
   * Handles `click` event on the up button in the shadow DOM.
   */
  _handleUserInitiatedStepUp(): void {
    const { _input: input } = this;
    this.stepUp();

    /**
     * @ignore
     */
    this.dispatchEvent(
      new CustomEvent((this.constructor as typeof NumberInput).eventInput, {
        bubbles: true,
        composed: true,
        cancelable: false,
        detail: {
          value: input.value,
        },
      })
    );
  }

  /**
   * Handles `click` event on the down button in the shadow DOM.
   */
  _handleUserInitiatedStepDown(): void {
    const { _input: input } = this;
    this.stepDown();

    /**
     * @ignore
     */
    this.dispatchEvent(
      new CustomEvent((this.constructor as typeof NumberInput).eventInput, {
        bubbles: true,
        composed: true,
        cancelable: false,
        detail: {
          value: input.value,
        },
      })
    );
  }

  _testValidity(): string {
    if (this._input?.valueAsNumber > parseFloat(this.max)) {
      return NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM;
    }
    if (this._input?.valueAsNumber < parseFloat(this.min)) {
      return NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM;
    }

    return super.testValidity();
  }

  @property({ reflect: true })
  get min(): string {
    return this._min.toString();
  }

  set min(value: string) {
    const oldValue = this.min;
    this._min = value;
    this.requestUpdate('min', oldValue);
  }

  @property({ reflect: true })
  get step(): string {
    return this._step.toString();
  }

  set step(value: string) {
    const oldValue = this.step;
    this._step = value;
    this.requestUpdate('step', oldValue);
  }

  @property({ reflect: true })
  get max(): string {
    return this._max.toString();
  }

  set max(value: string) {
    const oldValue = this.max;
    this._max = value;

    this.requestUpdate('max', oldValue);
  }

  /**
   * Handles incrementing the value in the input
   */
  stepUp(): void {
    this._input.stepUp();
    const oldValue = this._value;
    this._value = this.value;

    this.requestUpdate('value', oldValue);
  }

  /**
   * Handles decrementing the value in the input
   */
  stepDown(): void {
    this._input.stepDown();
    const oldValue = this._value;
    this._value = this.value;

    this.requestUpdate('value', oldValue);
  }

  /**
   * May be any of the standard HTML autocomplete options
   */
  @property() autocomplete: any = '';

  /**
   * Name for the input in the `FormData`
   */
  @property() name = '';

  /**
   * Pattern to validate the input against for HTML validity checking
   */
  @property() pattern = '^[0-9]*$';

  /**
   * Value to display when the input has an empty `value`
   */
  @property({ reflect: true }) placeholder = '';

  /**
   * Sets the input to be focussed automatically on page load. Defaults to false
   */
  @property({ type: Boolean }) autofocus = false;

  /**
   * Controls the disabled state of the input
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * Boolean property to set the required status
   */
  @property({ type: Boolean, reflect: true }) required = false;

  /**
   * Controls the invalid state and visibility of the `validityMessage`
   */
  @property({ type: Boolean, reflect: true }) invalid = false;

  protected _value = '';
  protected _min = '';
  protected _max = '';
  protected _step = '1';

  /**
   * Aria text for the button that increments the value
   */
  @property({ attribute: 'increment-button-assistive-text' })
  incrementButtonAssistiveText = 'increase number input';

  /**
   * Aria text for the button that decrements the value
   */
  @property({ attribute: 'decrement-button-assistive-text' })
  decrementButtonAssistiveText = 'decrease number input';

  /**
   * The validity message shown when input is required
   *
   * Also available via the `required-validity-message` slot
   */
  @property({ attribute: 'required-validity-message' })
  requiredValidityMessage = 'Please fill out this field';

  /**
   * The validity message shown when input is invalid
   *
   * Also available via the `validity-message` slot
   */
  @property({ attribute: 'validity-message' }) validityMessage = '';

  /**
   * The validity message shown when the value is greater than the maximum
   *
   * Also available via the `validity-message-max` slot
   */
  @property({ attribute: 'validity-message-max' }) validityMessageMax = '';

  /**
   * The validity message shown when the value is less than the minimum
   *
   * Also available via the `validity-message-min` slot
   */
  @property({ attribute: 'validity-message-min' }) validityMessageMin = '';

  @property({ reflect: true })
  get value(): string {
    if (this._input) {
      return this._input.value;
    }

    return this._value;
  }

  set value(value: string) {
    const oldValue = this._value;
    this._value = value;

    this.requestUpdate('value', oldValue);

    if (this._input) {
      this._input.value = value;
    }
  }

  protected renderIncrementButton(): TemplateResult {
    const { _handleUserInitiatedStepUp: handleUserInitiatedStepUp } = this;
    const validity = this._testValidity();

    return html`
      <button
        class="adc-number-input__control rounded border border-solid border-blue-060 text-blue-060 min-w-[48px] max-w-[48px] min-h-[48px] max-h-[48px]${classMap(
          {
            'border-neutral-090':
              this.disabled ||
              validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
            'text-neutral-090':
              this.disabled ||
              validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
            'bg-transparent':
              validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
            'hover:bg-neutral-130':
              validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
            'hover:cursor-pointer':
              validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
            'focus:bg-neutral-130':
              validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
          }
        )}"
        aria-label="${this.incrementButtonAssistiveText}"
        aria-live="polite"
        aria-atomic="true"
        type="button"
        ?disabled=${this.disabled}
        @click=${handleUserInitiatedStepUp}
        id="incrementButton"
      >
        <adc-icon icon="action:plus"></adc-icon>
      </button>
    `;
  }

  renderDecrementButton(): TemplateResult {
    const { _handleUserInitiatedStepDown: handleUserInitiatedStepDown } = this;
    const validity = this._testValidity();
    return html`
      <button
        class="adc-number-input__control rounded border border-solid border-blue-060 text-blue-060 min-w-[48px] max-w-[48px] min-h-[48px] max-h-[48px]  ${classMap(
          {
            'border-neutral-090':
              this.disabled ||
              validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM,
            'text-neutral-090':
              this.disabled ||
              validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM,
            'bg-transparent':
              validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM,
            'hover:bg-neutral-130':
              validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM,
            'hover:cursor-pointer':
              validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM,
            'focus:bg-neutral-130':
              validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM,
          }
        )}"
        aria-label="${this.decrementButtonAssistiveText}"
        aria-live="polite"
        aria-atomic="true"
        type="button"
        ?disabled=${this.disabled}
        @click=${handleUserInitiatedStepDown}
        id="decrementButton"
      >
        <adc-icon icon="action:subtract"></adc-icon>
      </button>
    `;
  }

  render(): TemplateResult {
    const { _handleInput: handleInput } = this;
    const validity = this._testValidity();
    const isGenericallyInvalid = () =>
      this.invalid &&
      validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM &&
      validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM;
    const isRequired = () => this.required;
    const borderRed =
      this.invalid ||
      this.required ||
      validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM ||
      validity === NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM;
    const inputClasses = {
      'adc-number-input__input': true,
      'border-red-070': borderRed,
      'hover:border-blue-060': this.invalid || this.required,
      'bg-neutral-090': this.disabled,
      'border-neutral-090': this.disabled,
      'text-neutral-090': this.disabled,
      'border-neutral-070': !borderRed,
      'focus:border-blue-060':
        validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM &&
        validity !== NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM,
    };

    return html`
      <div class="inline-flex" ?data-invalid="${this.invalid}">
        ${this.renderDecrementButton()}
        <input
          autocomplete="${this.autocomplete}"
          class="adc-number-input__input font-sans text-base font-regular line-height-6 rounded border border-solid text-neutral-000 h-12 w-full p-0 outline-0 outline-none text-center my-0 mx-4 placeholder-neutral-060 ${classMap(
            inputClasses
          )}"
          ?data-invalid="${this.invalid}"
          ?disabled="${this.disabled}"
          id="input"
          name="${ifDefined(this.name)}"
          pattern="[0-9]"
          placeholder="${ifDefined(this.placeholder)}"
          ?required="${this.required}"
          type="number"
          .value="${this._value}"
          @input="${handleInput}"
          min="${ifDefined(this.min)}"
          max="${ifDefined(this.max)}"
          step="${ifDefined(this.step)}"
        />
        ${this.renderIncrementButton()}
      </div>
      <div
        class="font-sans font-regular text-xs line-height-4 text-red-060 overflow-hidden my-2 mx-16"
      >
        <div class="validity" ?hidden="${!isGenericallyInvalid()}">
          <slot name="validity-message"> ${this.validityMessage} </slot>
        </div>
        <div class="required" ?hidden="${!isRequired()}">
          <slot name="required-validity-message">
            ${this.requiredValidityMessage}
          </slot>
        </div>
        <div
          class="message-max"
          ?hidden="${validity !==
          NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM}"
        >
          <slot name="validity-message-max"> ${this.validityMessageMax} </slot>
        </div>
        <div
          class="message-min"
          ?hidden="${validity !==
          NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM}"
        >
          <slot name="validity-message-min"> ${this.validityMessageMin} </slot>
        </div>
      </div>
    `;
  }

  _getValidityMessage(state: NumberInputValidationStatus): string {
    if (Object.values(NUMBER_INPUT_VALIDATION_STATUS).includes(state)) {
      const stateMessageMap: Record<NumberInputValidationStatus, string> = {
        [NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MAXIMUM]:
          this.validityMessageMax,
        [NUMBER_INPUT_VALIDATION_STATUS.EXCEEDED_MINIMUM]:
          this.validityMessageMin,
      };

      return stateMessageMap[state];
    }

    return super.getValidityMessage(state);
  }

  /**
   * The name of the custom event fired after the value is changed upon a user
   * gesture.
   */
  static get eventInput(): string {
    return 'adc-number-input-input-value';
  }
}

try {
  customElements.define('adc-number-input', NumberInput);
} catch (e) {
  // do nothing
}
