import type { NumberInput } from './number-input';
import './number-input';

describe('<adc-number-input>', () => {
  let numberInput: NumberInput;
  beforeEach(() => {
    document.body.innerHTML = `<h1>Custom element test</h1><adc-number-input></adc-number-input>`;
    numberInput = document.querySelector('adc-number-input') as NumberInput;
  });

  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(numberInput?.nodeType).toBe(1);
    });
    it('should have correct default values', () => {
      expect(numberInput?.autofocus).toBe(false);
      expect(numberInput?.disabled).toBe(false);
      expect(numberInput?.required).toBe(false);
      expect(numberInput?.invalid).toBe(false);
      expect(numberInput?.min).toBe('');
      expect(numberInput?.max).toBe('');
      expect(numberInput?.step).toBe('1');
      expect(numberInput?.placeholder).toBe('');
      expect(numberInput?.validityMessage).toBe('');
      expect(numberInput?.requiredValidityMessage).toBe(
        'Please fill out this field'
      );
      expect(numberInput?.validityMessageMax).toBe('');
      expect(numberInput?.validityMessageMin).toBe('');
      expect(numberInput?.pattern).toBe('^[0-9]*$');
    });
  });
  describe('when properties has been settled', () => {
    it(`should increase the value when click on increment button`, async () => {
      numberInput.min = '0';
      numberInput.max = '100';
      await numberInput.updateComplete;
      const incrementButton = numberInput.shadowRoot?.querySelector(
        '#incrementButton'
      ) as HTMLButtonElement;
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      incrementButton?.click();
      expect(input?.value).toBe('1');
    });
    it(`should decrease the value when click on Decrement button`, async () => {
      numberInput.min = '0';
      numberInput.max = '100';
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '1';
      await numberInput.updateComplete;
      const decrementButton = numberInput.shadowRoot?.querySelector(
        '#decrementButton'
      ) as HTMLButtonElement;
      decrementButton?.click();
      expect(input.value).toBe('0');
    });
    it(`should not increase the value when click on increment button and has reached the max`, async () => {
      numberInput.min = '0';
      numberInput.max = '100';
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '100';
      await numberInput.updateComplete;
      const incrementButton = numberInput.shadowRoot?.querySelector(
        '#incrementButton'
      ) as HTMLButtonElement;

      incrementButton?.click();

      expect(input.value).toBe('100');
    });
    it(`should render a increment disabled button when type a greater value than the max`, async () => {
      numberInput.min = '0';
      numberInput.max = '100';
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '101';
      numberInput.requestUpdate();
      await numberInput.updateComplete;
      const incrementDisabledButton =
        numberInput?.shadowRoot?.querySelector('.bg-transparent');

      expect(incrementDisabledButton).not.toBeNull();
    });
    it(`should render a decrement disabled button when type a lower value than the max`, async () => {
      numberInput.min = '1';
      numberInput.max = '100';
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '0';
      await numberInput.updateComplete;
      const decrementDisabledButton =
        numberInput?.shadowRoot?.querySelector('.bg-transparent');

      expect(decrementDisabledButton).not.toBeNull();
    });
    it(`should display a message max when type a greater value than the max`, async () => {
      numberInput.min = '0';
      numberInput.max = '100';
      numberInput.validityMessageMax = 'Try a lower value, between 0 and 100';
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '101';
      await numberInput.updateComplete;
      const message = numberInput.shadowRoot?.querySelector('.message-max');
      expect(message?.textContent?.trim()).toBe(
        'Try a lower value, between 0 and 100'
      );
    });
    it(`should display a message min when type a lower value than the min`, async () => {
      numberInput.min = '2';
      numberInput.max = '100';
      numberInput.validityMessageMin = 'Try a lower value, between 2 and 100';
      await numberInput.updateComplete;
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '1';
      await numberInput.updateComplete;
      const message = numberInput.shadowRoot?.querySelector('.message-min');
      expect(message?.textContent?.trim()).toBe(
        'Try a lower value, between 2 and 100'
      );
    });
    it(`should increment by 4`, async () => {
      numberInput.step = '4';
      numberInput.min = '0';
      numberInput.max = '100';
      await numberInput.updateComplete;
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '0';
      const incrementButton = numberInput.shadowRoot?.querySelector(
        '#incrementButton'
      ) as HTMLButtonElement;
      incrementButton.click();
      await numberInput.updateComplete;

      expect(input.value).toBe('4');
    });
    it(`should decrement by 4`, async () => {
      numberInput.step = '4';
      numberInput.min = '0';
      numberInput.max = '100';
      await numberInput.updateComplete;
      const input = numberInput.shadowRoot?.querySelector(
        '#input'
      ) as HTMLInputElement;
      input.value = '4';
      const decrementButton = numberInput.shadowRoot?.querySelector(
        '#decrementButton'
      ) as HTMLButtonElement;
      decrementButton.click();
      await numberInput.updateComplete;

      expect(input.value).toBe('0');
    });
  });
});
