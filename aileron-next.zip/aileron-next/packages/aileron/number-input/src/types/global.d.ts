import { NumberInput } from './number-input';

declare global {
  interface HTMLElementTagNameMap {
    'adc-number-input': NumberInput;
  }
}
