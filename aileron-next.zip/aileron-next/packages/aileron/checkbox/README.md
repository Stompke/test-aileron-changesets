# @aileron/checkbox

### For documentation, please visit our [Checkbox documentation page](https://animated-doodle-g3kyvlm.pages.github.io/components/checkbox/).
