# @aileron/checkbox

## 1.6.5-next.0

### Patch Changes

- d41e2d29: version bump

## 1.6.4

### Patch Changes

- cedc7699: fix: update all components for eslint
