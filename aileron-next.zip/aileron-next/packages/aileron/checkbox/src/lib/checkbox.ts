import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { closestElement } from '@aileron/shared/closest-element';
import { emit } from '@aileron/shared/event';
import { FormSubmitController } from '@aileron/shared/form';
import { watch } from '@aileron/shared/watch';
import { html } from 'lit';
import { property, query, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { live } from 'lit/directives/live.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';

/**
 * Checkbox
 * @element adc-checkbox
 * @summary A checkbox is a type of data input typically found in forms with simple true/false values. Multiple checkboxes can be grouped under a single label where one or more choices are available.
 * @fires adc-changed - Event fired when the checkbox is changed.
 * @fires adc-blur - Event fired when the checkbox loses focus.
 * @fires adc-focus - Event fired when the checkbox gains focus.
 * @slot Default - used for the label of checkbox.
 * @csspart base - base container element of adc-checkbox
 * @csspart input - input element of adc-checkbox
 * @csspart label - label element of adc-checkbox
 * @attr {boolean} [checked] - Sets the checked state of the checkbox.
 * @attr {boolean} [required] - Sets the required state of the checkbox.
 * @attr {boolean} [disabled] - Sets the disabled state of the checkbox.
 * @attr {boolean} [invalid] - Sets the valid state of the checkbox.
 * @attr {boolean} [indeterminate] - Sets the indeterminate state of the checkbox.
 * @attr {"vertical" | "horizontal"} [orientation] - Sets the orientation of the checkbox.
 * @attr {"left" | "right"} [label-position] - Sets the label position of the checkbox.
 * @attr {string} [label-text] - Sets the label text of the checkbox.
 * @attr {string} [name=undefined] - Sets the name of the checkbox.
 * @attr {string} [value=undefined] - Sets the value of the checkbox.
 * @attr {boolean} [live-validation] - Sets the live validation of the checkbox.
 */
export class Checkbox extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @query('input[type="checkbox"]') input!: HTMLInputElement;

  /**
   * @ignore
   */
  // @ts-expect-error -- Controller is currently unused
  private readonly formSubmitController = new FormSubmitController(this, {
    value: (control: Checkbox) => (control.checked ? control.value : undefined),
  });

  @state() private hasFocus = false;
  @state() private pristine = true;

  @property({ type: Boolean, reflect: true }) checked = false;
  @property({ type: Boolean, reflect: true }) required = false;
  @property({ type: Boolean, reflect: true }) disabled = false;
  @property({ type: Boolean, reflect: true }) invalid = false;
  @property({ type: Boolean, reflect: true }) indeterminate = false;
  @property({ reflect: true }) orientation: 'vertical' | 'horizontal' =
    'horizontal';
  @property({ attribute: 'label-position', reflect: true })
  labelPosition: 'left' | 'right' = 'right';
  @property({ type: String, attribute: 'label-text' }) labelText = '';
  @property({ type: String }) name!: string;
  @property({ type: String }) value!: string;
  @property({ type: Boolean, attribute: 'live-validation', reflect: true })
  liveValidation = false;

  firstUpdated() {
    this.invalid = !this.pristine && !this.input.checkValidity();
  }

  updated(changedProperties: PropertyValues) {
    if (changedProperties.has('pristine')) {
      if (this.liveValidation && !this.pristine) {
        this.invalid = !this.input.checkValidity();
      }
    }

    if (changedProperties.has('disabled')) {
      if (this.disabled) {
        this.input.setAttribute('disabled', 'disabled');
      } else {
        this.input.removeAttribute('disabled');
      }
    }
  }

  /**
   * Click method for the checkbox.
   */
  click() {
    this.input.click();
  }

  /**
   * Focus method for the checkbox.
   */
  focus(options?: FocusOptions) {
    this.input.focus(options);
  }

  /**
   * Blur method for the checkbox.
   */
  blur() {
    this.input.blur();
  }

  /**
   * Check validity method for the checkbox.
   */
  reportValidity() {
    return this.input.reportValidity();
  }

  /**
   * Sets the custom validity message of the checkbox.
   */
  setCustomValidity(message: string) {
    this.input.setCustomValidity(message);
    this.invalid = !this.input.checkValidity();
  }

  /**
   * handleClick method for the checkbox.
   */
  handleClick() {
    this.checked = !this.checked;
    this.indeterminate = false;
    this.handleValidity();

    emit(this, 'adc-changed');
  }

  /**
   * handleBlur method for the checkbox.
   */
  handleBlur() {
    this.hasFocus = false;

    emit(this, 'adc-blur');
  }

  /**
   * handleDisabledChange method for the checkbox.
   */
  @watch('disabled', { waitUntilFirstUpdate: true })
  handleDisabledChange() {
    this.input.disabled = this.disabled;
    this.invalid = !this.input.checkValidity();
  }

  /**
   * handleFocus method for the checkbox.
   */
  handleFocus() {
    this.hasFocus = true;

    emit(this, 'adc-focus');
  }

  /**
   * handleStateChange method for the checkbox.
   */
  @watch('checked', { waitUntilFirstUpdate: true })
  @watch('indeterminate', { waitUntilFirstUpdate: true })
  handleStateChange() {
    this.invalid = !this.input.checkValidity();
  }

  /**
   * handleValidity method for the checkbox.
   */
  handleValidity() {
    if (this.liveValidation) {
      this.pristine = false;
    }

    this.invalid = !this.input.checkValidity();
  }

  render(): TemplateResult {
    const labelClasses = {
      'adc-checkbox__label--focused': this.hasFocus,
      'flex-row-reverse': this.labelPosition === 'left',
      'pointer-events-none': this.disabled,
    };
    const secondaryClosest = !!closestElement('.container-secondary', this);
    const tertiaryClosest = !!closestElement('.container-tertiary', this);

    return html` <label
      part="base"
      for="checkbox"
      class="
        font-sans
        font-regular
        line-height-6
        text-base
        group
        min-h-12
        cursor-pointer
        items-center
        inline-flex
        ${classMap(labelClasses)}
      "
    >
      <div
        class="
        h-8
        w-8
        relative
        ${classMap({
          'ml-8': this.labelPosition === 'left',
          'mr-0': this.labelPosition === 'left',
          'ml-0': this.labelPosition === 'right',
          'mr-8': this.labelPosition === 'right',
        })}
        "
      >
        <input
          part="input"
          id="checkbox"
          type="checkbox"
          class="
            absolute
            left-4
            top-4
            inline-flex
            items-center
            justify-center
            appearance-none
            outline-none
            cursor-pointer
            min-w-6
            h-6
            w-6
            m-0

            before:rounded-full
            before:h-0
            before:absolute
            before:w-0
            before:z-[-1]
            before:transition-[height,width]
            before:duration-[180ms]
            before:ease-in-out
            group-hover:before:h-10
            group-hover:before:w-10
            group-hover:before:bg-blue-120
            dark:group-hover:before:bg-blue-020
            focus:before:h-10
            focus:before:w-10
            focus:before:bg-blue-100
            dark:focus:before:bg-blue-040
          "
          name=${ifDefined(this.name)}
          value=${ifDefined(this.value)}
          .indeterminate=${live(this.indeterminate)}
          .checked=${live(this.checked)}
          .required=${this.required}
          aria-checked=${this.checked ? 'true' : 'false'}
          @click=${this.handleClick}
          @blur=${this.handleBlur}
          @focus=${this.handleFocus}
        />
        <div
          class="
          pointer-events-none
          absolute
          left-[5px]
          top-[5px]
          w-[22px]
          h-[22px]
          ${classMap({
            'bg-neutral-120': tertiaryClosest,
            'dark:bg-neutral-020': tertiaryClosest,
            'bg-neutral-130': secondaryClosest,
            'dark:bg-neutral-010': secondaryClosest,
            'bg-neutral-140': !tertiaryClosest && !secondaryClosest,
            'dark:bg-neutral-000': !tertiaryClosest && !secondaryClosest,
          })}
        "
        ></div>
        <adc-icon
          icon="action:select-empty"
          size="32"
          class="
            pointer-events-none
            absolute
            left-0
            top-0
            z-1
            transition-[color]
            duration-[180ms]
            ease-in-out
            text-neutral-070
            ${classMap({
            'text-neutral-090': this.disabled,
            'dark:text-neutral-050': this.disabled,
            'text-red-060': this.invalid,
            'dark:text-red-080': this.invalid,
          })}
          "
        ></adc-icon>
        <adc-icon
          icon="action:select-checked"
          size="32"
          class="
            pointer-events-none
            absolute
            left-0
            top-0
            z-2
            transition-[opacity,color]
            duration-[180ms]
            ease-in-out
            ${classMap({
            'opacity-0': !this.checked,
            'opacity-100': this.checked,
            'text-neutral-090': this.disabled,
            'dark:text-neutral-050': this.disabled,
            'text-red-060': this.invalid,
            'dark:text-red-080': this.invalid,
            'text-blue-060': this.checked && !this.disabled && !this.invalid,
            'dark:text-blue-080':
              this.checked && !this.disabled && !this.invalid,
          })}
          "
        ></adc-icon>
      </div>
      <span
        part="label"
        class="
          items-center
          cursor-pointer
          inline-flex
          ${classMap({
          'text-neutral-090': this.disabled,
          'text-neutral-010': !this.disabled,
          'dark:text-neutral-050': this.disabled,
          'dark:text-neutral-130': !this.disabled,
        })}"
      >
        <slot>${this.labelText}</slot>
      </span>
    </label>`;
  }
}

try {
  customElements.define('adc-checkbox', Checkbox);
} catch (e) {
  // do nothing
}
