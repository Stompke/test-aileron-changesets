import { Checkbox } from './checkbox';

declare global {
  interface HTMLElementTagNameMap {
    'adc-checkbox': Checkbox;
  }
}
