import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * @ignore
 */
export const ICON_KIND = {
  NEWWINDOW: 'new-window',
  CHEVRON: 'chevron',
  EMPTY: '',
} as const;

type IconKind = (typeof ICON_KIND)[keyof typeof ICON_KIND];

/**
 * Link
 * @element adc-link
 * @summary A link is a component that is used to navigate to another page or section.
 * @slot Default - text for the link
 * @attr {string} [href=""] - Href to pass to the html anchor element
 * @attr {string} [hidden-label-text=""] - Add hidden text for screen readers
 * @attr {"navigation:new-window" | "navigation:chevron-right" | ""} [icon=''] - Determine what icon to show, if any.
 * @attr {string} [rel=undefined] - Rel to pass to the html anchor element
 * @attr {"_blank" | "_self" | "_parent" | "_top" | undefined} [target=undefined] - Target to pass to the html anchor element.
 * @attr {boolean} [inline=false] - Set if this is used within a paragraph or standalone
 */
export class Link extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @property({ reflect: true }) icon: IconKind = ICON_KIND.EMPTY;
  @property() href = '';
  @property({ reflect: true, attribute: 'hidden-label-text' })
  hiddenLabelText = '';
  @property({ reflect: false }) rel!: string;
  @property({ reflect: false }) target!:
    | '_blank'
    | '_parent'
    | '_self'
    | '_top';
  @property({ type: Boolean, reflect: true }) inline = false;

  renderIcon(): TemplateResult | undefined {
    return this.icon
      ? this.icon === 'chevron'
        ? html`<div
            id="chevronIcon"
            class="inline-block group-hover:no-underline font-sans font-regular text-base line-height-6"
            aria-hidden="true"
          >
            &raquo;
          </div>`
        : html`
            <div class="inline-flex relative">
              <adc-icon
                class="
                  text-blue-060
                  dark:text-blue-080
                  group-hover:text-blue-070
                  group-focus:text-blue-070
                  dark:group-focus:text-blue-080
                  group-active:text-blue-080
                  dark:group-active:text-blue-070"
                exportparts="icon"
                icon="navigation:${this.icon}"
                size="16"
              ></adc-icon>
            </div>
          `
      : undefined;
  }

  renderHiddenText(text: string): TemplateResult | undefined {
    return text ? html`<span class="sr-only">${text}</span>` : undefined;
  }

  renderSlot(): TemplateResult {
    return html`
      <slot></slot>
      ${this.renderHiddenText(this.hiddenLabelText)} ${this.renderIcon()}
    `;
  }

  render(): TemplateResult {
    return html`
      <a
        class="
          font-sans
          font-regular
          text-base
          line-height-6
          group
          rounded
          inline-block
          underline
          box-border
          text-blue-060
          dark:text-blue-080
          hover:text-blue-070
          hover:no-underline
          active:text-blue-080
          dark:active:text-blue-070
          focus:outline
          focus:outline-offset-1
          focus:outline-1
          focus:outline-blue-070
          after:hover:no-underline"
        href=${this.href}
        part="anchor"
        rel=${ifDefined(this.rel)}
        target=${ifDefined(this.target)}
      >
        ${this.renderSlot()}
      </a>
    `;
  }

  /**
   * Determine if a link is external or not
   * @private
   * @param href
   * @returns boolean
   */
  private handleExternalHref(href: string) {
    const match = href.match(/^https?:\/\/(?!www.aa.com|aa.com)+/);

    return !!match;
  }

  /**
   * If there is an external link, add a target="_blank" and rel="noopener
   * noreferrer"
   */
  connectedCallback(): void {
    super.connectedCallback();

    if (this.href && this.handleExternalHref(this.href) && !this.target) {
      this.target = '_blank';
      this.rel = 'noreferrer';
    }
  }
}

try {
  customElements.define('adc-link', Link);
} catch (e) {
  // do nothing
}
