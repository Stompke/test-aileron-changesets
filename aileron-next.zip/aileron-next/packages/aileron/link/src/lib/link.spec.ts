import { Link } from './link';
import './link';

describe('<adc-link>', () => {
  let link: Link;
  beforeEach(() => {
    document.body.innerHTML = `
    <p>
      Sapiente itaque laborum officia debitis et voluptatum.
      <adc-link></adc-link>
    </p>
  `;
    link = document.querySelector('adc-link');
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(link?.nodeType).toBe(1);
    });
    it('should have correct default values', () => {
      expect(link?.href).toBe('');
      expect(link?.hiddenLabelText).toBe('');
      expect(link?.rel).toBe(undefined);
      expect(link?.target).toBe(undefined);
      expect(link?.inline).toBe(false);
      expect(link?.icon).toBe('');
    });
    it('should render an anchor', async () => {
      const anchor = link.shadowRoot?.querySelector('a');
      expect(anchor).not.toBeNull();
    });
  });
  describe('when properties has been settled', () => {
    it('should has new-window icon', async () => {
      link.icon = 'new-window';
      link.requestUpdate();
      await link.updateComplete;
      const icon = link.shadowRoot?.querySelector(
        'adc-icon[icon="navigation:new-window"]'
      );
      expect(icon).not.toBeNull();
    });
    it('should has chevron icon', async () => {
      link.icon = 'chevron';
      link.requestUpdate();
      await link.updateComplete;
      const icon = link.shadowRoot?.querySelector('#chevronIcon');
      expect(icon).not.toBeNull();
    });
  });
});
