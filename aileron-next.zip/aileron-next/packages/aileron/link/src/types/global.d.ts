import { Link } from './link';

declare global {
  interface HTMLElementTagNameMap {
    'adc-link': Link;
  }
}
