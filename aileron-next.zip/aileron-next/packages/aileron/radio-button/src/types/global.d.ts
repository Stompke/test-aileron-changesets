import { RadioButton } from './radio-button';
import { RadioGroup } from './radio-group.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-radio-button': RadioButton;
    'adc-radio-group': RadioGroup;
  }
}
