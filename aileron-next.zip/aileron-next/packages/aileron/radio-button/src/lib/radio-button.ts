import { AileronElement } from '@aileron/shared/aileron-element';
import { closestElement } from '@aileron/shared/closest-element';
import { emit } from '@aileron/shared/event';
import { FormSubmitController } from '@aileron/shared/form';
import { watch } from '@aileron/shared/watch';
import { html } from 'lit';
import { property, query, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { live } from 'lit/directives/live.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Radio Button
 * @element adc-radio-button
 * @summary Radio Button's are used to select a single option from a set of options.
 * @fires {CustomEvent} adc-radio-group-changed | Fires whenever a radio button delegate is checked or unchecked.
 * @fires {CustomEvent} adc-blur | Fires whenever a radio button is blurred.
 * @fires {CustomEvent} adc-focus | Fires whenever a radio button is focused.
 * @fires {CustomEvent} adc-change | Fires whenever a radio button is changed.
 * radio button changes.
 * @slot default - text label content.
 * @attr {string} [label-text=undefined] - Sets the label text for the radio button.
 * @attr {string} [name=undefined] - Sets the name for the radio button.
 * @attr {string} [value=undefined] - Sets the value for the radio button.
 */
export class RadioButton extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  /**
   * Actual radio button element.
   * @private
   */
  @query('input[type=radio]') input!: HTMLInputElement;

  readonly formSubmitController = new FormSubmitController(this, {
    value: (control: HTMLInputElement) =>
      control.checked ? control.value : undefined,
  });

  @state() hasFocus = false;

  /**
   * Sets the checked state of the radio button.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) checked = false;

  /**
   * Sets the disabled state of the radio button.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * Hides the label text on for the radio button.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true, attribute: 'hide-label' })
  hideLabel = false;

  /**
   * Positions the label text to the right/left of the radio button.
   * @type {"left"|"right"}
   */
  @property({ reflect: true, attribute: 'label-position' })
  labelPosition: 'left' | 'right' = 'right';

  /**
   * Sets the label text for the radio button.
   * @type {string}
   */
  @property({ attribute: 'label-text' }) labelText!: string;

  /**
   * Set the value for the radio button.
   * @type {string}
   */
  @property() value!: string;

  /**
   * Sets the validity of the radio button.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) invalid = false;

  /**
   * Marks the radio button as required.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) required = false;

  /**
   * Sets the name of the radio button.
   * @type {string}
   */
  @property() name!: string;

  /**
   * Sets the orientation of the radio button.
   * @type {"horizontal"|"vertical"}
   */
  @property({ reflect: true }) orientation: 'horizontal' | 'vertical' =
    'horizontal';

  click() {
    this.input.click();
  }

  focus(options?: FocusOptions) {
    this.input.focus(options);
  }

  blur() {
    this.input.blur();
  }

  reportValidity() {
    return this.input.reportValidity();
  }

  checkValidity() {
    return this.input.checkValidity();
  }

  setCustomValidity(message: string) {
    this.input.setCustomValidity(message);
    this.invalid = !this.input.checkValidity();
  }

  handleBlur() {
    this.hasFocus = false;

    emit(this, 'adc-blur');
  }

  handleClick() {
    if (!this.disabled) {
      this.checked = true;
    }
  }

  handleFocus() {
    this.hasFocus = true;

    emit(this, 'adc-focus');
  }

  handleInvalid() {
    this.invalid = true;
  }

  @watch('checked')
  handleCheckedChange() {
    if (this.hasUpdated) {
      emit(this, 'adc-change');
    }
  }

  @watch('disabled', { waitUntilFirstUpdate: true })
  handleDisabledChange() {
    this.setAttribute('aria-disabled', this.disabled ? 'true' : 'false');

    if (this.hasUpdated) {
      this.input.disabled = this.disabled;
      this.invalid = !this.input.checkValidity();
    }
  }

  render(): TemplateResult {
    const secondaryClosest = !!closestElement('.container-secondary', this);
    const tertiaryClosest = !!closestElement('.container-tertiary', this);
    const labelClasses = {
      'flex-row-reverse': this.labelPosition === 'left',
      'h-6': this.orientation === 'vertical',
      'h-12': this.orientation !== 'vertical',
      'pointer-events-none': this.disabled,
    };

    const innerLabelClasses = {
      'sr-only': this.hideLabel,
      'text-neutral-090': this.disabled,
      'dark:text-neutral-050': this.disabled,
      'text-neutral-010': !this.disabled,
      'dark:text-neutral-130': !this.disabled,
    };

    return html`
      <label
        part="base"
        for="input"
        class="
        font-sans
        font-regular
        text-base
        line-height-6
        pointer-events-auto
        items-center
        text-neutral-010
        cursor-pointer
        inline-flex
        justify-start
        m-0
        relative
        align-middle
        whitespace-nowrap
        group
        ${classMap(labelClasses)}"
      >
        <input
          id="input"
          class="adc-radio-button__input sr-only"
          type="radio"
          .checked=${live(this.checked)}
          .disabled=${this.disabled}
          .required=${this.required}
          name=${ifDefined(this.name)}
          value=${ifDefined(this.value)}
          @invalid=${this.handleInvalid}
          @click=${this.handleClick}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
        />
        <span
          part="control"
          class="
          adc-radio-button__control
          border
          rounded-full
          border-solid
          border-neutral-070
          items-center
          box-border
          flex
          h-6
          w-6
          justify-center
          mr-2
          relative
          whitespace-nowrap
          transition-[border,background,height,width]
          duration-[180ms]
          ease-in-out
          delay-[0]
          group-focus-within:border-blue-070

          before:absolute
          before:rounded-full
          before:box-border
          before:border
          before:flex
          before:h-4
          before:w-4
          before:top-1/2
          before:left-1/2
          before:border-neutral-070
          before:border-solid
          before:translate-x-[-50%]
          before:translate-y-[-50%]

          after:absolute
          after:rounded-full
          after:border
          after:box-border
          after:flex
          after:h-3
          after:w-3
          after:group-hover:h-8
          after:group-hover:w-8
          after:top-1/2
          after:left-1/2
          after:translate-x-[-50%]
          after:translate-y-[-50%]
          after:z-[-1]
          after:transition-[background,height,width]
          after:duration-[180ms]
          after:ease-in-out
          after:group-hover:bg-blue-120
          dark:after:group-hover:bg-blue-020

          after:group-focus-within:border
          after:group-focus-within:bg-blue-100
          dark:after:group-focus-within:bg-blue-040
          after:group-focus-within:h-8
          after:group-focus-within:w-8
          after:group-focus-within:transition-[background,height,width]
          after:group-focus-within:duration-[180ms]
          after:group-focus-within:ease-in-out

          ${classMap({
            'my-1': this.hideLabel,
            'mx-0': this.hideLabel,
            'ml-2': this.labelPosition === 'left',
            'mr-0': this.labelPosition === 'left',
            //Normal
            'before:bg-neutral-130': secondaryClosest && !this.checked,
            'bg-neutral-130': secondaryClosest,
            'before:bg-neutral-120': tertiaryClosest && !this.checked,
            'bg-neutral-120': tertiaryClosest,
            'before:bg-neutral-140':
              !secondaryClosest && !tertiaryClosest && !this.checked,
            'bg-neutral-140': !secondaryClosest && !tertiaryClosest,
            'dark:before:bg-neutral-010': secondaryClosest && !this.checked,
            'dark:bg-neutral-010': secondaryClosest,
            'dark:before:bg-neutral-020': tertiaryClosest && !this.checked,
            'dark:bg-neutral-020': tertiaryClosest,
            'dark:before:bg-neutral-000':
              !secondaryClosest && !tertiaryClosest && !this.checked,
            'dark:bg-neutral-000': !secondaryClosest && !tertiaryClosest,
            //Disabled at all
            'before:bg-neutral-090': this.disabled && this.checked,
            'dark:before:bg-neutral-050': this.disabled && this.checked,
            'before:border-neutral-090': this.disabled,
            'dark:before:border-neutral-050': this.disabled,
            'border-neutral-090': this.disabled,
            'dark:border-neutral-050': this.disabled,
            //Checked only
            'before:bg-blue-060':
              this.checked && !this.disabled && !this.invalid,
            'dark:before:bg-blue-080':
              this.checked && !this.disabled && !this.invalid,
            'before:border-blue-060':
              this.checked && !this.disabled && !this.invalid,
            'dark:before:border-blue-080':
              this.checked && !this.disabled && !this.invalid,
            'border-blue-070': this.checked && !this.disabled && !this.invalid,
            //Invalid at all
            'border-red-060': this.invalid && !this.disabled,
            'dark:border-red-080': this.invalid && !this.disabled,
            'before:bg-red-060': this.invalid && this.checked && !this.disabled,
            'dark:before:bg-red-080':
              this.invalid && this.checked && !this.disabled,
            'before:border-red-060':
              this.invalid && this.checked && !this.disabled,
            'dark:before:border-red-080':
              this.invalid && this.checked && !this.disabled,
          })}"
        ></span>
        <span
          part="label"
          class="
          adc-radio-button__label-text
          ${classMap(innerLabelClasses)}
        "
        >
          <slot>${this.labelText}</slot>
        </span>
      </label>
    `;
  }
}

try {
  customElements.define('adc-radio-button', RadioButton);
} catch (e) {
  // do nothing
}
