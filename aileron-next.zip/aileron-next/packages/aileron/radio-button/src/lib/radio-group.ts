import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { emit } from '@aileron/shared/event';
import { watch } from '@aileron/shared/watch';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { RadioButton } from './radio-button';
import type { PropertyValues } from 'lit';

const RADIO_CHILDREN = ['adc-radio-button'];

/**
 * Radio Button Group
 * @element adc-radio-group
 * @summary A Radio Button group is used to organize a collection of radio buttons.
 * @fires {CustomEvent} adc-radio-group-changed - Event fired when the checked state of the
 * radio button changes.
 * @slot default - Takes adc-radio-button elements.
 * @slot label-text - Default text label content.
 * @attr {string} [label-text=undefined] - Sets the label text for the radio button group.
 * @attr {string} [name=undefined] - Sets the name for the children radio buttons.
 * @attr {string} [value=undefined] - Sets the value for the radio button collection.
 */
export class RadioGroup extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * Sets required to the child radio buttons.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) required = false;

  /**
   * Sets disabled to the child radio buttons.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * Sets invalid based on child radio buttons.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) invalid = false;

  /**
   * Positions the label text for the child radio buttons.
   * @type {"left"|"right"}
   */
  @property({ attribute: 'label-position' })
  labelPosition: 'left' | 'right' = 'right';

  /**
   * Sets the label text for the radio button group.
   * @type {string}
   */
  @property({ attribute: 'label-text' }) labelText!: string;

  /**
   * Sets the name for the children radio buttons.
   * @type {string}
   */
  @property() name!: string;

  /**
   * Sets the value for the radio button collection.
   * @type {string}
   */
  @property({ reflect: true }) value!: string;

  /**
   * Sets the orientation for the radio button children.
   * @type {"horizontal"|"vertical"}
   */
  @property({ reflect: true }) orientation: 'horizontal' | 'vertical' =
    'horizontal';

  /**
   * Sets the inputmode attribute on the native input element.
   * @type {string}
   */
  @property({ attribute: 'validity-message' }) validityMessage = '';

  getAllRadios() {
    const radios = this.querySelectorAll(RADIO_CHILDREN.join(','));

    return Array.from(radios).filter((el) => {
      return RADIO_CHILDREN.includes(el.tagName.toLowerCase());
    }) as RadioButton[];
  }

  handleRadioClick(event: MouseEvent) {
    const target = event.target as RadioButton;
    const checkedRadio = target.closest(
      RADIO_CHILDREN.map((selector) => `${selector}:not([disabled])`).join(',')
    );

    if (checkedRadio) {
      this.value = (checkedRadio as RadioButton).value;
      this.invalid = false;
      this.getAllRadios().forEach((radio) => {
        radio.checked = radio === checkedRadio;
        radio.input.tabIndex = radio === checkedRadio ? 0 : -1;
      });
    }
  }

  handleKeyDown(event: KeyboardEvent) {
    if (
      ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)
    ) {
      const radios = this.getAllRadios().filter((radio) => !radio.disabled);
      const checkedRadio = radios.find((radio) => radio.checked) ?? radios[0];
      const incr = ['ArrowUp', 'ArrowLeft'].includes(event.key) ? -1 : 1;

      let index = radios.indexOf(checkedRadio) + incr;

      if (index < 0) {
        index = radios.length - 1;
      }

      if (index > radios.length - 1) {
        index = 0;
      }

      this.getAllRadios().forEach((radio) => {
        radio.checked = false;
        radio.input.tabIndex = -1;
      });

      radios[index].focus();
      radios[index].checked = true;
      radios[index].input.tabIndex = 0;

      this.value = radios[index].value;
      this.invalid = false;

      event.preventDefault();
    }
  }

  handleSlotChange() {
    const radios = this.getAllRadios();
    const checkedRadio = radios.find((radio) => radio.checked);

    radios.forEach((radio) => {
      radio.checked = radio === checkedRadio || radio.value === this.value;
      radio.required = this.required;
      radio.name = this.name;
      radio.input.tabIndex = -1;
    });

    if (checkedRadio) {
      checkedRadio.input.tabIndex = 0;
    } else if (radios.length > 0) {
      radios[0].input.tabIndex = 0;
    }
  }

  @watch('value', { waitUntilFirstUpdate: true })
  handleValueChange() {
    const radios = this.getAllRadios();

    if (this.hasUpdated) {
      radios.forEach((radio) => {
        radio.checked = radio.value === this.value;
      });

      emit(this, 'adc-radio-group-changed', { detail: { value: this.value } });
    }
  }

  @watch('disabled', { waitUntilFirstUpdate: true })
  handleDisabledChange() {
    const radios = this.getAllRadios();

    if (this.hasUpdated) {
      radios.forEach((radio) => {
        radio.disabled = this.disabled;
      });
    }
  }

  @watch('orientation', { waitUntilFirstUpdate: true })
  handleOrientationChange() {
    const radios = this.getAllRadios();

    if (this.hasUpdated) {
      radios.forEach((radio) => {
        radio.orientation = this.orientation;
      });
    }
  }

  @watch('labelPosition', { waitUntilFirstUpdate: true })
  handleLabeLPositionChange() {
    const radios = this.getAllRadios();

    if (this.hasUpdated) {
      radios.forEach((radio) => {
        radio.labelPosition = this.labelPosition;
      });
    }
  }

  @watch('required', { waitUntilFirstUpdate: true })
  handleRequiredChange() {
    const radios = this.getAllRadios();

    if (this.hasUpdated) {
      radios.forEach((radio) => {
        radio.required = this.required;
      });
    }
  }

  async updated(changedProperties: PropertyValues) {
    await this.updateComplete;

    this.getAllRadios().forEach((radio) => {
      radio.invalid = false;
    });

    if (changedProperties.has('invalid')) {
      this.getAllRadios().forEach((radio) => {
        radio.invalid = this.invalid;
      });
    }
  }

  render() {
    const classes = {
      'after:border': this.required,
      'after:border-red-070': this.required,
      'after:border-solid': this.required,
      'after:rounded-full': this.required,
      'after:bg-red-070': this.required,
      'after:h-[6px]': this.required,
      'after:ml-4': this.required,
      'after:w-[6px]': this.required,
      'text-red-060': this.invalid,
      'dark:text-red-080': this.invalid,
      'text-neutral-060': !this.invalid,
      'dark:text-neutral-080': !this.invalid,
    };

    return html`
      <fieldset
        part="base"
        class="adc-radio-group block p-0 border-0 ${this.orientation ===
        'vertical'
          ? 'mb-1'
          : 'm-0'}"
      >
        <legend
          part="label"
          class="font-sans font-regular text-sm line-height-4 items-center flex mb-8 ${classMap(
            classes
          )}"
        >
          ${this.invalid
            ? html`<adc-icon
                icon="signal:error"
                size="16"
                outlined
                class="mr-1 text-red-070"
              ></adc-icon>`
            : undefined}
          <slot name="label-text">${this.labelText}</slot>
        </legend>
        <slot
          @click=${this.handleRadioClick}
          @keydown=${this.handleKeyDown}
          @slotchange=${this.handleSlotChange}
        ></slot>
        <div
          class="font-sans font-regular line-height-4 text-xs mt-2 mx-0 mb-0 ${classMap(
            {
              'text-red-060': this.invalid,
              'dark:text-red-080': this.invalid,
              block: this.invalid,
              'overflow-visible': this.invalid,
              hidden: !this.invalid,
              'overflow-hidden': !this.invalid,
            }
          )}"
          aria-live="polite"
        >
          <slot name="validity-message">${this.validityMessage}</slot>
        </div>
      </fieldset>
    `;
  }
}

try {
  customElements.define('adc-radio-group', RadioGroup);
} catch (e) {
  // do nothing
}
