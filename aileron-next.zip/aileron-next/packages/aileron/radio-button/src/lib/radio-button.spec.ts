import type { RadioButton, RadioGroup } from '../index';
import '../index';

describe('<adc-radio-button>', () => {
  let radioButtonGroup: RadioGroup;
  let radioButton: RadioButton;
  beforeEach(() => {
    document.body.innerHTML = `
    <form>
      <adc-radio-group required>
        <adc-radio-button
          label-text="Radio Button 1"
          value="radio_button_01"
          id="Radio1"
        ></adc-radio-button>
        <adc-radio-button
          label-text="Radio Button 2"
          value="radio_button_02"
          id="Radio2"
        ></adc-radio-button>
        <adc-radio-button
          label-text="Radio Button 3"
          value="radio_button_03"
          id="Radio3"
        ></adc-radio-button>
      </adc-radio-group>
    </form>
    `;
    radioButtonGroup = document.querySelector('adc-radio-group') as RadioGroup;
    radioButton = document.querySelector('adc-radio-button');
  });
  it('should be disabled with the disabled attribute', async () => {
    radioButton.disabled = true;
    await radioButton?.updateComplete;

    expect(radioButton?.input.disabled).toBe(true);
  });

  it('should be valid by default', () => {
    expect(radioButton?.invalid).toBe(false);
  });

  it('should fire adc-change when clicked', async () => {
    const input = radioButton?.shadowRoot?.getElementById(
      'input'
    ) as HTMLInputElement;
    input.click();

    expect(radioButton?.checked).toBe(true);
  });

  it('should not get checked when disabled', async () => {
    radioButton.disabled = true;
    await radioButton.updateComplete;
    radioButton?.click();

    expect(radioButton?.checked).toBe(false);
  });

  it('should emit adc-focus event after focus', async () => {
    const dispatchEventStub = vi.fn();
    radioButton.dispatchEvent = dispatchEventStub;

    const input = radioButton?.shadowRoot?.querySelector('input');

    input?.focus();

    await radioButton?.updateComplete;

    expect(dispatchEventStub.mock.calls[0][0].type).toBe('adc-focus');
  });

  it('should emit adc-blur event after blur', async () => {
    const dispatchEventStub = vi.fn();
    radioButton.dispatchEvent = dispatchEventStub;

    const input = radioButton?.shadowRoot?.querySelector('input');

    input?.focus();
    input?.blur();

    await radioButton?.updateComplete;

    expect(dispatchEventStub.mock.calls[1][0].type).toBe('adc-blur');
  });

  it('should invalid be true after calling handleInvalid', async () => {
    radioButton?.handleInvalid();

    await radioButton?.updateComplete;

    expect(radioButton?.invalid).toBe(true);
  });

  it('should focus the inner input', async () => {
    const input = radioButton.shadowRoot?.querySelector('input');
    const focusStub = vi.fn();

    input?.addEventListener('focus', focusStub, { once: true });

    radioButton?.focus();
    await radioButton?.updateComplete;

    expect(focusStub).toHaveBeenCalled();
  });

  it('should blur the inner input', async () => {
    const input = radioButton?.shadowRoot?.querySelector('input');
    const blurStub = vi.fn();

    input?.addEventListener('blur', blurStub, { once: true });

    radioButton?.focus();
    await radioButton?.updateComplete;

    radioButton?.blur();
    await radioButton?.updateComplete;

    expect(blurStub).toHaveBeenCalled();
  });

  it('should has aria-disabled=true when disabled is true', async () => {
    radioButton.disabled = true;
    await radioButton?.updateComplete;
    expect(radioButton?.getAttribute('aria-disabled')).toBe('true');
  });

  it('should has aria-disabled=false when disabled is false', async () => {
    radioButton.disabled = true;
    await radioButton?.updateComplete;
    radioButton.disabled = false;
    await radioButton?.updateComplete;
    expect(radioButton?.getAttribute('aria-disabled')).toBe('false');
  });

  it('should call reportValidity', async () => {
    const input = radioButton?.shadowRoot?.querySelector(
      'input'
    ) as HTMLInputElement;
    const reportValidityStub = vi.fn();

    input.reportValidity = reportValidityStub;

    radioButton?.reportValidity();
    await radioButton?.updateComplete;

    expect(reportValidityStub).toHaveBeenCalled();
  });

  it('should call checkValidity', async () => {
    const input = radioButton?.shadowRoot?.querySelector(
      'input'
    ) as HTMLInputElement;
    const checkValidityStub = vi.fn();

    input.checkValidity = checkValidityStub;

    radioButton?.checkValidity();
    await radioButton?.updateComplete;

    expect(checkValidityStub).toHaveBeenCalled();
  });

  it('should call setCustomValidity', async () => {
    const input = radioButton?.shadowRoot?.querySelector(
      'input'
    ) as HTMLInputElement;
    const setCustomValidityStub = vi.fn();

    input.setCustomValidity = setCustomValidityStub;

    radioButton?.setCustomValidity('invalid');
    await radioButton?.updateComplete;

    expect(setCustomValidityStub).toHaveBeenCalledWith('invalid');
  });

  it('should change radioButtonGroup value', async () => {
    radioButton = document.querySelector('#Radio2') as RadioButton;
    radioButtonGroup.required = true;
    radioButton.click();
    await radioButtonGroup.updateComplete;

    expect(radioButtonGroup.value).toBe('radio_button_02');
  });
});
