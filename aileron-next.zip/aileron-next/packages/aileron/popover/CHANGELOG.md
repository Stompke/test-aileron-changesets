# @aileron/popover

## 0.1.5-next.0

### Patch Changes

- d41e2d29: version bump
- Updated dependencies [d41e2d29]
  - @aileron/button-icon@1.7.5-next.0

## 0.1.4

### Patch Changes

- 6ddd465c: fix: update the styles of multiple components
- Updated dependencies [1f298c59]
- Updated dependencies [cedc7699]
  - @aileron/button-icon@1.7.4
