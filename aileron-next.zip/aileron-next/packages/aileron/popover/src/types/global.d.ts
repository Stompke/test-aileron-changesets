import { Popover } from './popover';

declare global {
  interface HTMLElementTagNameMap {
    'adc-popover': Popover;
  }
}
