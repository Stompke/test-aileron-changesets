import type { Popover } from './popover';
import './popover';

describe('<adc-popover-mark>', () => {
  let popover: Popover;
  beforeEach(() => {
    document.body.innerHTML = `
      <div>
        <adc-button>Popover anchor</adc-button>
        <adc-popover>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut blandit eu pellentesque egestas adipiscing vel viverra posuere ipsum. Ut vulputate risus amet id et proin.
        </adc-popover>
      </div>
    `;
    popover = document.querySelector('adc-popover');
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(popover?.nodeType).toBe(1);
    });
    it('should render default popover', () => {
      expect(popover?.placement).toBe('bottom');
      expect(popover?.heading).toBe('');
      expect(popover?.showing).toBe(true);
      expect(popover?.closeLabelText).toBe('Close Modal');
      expect(popover?.kind).toBe('primary');
    });
    it('should display a close-button', () => {
      const closeButton = popover?.shadowRoot?.querySelector('adc-button-icon');
      expect(closeButton).not.toBeNull();
    });
  });
  describe('when properties has been settled', () => {
    it('should display popover content after focus on previous element sibling', async () => {
      popover.focus();
      await popover.updateComplete;
      expect(popover.showing).toBe(true);
    });
    it('should hide popover content after click on close-button', async () => {
      popover.showing = true;
      await popover.updateComplete;
      const closeButton = popover?.shadowRoot?.querySelector(
        'adc-button-icon'
      ) as HTMLButtonElement;
      closeButton?.click();
      await popover.updateComplete;
      expect(popover.showing).toBe(false);
    });
    it('should display a header', async () => {
      popover.heading = 'This is a Heading';
      await popover.updateComplete;
      const header = popover?.shadowRoot?.querySelector('#header');
      expect(header).not.toBeNull();
    });
  });
});
