import './popover';
import '@aileron/button';
import { html, TemplateResult } from 'lit-html';
import { ifDefined } from 'lit-html/directives/if-defined.js';
import { Placement } from '@floating-ui/dom';

export default {
  title: 'Components/Popover',
  component: 'adc-popover',
  parameters: {
    actions: {
      handles: ['adc-show', 'adc-hide', 'adc-close-popover'],
    },
  },
  args: {
    heading: 'Have an AAdvantage® account?',
    content: 'Log in here.',
    kind: 'primary',
    placement: 'bottom',
  },
  argTypes: {
    heading: {
      type: {
        name: 'heading',
        required: false,
      },
      table: {
        type: {
          summary: 'string',
        },
        defaultValue: { heading: '' },
      },
      control: { type: 'text' },
    },
    content: {
      type: {
        name: 'content',
        required: false,
      },
      table: {
        type: {
          label: 'string',
        },
        defaultValue: {
          content:
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut blandit eu pellentesque egestas adipiscing vel viverra posuere ipsum. Ut vulputate risus amet id et proin.',
        },
      },
      control: { type: 'text' },
    },
    kind: {
      type: {
        name: 'kind',
        required: false,
      },
      table: {
        type: {
          label: 'string',
        },
        defaultValue: {
          content: 'primary',
        },
      },
      control: { type: 'text' },
    },
    placement: {
      type: {
        name: 'placement',
        required: false,
      },
      table: {
        type: {
          label: 'string',
        },
        defaultValue: {
          content: 'bottom',
        },
      },
      control: { type: 'text' },
    },
  },
};

interface Properties {
  heading?: string;
  content?: string;
  kind?: 'primary' | 'secondary';
  placement?: Placement;
}

const Template = (
  { heading, content, kind, placement }: Properties = {
    heading: 'Test Heading',
    content:
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut blandit eu pellentesque egestas adipiscing vel viverra posuere ipsum. Ut vulputate risus amet id et proin.',
    kind: 'primary',
    placement: 'bottom',
  }
): TemplateResult => {
  return html`
    <adc-button kind="secondary">Anchor Element</adc-button>
    <adc-popover
      heading="${ifDefined(heading)}"
      kind="${ifDefined(kind)}"
      placement="${ifDefined(placement)}"
    >
      ${content}
    </adc-popover>
  `;
};

export const Default = (args?: Properties): TemplateResult => Template(args);
