import '@aileron/button-icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { emit } from '@aileron/shared/event';
import { Float } from '@aileron/shared/float';
import type { Placement } from '@floating-ui/dom';
import { html } from 'lit';
import { property, queryAsync, query } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { PropertyValues } from 'lit';

/**
 * Popover
 * @element adc-popover
 * @summary Popovers are a modal that is anchored to an element similar to a tooltip but the
 * user can interact with the content.
 * @fires {CustomEvent} adc-hide - Event fired when the popover is hidden.
 * @fires {CustomEvent} adc-finish-hide - Event fired after the popover is hidden.
 * @fires {CustomEvent} adc-close - Event fired when the popover is closed.
 */
export class Popover extends AileronElement {
  /**
   * @private
   */
  static styles = [AileronElement.styles || [], styles];

  /**
   * @private
   */
  @query('.adc-popover') popoverDiv!: HTMLElement;

  /**
   * @private
   */
  private float!: Float;

  /**
   * The Heading Text for the Popover.
   * @attr {string} [heading]
   * @type {string}
   */
  @property({ reflect: true, type: String })
  heading = '';

  /**
   * Boolean tied to the Popover showing.
   * @ignore
   */
  @property({ reflect: true, type: Boolean })
  showing = true;

  /**
   * Boolean tied to the Popover showing.
   * @ignore
   */
  @property({ reflect: true, type: String, attribute: 'close-label-text' })
  closeLabelText = 'Close Modal';

  /**
   * Determines the Popover's kind. Changing value will adjust the color theme
   * @type {"primary"|"secondary"}
   */
  @property({ reflect: true })
  kind: 'primary' | 'secondary' = 'primary';

  /**
   * Arrow element for tooltip
   * @private
   */
  @queryAsync('#arrow') private readonly _arrow!: HTMLElement;

  /**
   * @private
   */
  _target: Element | null = null;

  /**
   * The placement position for the tooltip. ("top", "bottom", "left", "right")
   * @attr {string} [placement]
   * @type {Placement}
   */
  @property({ reflect: true })
  placement: Placement = 'bottom';

  constructor() {
    super();
    // Finish hiding at end of animation
    this.addEventListener('adc-hide', this.finishHide);
  }

  async connectedCallback() {
    super.connectedCallback();

    const arrow = await this._arrow;
    this.target ??= this.previousElementSibling || null;

    // Setup float with elements
    this.float = new Float(this.popoverDiv, this._target, arrow);
    this.float.activate(this.placement);
    this.showing = true;
    this.style.cssText = '';
  }

  render() {
    return html`
      <div
        class="adc-popover inline-block absolute p-4 rounded bg-neutral-140 opacity-0 w-auto gap-4 text-left z-[1] shadow-lg max-w-[290px] ${classMap(
          {
            'opacity-100': this.showing,
            'bg-blue-060': this.kind === 'secondary',
          }
        )}"
      >
        <div exportparts="header-container" class="flex justify-between">
          ${this.heading &&
          html`<span
            id="header"
            exportparts="header"
            class="font-sans font-regular text-xl line-height-6 text-left mt-0.5 mr-[21px] mb-0 ml-0 text-neutral-010 flex self-center ${classMap(
              { 'text-neutral-140': this.kind === 'secondary' }
            )}"
            >${this.heading}</span
          >`}
          <adc-button-icon
            exportparts="icon"
            class="close-btn ${classMap({
              'text-neutral-140': this.kind === 'secondary',
            })}"
            kind="ghost"
            size="sm"
            icon="action:close"
            outlined
            label-text="${this.closeLabelText}"
            @click=${this.handleClick}
          ></adc-button-icon>
        </div>
        <span
          exportparts="content"
          class="font-sans font-bold text-xl line-height-6 text-left text-neutral-010 ${classMap(
            {
              'text-neutral-140': this.kind === 'secondary',
            }
          )}"
        >
          <slot></slot>
        </span>
        <div
          exportparts="arrow"
          id="arrow"
          class="absolute w-2.5 h-2.5 bg-neutral-140 ${classMap({
            'bg-blue-060': this.kind === 'secondary',
          })}"
        ></div>
      </div>
    `;
  }

  /**
   * @private
   */
  get target() {
    return this._target;
  }

  /**
   * @private
   */
  set target(target: Element | null) {
    this._target = target;
  }

  handleClick() {
    this.hide();
    emit(this, 'adc-close-popover');
  }

  /**
   * Function to hide Popover
   * @private
   */
  hide = () => {
    this.showing = false;
    emit(this, 'adc-hide');
  };

  /**
   * Function to finish hiding Popover after transition.
   * @private
   */
  finishHide = () => {
    if (!this.showing) {
      this.style.display = 'none';
      emit(this, 'adc-finish-hide');
    }
  };

  async updated(changedProperties: PropertyValues) {
    const arrow = await this._arrow;
    this.target ??= this.previousElementSibling;
    if (changedProperties.has('type') || changedProperties.has('toggle')) {
      this.float = new Float(this.popoverDiv, this._target, arrow);
    }
  }
}

try {
  customElements.define('adc-popover', Popover);
} catch (e) {
  // do nothing
}
