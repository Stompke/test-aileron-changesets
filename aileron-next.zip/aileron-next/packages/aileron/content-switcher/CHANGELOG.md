# @aileron/content-switcher

## 1.6.5-next.1

### Patch Changes

- aa9a1865: fix(content-switch): added parts for all html elements

## 1.6.5-next.0

### Patch Changes

- d41e2d29: version bump

## 1.6.4

### Patch Changes

- 6ddd465c: fix: update the styles of multiple components
- cedc7699: fix: update all components for eslint
