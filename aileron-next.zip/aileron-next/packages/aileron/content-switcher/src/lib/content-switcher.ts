import { AileronElement } from '@aileron/shared/aileron-element';
import { getActiveElement } from '@aileron/shared/get-active-element';
import { HostListener, HostListenerMixin } from '@aileron/shared/host-listener';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';
import type { ContentSwitchPanel } from './content-switch-panel';
import type { ContentSwitch } from './content-switch';

/**
 * Sets the available arrow keys to move focus to the next/previous
 */
const availableArrowsByDirection: Record<string, string[]> = {
  horizontal: ['ArrowLeft', 'ArrowRight'],
};

/**
 * Content switcher
 * @element adc-content-switcher
 * @summary A group of content switches that allow the user to toggle between different views.
 * @slot default - expects adc-switch's.
 * @slot adc-content-switch-panel - Slot for the content switch panel.
 * @fires {CustomEvent} change - Fires when the selected content switch changes.
 * @fires {CustomEvent} keydown - Fires when content switch is clicked.
 * @attr {boolean} [auto=false] - Sets the ability to move focus to the next/previous element by arrow keys
 * @attr {boolean} [disabled=false] - Sets disabled to the entire content switcher
 * @attr {string} [label=''] - Sets the label for the content switcher
 * @attr {string} [selected=''] - Sets the selected content switch and panel.
 */
export class ContentSwitcher extends HostListenerMixin(AileronElement) {
  static styles = [AileronElement.styles || [], styles];

  @property({ type: Boolean }) auto = false;
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * @ignore
   */
  @property() label = '';
  @property({ reflect: true })
  get selected(): string {
    return this._selected;
  }

  set selected(value: string) {
    const oldValue = this.selected;

    if (value === oldValue) {
      return;
    }

    this._selected = value;
    this.shouldUpdateCheckedState();
    this.requestUpdate('selected', oldValue);
  }

  /**
   * @ignore
   */
  @HostListener('window:resize')
  // @ts-expect-error - HostListener not used for calls
  private readonly _handleResize = async () => {
    const { contentSwitch } = this.constructor as typeof ContentSwitcher;
    const _arr: number[] = [];

    await this.updateComplete;

    if (!this._width) {
      this.querySelectorAll(contentSwitch).forEach((el: Element) => {
        _arr.push(el.getBoundingClientRect().width);
      });

      this._width = Math.max(..._arr);
    }

    if (window.matchMedia('(min-width:672px)')?.matches) {
      this.querySelectorAll(contentSwitch).forEach(
        (el: any) => (el.style.width = `${this._width}px`)
      );
    } else {
      this.querySelectorAll(contentSwitch).forEach(
        (el: any) => (el.style.width = '50%')
      );
    }
  };

  /**
   * @ignore
   */
  private _selected = '';

  /**
   * @ignore
   */
  private _width!: number;

  /**
   * @ignore
   */
  private contentSwitcher: ContentSwitch[] = [];

  /**
   * @ignore
   */
  get focusElement(): ContentSwitch | this {
    const focusElement = this.contentSwitcher.find(
      (s) => !s.disabled && (s.selected || s.value === this.selected)
    );

    if (focusElement) {
      return focusElement;
    }

    const fallback = this.contentSwitcher.find((s) => !s.disabled);

    return fallback || this;
  }

  manageAutoFocus(): void {
    const contentSwitcher = [...(this.children as any)] as ContentSwitch[];
    const contentSwitchUpdateCompletes = contentSwitcher.map((s) => {
      if (typeof s.updateComplete !== 'undefined') {
        return s.updateComplete;
      }

      return Promise.resolve();
    });

    Promise.all<unknown>(contentSwitchUpdateCompletes).then(() => {
      if (this.autofocus) {
        this.dispatchEvent(new KeyboardEvent('keydown', { code: 'Tab' }));
        this.focusElement.focus();
      }
    });
  }

  managePanels({ target }: Event & { target: HTMLSlotElement }): void {
    const panels = target.assignedElements() as unknown as ContentSwitchPanel[];

    panels.map((panel) => {
      const { value, id } = panel;
      const contentSwitch = this.querySelector(
        `[role="content-switch"][value="${value}"]`
      );

      if (contentSwitch) {
        contentSwitch.setAttribute('aria-controls', id);
        panel.setAttribute('aria-labelledby', contentSwitch.id);
      }

      panel.selected = value === this.selected;
    });
  }

  render(): TemplateResult {
    return html`
      <div
        part="container"
        aria-label=${ifDefined(this.label ? this.label : undefined)}
        @click=${this.onClick}
        @keydown=${this.onKeyDown}
        @mousedown=${this.manageFocusinType}
        @focusin=${this.startListeningToKeyboard}
        class="flex justify-start m-0 relative align-top z-0 items-stretch ${classMap(
          { 'pointer-events-none': this.disabled }
        )}"
        id="content-switch-list"
        role="tablist"
      >
        <slot @slotchange=${this.onSlotChange}></slot>
      </div>
      <slot
        name="adc-content-switch-panel"
        @slotchange=${this.managePanels}
      ></slot>
    `;
  }

  firstUpdated(changes: PropertyValues): void {
    super.firstUpdated(changes);

    const selectedChild = this.querySelector(
      '[selected]'
    ) as unknown as ContentSwitch;
    if (selectedChild) {
      this.selectTarget(selectedChild);
    }
  }

  updated(changes: PropertyValues<this>): void {
    if (changes.has('selected')) {
      if (changes.get('selected')) {
        const previous = this.querySelector(
          `[role="tabpanel"][value="${changes.get('selected')}"]`
        ) as unknown as ContentSwitchPanel;

        if (previous) {
          previous.selected = false;
        }
      }

      const next = this.querySelector(
        `[role="tabpanel"][value="${this.selected}"]`
      ) as unknown as ContentSwitchPanel;

      if (next) {
        next.selected = true;
      }
    }
    if (changes.has('disabled')) {
      const contentSwitches = this.querySelectorAll('[role="tab"]');

      if (this.disabled) {
        this.setAttribute('aria-disabled', 'true');
        contentSwitches.forEach((s) => s.setAttribute('disabled', 'true'));
      } else {
        this.removeAttribute('aria-disabled');
        contentSwitches.forEach((s) => s.removeAttribute('disabled'));
      }
    }

    super.updated(changes);
  }

  /**
   * @private
   * @ignore
   */
  private async _determineSwitchWidth() {
    const { contentSwitch } = this.constructor as typeof ContentSwitcher;
    const _arr: number[] = [];

    await this.updateComplete;

    this.querySelectorAll(contentSwitch).forEach((el: Element) => {
      _arr.push(el.getBoundingClientRect().width);
    });

    if (!this._width) {
      this.querySelectorAll(contentSwitch).forEach((el: Element) => {
        _arr.push(el.getBoundingClientRect().width);
      });

      this._width = Math.max(..._arr);
    }
    if (window.matchMedia('(min-width:672px)')?.matches) {
      this.querySelectorAll(contentSwitch).forEach(
        (el: any) => (el.style.width = `${this._width}px`)
      );
    } else {
      this.querySelectorAll(contentSwitch).forEach(
        (el: any) => (el.style.width = '50%')
      );
    }
  }

  /**
   * @ignore
   */
  private shouldSetFocusVisible = false;

  /**
   * @ignore
   */
  private readonly manageFocusinType = (): void => {
    if (this.shouldSetFocusVisible) {
      return;
    }

    const handleFocus = (): void => {
      this.shouldSetFocusVisible = false;
      this.removeEventListener('focusin', handleFocus);
    };

    this.addEventListener('focusin', handleFocus);
  };

  /**
   * handler to start listening to keyboard events
   */
  startListeningToKeyboard(): void {
    this.addEventListener('keydown', this.handleKeydown);
    this.shouldSetFocusVisible = true;

    const selected = this.querySelector(
      '[selected]'
    ) as unknown as ContentSwitch;

    if (selected) {
      selected.tabIndex = -1;
    }

    const stopListeningToKeyboard = (): void => {
      this.removeEventListener('keydown', this.handleKeydown);
      this.shouldSetFocusVisible = false;

      const selectedHtmlElement = this.querySelector(
        '[selected]'
      ) as unknown as ContentSwitch;

      if (selectedHtmlElement) {
        selected.tabIndex = 0;
      }

      this.removeEventListener('focusout', stopListeningToKeyboard);
    };

    this.addEventListener('focusout', stopListeningToKeyboard);
  }

  /**
   * method to handle keydown event
   */
  handleKeydown(event: KeyboardEvent): void {
    const { code } = event;
    const availableArrows = [...availableArrowsByDirection['horizontal']];
    if (!availableArrows.includes(code)) {
      return;
    }

    event.preventDefault();
    const currentFocusedContentSwitcher = getActiveElement(
      this
    ) as unknown as ContentSwitch;
    let currentFocusedContentSwitcherIndex = this.contentSwitcher.indexOf(
      currentFocusedContentSwitcher
    );
    currentFocusedContentSwitcherIndex += code === availableArrows[0] ? -1 : 1;

    const nextContentSwitch =
      this.contentSwitcher[
        (currentFocusedContentSwitcherIndex + this.contentSwitcher.length) %
          this.contentSwitcher.length
      ];
    nextContentSwitch.focus();
    if (this.auto) {
      this.selected = nextContentSwitch.value;
    }
  }

  /**
   * @ignore
   */
  private readonly onClick = (event: Event): void => {
    const target = event.target as unknown as ContentSwitch;

    if (this.disabled || target.disabled) {
      return;
    }

    this.selectTarget(target);
    if (this.shouldSetFocusVisible && event.composedPath()[0] !== this) {
      this.dispatchEvent(
        new KeyboardEvent('keydown', {
          code: 'Tab',
        })
      );

      target.focus();
    }
  };

  /**
   * @ignore
   */
  private readonly onKeyDown = (event: KeyboardEvent): void => {
    if (event.code === 'Enter' || event.code === 'Space') {
      event.preventDefault();
      const target = event.target as HTMLElement;

      if (target) {
        this.selectTarget(target);
      }
    }
  };

  /**
   * @ignore
   */
  private selectTarget(target: HTMLElement): void {
    const value = target.getAttribute('value');

    if (value) {
      const selected = this.selected;
      this.selected = value;

      const applyDefault = this.dispatchEvent(
        new Event('change', {
          cancelable: true,
        })
      );

      if (!applyDefault) {
        this.selected = selected;
      }
    }
  }

  /**
   * @ignore
   */
  private onSlotChange(): void {
    this.contentSwitcher = [
      ...(this.querySelectorAll('[role="tab"]') as any),
    ] as ContentSwitch[];
    this.shouldUpdateCheckedState();
  }

  /**
   * @ignore
   */
  private shouldUpdateCheckedState(): void {
    this.contentSwitchChangeResolver();
    this.contentSwitchChangePromise = new Promise(
      (res) => (this.contentSwitchChangeResolver = res)
    );

    setTimeout(this.updateCheckedState);
  }

  /**
   * @ignore
   */
  private readonly updateCheckedState = (): void => {
    if (!this.contentSwitcher.length) {
      this.contentSwitcher = [
        ...(this.querySelectorAll('[role="tab"]') as any),
      ] as ContentSwitch[];
    }

    this.contentSwitcher.forEach((element) => {
      element.removeAttribute('selected');
    });

    if (this.selected) {
      const currentlyChecked = this.contentSwitcher.find(
        (el) => el.value === this.selected
      );

      if (currentlyChecked) {
        currentlyChecked.selected = true;
      } else {
        this.selected = '';
      }
    } else {
      const firstContentSwitcher = this.contentSwitcher[0];

      if (firstContentSwitcher) {
        firstContentSwitcher.setAttribute('tabindex', '0');
      }
    }

    this.contentSwitchChangeResolver();
  };

  connectedCallback() {
    super.connectedCallback();

    this._determineSwitchWidth();
  }

  /**
   * @ignore
   */
  static get contentSwitch(): string {
    return 'adc-content-switch';
  }

  /**
   * @ignore
   */
  private contentSwitchChangePromise = Promise.resolve();

  /**
   * @ignore
   */
  private contentSwitchChangeResolver: () => void = function () {
    return;
  };

  /**
   * @ignore
   */
  async getUpdateComplete(): Promise<boolean> {
    const complete = await super.getUpdateComplete();
    await this.contentSwitchChangePromise;

    return complete;
  }
}

try {
  customElements.define('adc-content-switcher', ContentSwitcher);
} catch (e) {
  // do nothing
}
