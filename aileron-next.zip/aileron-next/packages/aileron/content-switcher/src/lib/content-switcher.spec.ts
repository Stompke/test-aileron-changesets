import type { ContentSwitch, ContentSwitcher } from '../index';
import '../index';

describe('<adc-content-switch>', () => {
  let firstContentSwitch: ContentSwitch;
  let secondContentSwitch: ContentSwitch;
  let contentSwitcher: ContentSwitcher;
  beforeEach(() => {
    document.body.innerHTML = `
    <adc-content-switcher>
      <adc-content-switch selected value="first" label="first" id="first">first</adc-content-switch>
      <adc-content-switch value="second" id="second">really really really long second</adc-content-switch>
      <adc-content-switch-panel selected value="first">
        <adc-grid>
          <adc-row has-form>
            <adc-column col-desktop="4">
              <adc-text-input label-text="test"></adc-text-input>
            </adc-column>
            <adc-column col-desktop="4">
              <adc-text-input label-text="test 2"></adc-text-input>
            </adc-column>
            <adc-column col-desktop="4">
              <adc-text-input label-text="test 3"></adc-text-input>
            </adc-column>
          </adc-row>
        </adc-grid>
      </adc-content-switch-panel>
      <adc-content-switch-panel value="second">Second Panel</adc-content-switch-panel>
    </adc-content-switcher>
    `;
    firstContentSwitch = document.querySelector(
      'adc-content-switch#first'
    ) as unknown as ContentSwitch;
    secondContentSwitch = document.querySelector(
      'adc-content-switch#second'
    ) as unknown as ContentSwitch;
    contentSwitcher = document.querySelector('adc-content-switcher');
  });
  it('should render default content switch', async () => {
    secondContentSwitch.requestUpdate();
    await secondContentSwitch.updateComplete;
    expect(secondContentSwitch?.selected).toBe(false);
    expect(secondContentSwitch?.getAttribute('aria-selected')).toBe('false');
    expect(secondContentSwitch?.getAttribute('tabindex')).toBe('-1');
    expect(secondContentSwitch?.disabled).toBe(false);
    expect(secondContentSwitch?.label).toBe('');
  });

  it('should disable the switch by attribute', async () => {
    firstContentSwitch.disabled = true;
    firstContentSwitch.requestUpdate();
    await firstContentSwitch?.updateComplete;
    expect(firstContentSwitch?.disabled).toBe(true);
  });

  it('should add aria-disabled when disabled is true', async () => {
    contentSwitcher.disabled = true;
    contentSwitcher?.requestUpdate();
    await contentSwitcher?.updateComplete;
    expect(contentSwitcher?.getAttribute('aria-disabled')).toBe('true');
  });

  it('should select the switch by attribute', () => {
    expect(firstContentSwitch?.selected).toBe(true);
  });

  it('should render a label', () => {
    expect(firstContentSwitch?.label).toBe('first');
  });
  it('should switch second panel when click on it', async () => {
    firstContentSwitch.disabled = false;
    contentSwitcher.disabled = false;
    await contentSwitcher.updateComplete;
    secondContentSwitch.click();
    secondContentSwitch.requestUpdate();
    expect(contentSwitcher?.selected).toBe('second');
  });
});
