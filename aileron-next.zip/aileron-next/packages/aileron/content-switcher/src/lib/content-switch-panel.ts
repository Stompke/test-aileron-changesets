import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';

/**
 * Content switch panel
 * @element adc-content-panel
 * @summary Content for a selected content switch when used within a content switcher context.
 * @slot default - Default slot.
 * @attr {boolean} [selected=false] - Sets the panel to selected.
 * @attr {string} [value=""] - Sets the value, should match with the switch.
 * @attr {string} [id=""] - Sets the id of the panel.
 *
 */
export class ContentSwitchPanel extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * Sets the panel to selected.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) selected = false;

  /**
   * Sets the value, should match with the switch.
   * @type {string}
   */
  @property({ reflect: true }) value = '';

  /**
   * Sets the id of the panel.
   * @type {string}
   */
  @property({ reflect: true }) id = '';

  protected render(): TemplateResult {
    return html`<div
      part="panel"
      class="
      font-sans
      font-regular
      text-base
      line-height-6
      text-neutral-000
      box-border
      after:absolute
      after:box-border
      after:w-full
      after:h-full
      after:top-0
      after:left-0
      after:border
      after:border-solid
      after:border-transparent
      after:pointer-events-none
      ${classMap({ block: this.selected, hidden: !this.selected })}"
    >
      <slot></slot>
    </div>`;
  }

  protected firstUpdated(): void {
    this.slot = 'adc-content-switch-panel';
    this.setAttribute('role', 'tabpanel');
    this.tabIndex = 0;

    if (!this.hasAttribute('id')) {
      this.id = `adc-content-switch-panel-${ContentSwitchPanel.instanceCount++}`;
    }
  }

  protected updated(changes: PropertyValues<this>): void {
    if (changes.has('selected')) {
      if (this.selected) {
        this.removeAttribute('aria-hidden');
        this.tabIndex = 0;
      } else {
        this.setAttribute('aria-hidden', 'true');
        this.tabIndex = -1;
      }
    }
  }

  /**
   * Keeps track the instance the switch is related to.
   */
  static instanceCount = 0;
}

try {
  customElements.define('adc-content-switch-panel', ContentSwitchPanel);
} catch (e) {
  // do nothing
}
