import { AileronElement } from '@aileron/shared/aileron-element';
import { FocusVisiblePolyfillMixin } from '@aileron/shared/focus-visible';
import {
  ObserveSlotPresence,
  ObserveSlotText,
} from '@aileron/shared/observe-slot';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';

/**
 * Content switch
 * @element adc-content-switch
 * @summary The singular switch that makes up the selection button group.
 * @slot default - Default slot.
 * @attr {string} [label=""] - Sets the button text label.
 * @attr {boolean} [disabled=false] - Sets the content switch to disabled.
 * @attr {boolean} [selected=false] - Sets the content switch to selected.
 * @attr {string} [value=""] - Sets the value of the content switch, this maps to the `content-switch-panel`
 */
export class ContentSwitch extends FocusVisiblePolyfillMixin(
  ObserveSlotText(ObserveSlotPresence(AileronElement, '[slot="icon"]'), '')
) {
  static styles = [AileronElement.styles || [], styles];

  /**
   * Used to detect content and set switch to hidden.
   */
  protected get hasLabel(): boolean {
    return !!this.label || this.slotHasContent;
  }

  /**
   * Sets the button text label.
   * @type {string}
   */
  @property({ reflect: true }) label = '';

  /**
   * Sets the content switch to disabled.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * Sets the content switch to selected.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) selected = false;

  /**
   * Sets the value of the content switch, this maps to the
   * `content-switch-panel`
   * @type {string}
   */
  @property({ reflect: true }) value = '';

  protected render(): TemplateResult {
    return html`<div
      part="switch"
      class="
      items-center
      box-border
      text-blue-060
      cursor-pointer
      inline-flex
      flex-shrink
      min-h-8
      justify-center
      outline-0
      py-0
      px-4
      relative
      text-center
      whitespace-nowrap
      z-[1]
      w-full
      hover:underline
      md:whitespace-nowrap
      ${classMap({
        'cursor-default': this.disabled,
        'pointer-events-none': this.disabled,
        'bg-blue-060': this.selected && !this.disabled,
        'text-neutral-140': this.selected,
        'focus-visible:underline': this.selected,
        'hover:bg-neutral-130': !this.selected && !this.disabled,
        'bg-neutral-120': this.disabled,
        'text-neutral-090': this.disabled,
      })}"
    >
      <label
        part="switch__label"
        class="font-sans font-bold text-sm line-height-4 antialiased box-border cursor-pointer block flex-grow justify-center outline-0 relative text-center z-[1] first-letter:capitalize"
        id="content-switchLabel"
        ?hidden=${!this.hasLabel}
      >
        ${this.slotHasContent ? html`` : this.label}
        <slot>${this.label}</slot>
      </label>
    </div>`;
  }

  /**
   * Sets the role on first render to 'tab'. Creates an id for the content
   * switch.
   */
  protected firstUpdated(changes: PropertyValues): void {
    super.firstUpdated(changes);

    this.setAttribute('role', 'tab');
    if (!this.hasAttribute('id')) {
      this.id = `adc-content-switch-${ContentSwitch.instanceCount++}`;
    }
  }

  /**
   * When the content switch is re-rendered, check if the selected or disabled
   * property has changed. If the selected property has, set 'aria-selected' and
   * 'tabindex'. If disabled is set, set 'aria-disabled'.
   */
  protected updated(changes: PropertyValues): void {
    super.updated(changes);

    if (changes.has('selected')) {
      this.setAttribute('aria-selected', this.selected ? 'true' : 'false');
      this.setAttribute('tabindex', this.selected ? '0' : '-1');
    }

    if (changes.has('disabled')) {
      this.setAttribute('aria-disabled', this.disabled ? 'true' : 'false');
    }
  }

  /**
   * Keeps track the instance the switch is related to.
   */
  static instanceCount = 0;
}

try {
  customElements.define('adc-content-switch', ContentSwitch);
} catch (e) {
  // do nothing
}
