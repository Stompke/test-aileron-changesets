import { ContentSwitcher } from './content-switcher';
import { ContentSwitchPanel } from './content-switch-panel.component';
import { ContentSwitch } from './content-switch.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-content-switcher': ContentSwitcher;
    'adc-content-panel': ContentSwitchPanel;
    'adc-content-switch': ContentSwitch;
  }
}
