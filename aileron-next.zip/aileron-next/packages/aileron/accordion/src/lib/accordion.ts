import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Accordion component
 * @element adc-accordion
 * @tag adc-accordion
 * @summary The adc-accordion components accepts a list
 * of adc-accordion-item components as children and each adc-accordion-item
 * is responsible for displaying the accordion's heading and panel content.
 * @slot default - Accepts a list of adc-accordion-item's
 */
export class Accordion extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  render(): TemplateResult {
    return html`<slot></slot>`;
  }

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'list');
    }

    super.connectedCallback();
  }
}

try {
  customElements.define('adc-accordion', Accordion);
} catch (e) {
  // do nothing
}
