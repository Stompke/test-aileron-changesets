import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * @ignore
 */
export const ACCORDION_POSITION = {
  LEFT: 'left',
  RIGHT: 'right',
} as const;

type AccordionPosition =
  (typeof ACCORDION_POSITION)[keyof typeof ACCORDION_POSITION];

/**
 * Accordion item.
 * @element adc-accordion-item
 * @tag adc-accordion-item
 * @summary Accordion Item is responsible for displaying the adc-accordion's heading and panel content.
 * @fires adc-accordion-item-beingtoggled - Event fired when the item is being
 * opened or closed.
 * @fires adc-accordion-item-toggled - Event fired when the item is opened or
 * closed.
 * @slot default - Default slot.
 * @slot label - Slot for the label-text.
 * @csspart content - The content of the item.
 * @csspart title - The title of the item.
 * @csspart expando - The expando of the item.
 * @csspart expando-icon - The expando icon of the item.
 * @parentComponent adc-accordion
 */
export class AccordionItem extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * @ignore
   */
  private _handleUserInitiatedToggle(open = !this.open) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      detail: {
        open,
      },
    };
    /**
     * @ignore
     */
    if (
      this.dispatchEvent(
        new CustomEvent(
          (this.constructor as typeof AccordionItem).eventBeforeToggle,
          init
        )
      )
    ) {
      if (!this.disabled) {
        this.open = open;
        /**
         *
         * @ignore
         */
        this.dispatchEvent(
          new CustomEvent(
            (this.constructor as typeof AccordionItem).eventToggle,
            init
          )
        );
      }
    }
  }

  /**
   * handler method for expanding/collapsing content
   */
  private _handleClickExpando() {
    this._handleUserInitiatedToggle();
  }

  /**
   *
   * @ignore
   */
  private readonly _handleKeydownExpando = ({ key }: KeyboardEvent) => {
    if (this.open && (key === 'Esc' || key === 'Escape')) {
      this._handleUserInitiatedToggle(false);
    }
  };

  /**
   * `true` if the accordion item should be disabled.
   * @attr [disabled]
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * `true` if the accordion item should be open.
   * @attr [open]
   */
  @property({ type: Boolean, reflect: true }) open = false;

  /**
   * The position of the label in relationship to the icon.
   * @type {"left"|"right"}
   * @attr [label-position]
   */
  @property({ reflect: true, attribute: 'label-position' })
  labelPosition: AccordionPosition = ACCORDION_POSITION.RIGHT;

  /**
   * The title of the accordion item.
   * @attr [label-text]
   */
  @property({ attribute: 'label-text' }) labelText = '';

  /**
   * `true` if the accordion item should has border top.
   * @attr [border-top]
   */
  @property({ type: Boolean, attribute: 'border-top' }) borderTop = false;

  /**
   * `true` if the accordion item should has border bottom.
   * @attr [border-bottom]
   */
  @property({ type: Boolean, attribute: 'border-bottom' }) borderBottom = false;

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'listitem');
    }

    super.connectedCallback();
  }

  render(): TemplateResult {
    const {
      disabled,
      open,
      labelPosition,
      labelText,
      _handleClickExpando,
      _handleKeydownExpando,
    } = this;

    return html`<div
      class="flex flex-col border-0 focus-within:border-0 focus-within:outline focus-within:outline-1 focus-within:outline-blue-070 border-x-0 ${classMap(
        {
          'border-solid': this.borderBottom || this.borderTop,
          'border-t': this.borderTop,
          'border-b': this.borderBottom,
          'border-neutral-070': this.borderTop || this.borderBottom,
          'border-blue-070': this.open && (this.borderTop || this.borderBottom),
          '-mt-px': this.borderBottom && this.borderTop,
          relative: this.open && this.borderBottom && this.borderTop,
        }
      )}"
    >
      <button
        ?disabled="${disabled}"
        type="button"
        part="expando"
        class="font-sans font-medium line-height-6 text-base flex bg-neutral-140 items-center py-16 px-0 cursor-pointer hover:underline appearance-none border-none focus:outline-0 height-[58px]${classMap(
          {
            'justify-between': this.labelPosition === ACCORDION_POSITION.LEFT,
            'text-neutral-090': this.disabled,
            'text-blue-060': !this.disabled,
          }
        )}"
        aria-controls="content"
        aria-expanded=${open}
        @click="${_handleClickExpando}"
        @keydown="${_handleKeydownExpando}"
      >
        ${labelPosition === ACCORDION_POSITION.RIGHT
          ? html` <adc-icon
                icon="navigation:chevron-down"
                part="expando-icon"
                size="24"
                class="flex fill-current mx-16 my-0 transition-transform origin-center rotate-1 ${classMap(
                  { 'rotate-180': this.open }
                )}"
              ></adc-icon>
              <span part="title" class="adc-accordion__title">
                <slot name="label">${labelText}</slot>
              </span>`
          : html`
              <span part="title" class="adc-accordion__title">
                <slot name="label">${labelText}</slot>
              </span>
              <adc-icon
                icon="navigation:chevron-down"
                part="expando-icon"
                size="24"
                class="flex fill-current mx-16 my-0 transition-transform origin-center rotate-1 ${classMap(
                  { 'rotate-180': this.open }
                )}"
              ></adc-icon>
            `}
      </button>
      <div
        id="content"
        part="content"
        class="adc-accordion__content--wrapper max-h-0 overflow-hidden bg-neutral-140 ${classMap(
          {
            'max-h-[300vh]': this.open,
            'max-h-0': !this.open,
          }
        )}"
      >
        <div
          class="font-sans text-base font-regular line-height-6 text-neutral-000 pt-0 px-16 pb-16"
        >
          <slot></slot>
        </div>
      </div>
    </div>`;
  }

  /**
   * The name of the custom event fired before this accordion item is being
   * toggled upon a user gesture. Cancellation of this event stops the
   * user-initiated action of toggling this accordion item.
   * @ignore
   */
  static get eventBeforeToggle(): string {
    return 'adc-accordion-item-beingtoggled';
  }

  /**
   * The name of the custom event fired after this accordion item is toggled
   * upon a user gesture.
   * @ignore
   */
  static get eventToggle(): string {
    return 'adc-accordion-item-toggled';
  }
}

try {
  customElements.define('adc-accordion-item', AccordionItem);
} catch (e) {
  // do nothing
}
