import { Accordion } from './accordion';
import { AccordionItem } from './item.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-accordion': Accordion;
    'adc-accordion-item': AccordionItem;
  }
}
