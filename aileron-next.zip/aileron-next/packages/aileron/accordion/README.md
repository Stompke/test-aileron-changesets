# @aileron/accordion

### For Accordion documentation, please visit [our documentation page here](https://animated-doodle-g3kyvlm.pages.github.io/components/accordion/).

### For Accordion Item documentation, please visit [our documentation page here](https://animated-doodle-g3kyvlm.pages.github.io/components/accordion-item/).

