import { defineConfig } from 'vite';
import ViteTsConfigPathsPlugin from 'vite-tsconfig-paths';
import replace from '@rollup/plugin-replace';
import { env } from 'process';
import pkg from './package.json';

// https://vitejs.dev/config/
export default defineConfig({
  build: {
    lib: {
      entry: 'src/index.ts',
      name: '@aileron/accordion',
      fileName: () => `accordion.js`,
    },
    rollupOptions: {
      output: [
        {
          name: '@aileron/accordion',
          dir: `dist/packages/aileron/accordion/dist/accordion@${env.NODE_ENV === 'production' ? 'latest' : 'next'}`,
          format: 'umd',
        },
        {
          name: '@aileron/accordion',
          dir: `dist/packages/aileron/accordion/dist/accordion@${pkg.version}`,
          format: 'umd',
        },
      ],
      plugins: [
        replace({
          'process.env.NODE_ENV': JSON.stringify('production'),
          preventAssignment: true,
        }),
      ],
    },
  },
  plugins: [
    ViteTsConfigPathsPlugin({
      root: '../../../',
    }),
  ],
});
