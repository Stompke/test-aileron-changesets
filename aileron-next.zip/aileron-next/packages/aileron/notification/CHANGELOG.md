# @aileron/notification

## 1.5.5-next.0

### Patch Changes

- d41e2d29: version bump
- Updated dependencies [d41e2d29]
  - @aileron/button@1.7.5-next.0
  - @aileron/button-icon@1.7.5-next.0
  - @aileron/divider@2.1.5-next.0
  - @aileron/icon@2.0.1-next.0

## 1.5.4

### Patch Changes

- Updated dependencies [60066416]
- Updated dependencies [1f298c59]
- Updated dependencies [6ddd465c]
- Updated dependencies [cedc7699]
  - @aileron/icon@2.0.0
  - @aileron/button-icon@1.7.4
  - @aileron/button@1.7.4
  - @aileron/divider@2.1.4
