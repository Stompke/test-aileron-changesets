import '@aileron/button';
import '@aileron/button-icon';
import '@aileron/divider';
import '@aileron/icon';
import { closestElement } from '@aileron/shared/closest-element';
import { Tailwind } from '@aileron/shared/tailwind-element';
import { html, LitElement } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { Common } from './common';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

const TailwindLitElement = Tailwind(LitElement);

/**
 * InlineNotification
 * @element adc-inline-notification
 * @summary Used to display alert and status messages to the user.
 * @slot title - slot to set the header title text
 * @fires adc-close - listens for a close event on the tooltip.
 * @attr {string} [title=undefined] - Header Title for the Notification Component
 * @attr {"success" | "information" | "warning" | "error"} [kind='information'] - determines the style of the notification component
 * @attr {boolean} [can-close=false] - Gives the ability to close and remove the notification from the dom
 * @attr {'default' | 'ghost'} [variant='default'] - Gives the inline notification transparent styling if variant set to "ghost"
 */
export class InlineNotification extends Common {
  static styles = [TailwindLitElement.styles || [], styles];

  @property({ reflect: true }) variant = 'default';

  isInline = true;

  render(): TemplateResult {
    const defaultClosest = !!closestElement('.container-default', this);
    const secondaryClosest = !!closestElement('.container-secondary', this);
    const tertiaryClosest = !!closestElement('.container-tertiary', this);
    return html`
      <div
        class="
      rounded
      inline-flex
      justify-left
      align-start
      py-1.5
      px-0
      text-neutral-010
      dark:text-neutral-130
      ${classMap({
          'bg-transparent': this.variant === 'ghost',
          'bg-blue-130':
            this.kind === 'information' &&
            this.variant !== 'ghost' &&
            defaultClosest,
          'dark:bg-blue-010':
            this.kind === 'information' &&
            this.variant !== 'ghost' &&
            defaultClosest,
          'bg-blue-120':
            this.kind === 'information' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'dark:bg-blue-020':
            this.kind === 'information' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'bg-blue-110':
            this.kind === 'information' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'dark:bg-blue-030':
            this.kind === 'information' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'text-blue-060':
            this.kind === 'information' && this.variant === 'ghost',
          'dark:text-blue-080':
            this.kind === 'information' && this.variant === 'ghost',
          'bg-green-130':
            this.kind === 'success' &&
            this.variant !== 'ghost' &&
            defaultClosest,
          'dark:bg-green-010':
            this.kind === 'success' &&
            this.variant !== 'ghost' &&
            defaultClosest,
          'bg-green-120':
            this.kind === 'success' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'dark:bg-green-020':
            this.kind === 'success' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'bg-green-110':
            this.kind === 'success' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'dark:bg-green-030':
            this.kind === 'success' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'text-green-060': this.kind === 'success' && this.variant === 'ghost',
          'dark:text-green-080':
            this.kind === 'success' && this.variant === 'ghost',
          'bg-orange-130': this.kind === 'warning' && this.variant !== 'ghost',
          'dark:bg-orange-010':
            this.kind === 'warning' && this.variant !== 'ghost',
          'bg-orange-120':
            this.kind === 'warning' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'dark:bg-orange-020':
            this.kind === 'warning' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'bg-orange-110':
            this.kind === 'warning' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'dark:bg-orange-030':
            this.kind === 'warning' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'text-orange-060':
            this.kind === 'warning' && this.variant === 'ghost',
          'dark:text-orange-080':
            this.kind === 'warning' && this.variant === 'ghost',
          'bg-red-130': this.kind === 'error' && this.variant !== 'ghost',
          'dark:bg-red-010': this.kind === 'error' && this.variant !== 'ghost',
          'bg-red-120':
            this.kind === 'error' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'dark:bg-red-020':
            this.kind === 'error' &&
            this.variant !== 'ghost' &&
            secondaryClosest,
          'bg-red-110':
            this.kind === 'error' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'dark:bg-red-030':
            this.kind === 'error' &&
            this.variant !== 'ghost' &&
            tertiaryClosest,
          'text-red-060': this.kind === 'error' && this.variant === 'ghost',
          'dark:text-red-080':
            this.kind === 'error' && this.variant === 'ghost',
        })}
    "
      >
        ${this._renderIcon()} ${this._renderTitle()} ${this._renderClose()}
      </div>
    `;
  }
}

try {
  customElements.define('adc-inline-notification', InlineNotification);
} catch (e) {
  // do nothing
}
