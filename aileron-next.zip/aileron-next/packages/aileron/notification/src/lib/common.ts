import '@aileron/button-icon';
import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { emit } from '@aileron/shared/event';
import { HasSlotController } from '@aileron/shared/slot';
import { html } from 'lit';
import { property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import type { TemplateResult } from 'lit';

export const NOTIFICATION_KIND = {
  SUCCESS: 'success',
  INFO: 'information',
  WARNING: 'warning',
  ERROR: 'error',
} as const;

type NotificationKind =
  (typeof NOTIFICATION_KIND)[keyof typeof NOTIFICATION_KIND];

const iconsOfKinds = {
  [NOTIFICATION_KIND.SUCCESS]: html`<adc-icon
    icon="signal:checkmark"
    outlined
    size="32"
  ></adc-icon>`,
  [NOTIFICATION_KIND.INFO]: html`<adc-icon
    icon="signal:information"
    outlined
    size="32"
  ></adc-icon>`,
  [NOTIFICATION_KIND.WARNING]: html`<adc-icon
    icon="signal:warning"
    outlined
    size="32"
  ></adc-icon>`,
  [NOTIFICATION_KIND.ERROR]: html`<adc-icon
    icon="signal:error"
    outlined
    size="32"
  ></adc-icon>`,
};

/**
 * @slot title - slot to set the header title text
 * @fires adc-close - listens for a close event on the tooltip.
 * @attr {string} [title=undefined] - Header Title for the Notification Component
 * @attr {"success" | "information" | "warning" | "error"} [kind='information'] - determines the style of the notification component
 * @attr {boolean} [can-close=false] - Gives the ability to close and remove the notification from the dom
 */
export abstract class Common extends AileronElement {
  /**
   * Used to determine if common is being called by notification or inline-notification
   * @private
   */
  abstract readonly isInline: boolean;

  /**
   * @private
   */
  readonly hasSlotController = new HasSlotController(this, 'title');

  /**
   * @private
   */
  static count = 0;

  /**
   * Sets the aria-label for the close button.
   * @type {string}
   */
  @state() closeLabel = 'Dismiss';

  @property({ reflect: true }) kind: NotificationKind = NOTIFICATION_KIND.INFO;
  @property() title!: string;
  @property({ type: Boolean, attribute: 'can-close' }) canClose = false;

  _renderTitle(): TemplateResult {
    const hasTitle = this.hasSlotController.test('title') || !!this.title;

    return html`
      <div
        class="font-sans font-bold text-base line-height-6 ${classMap({
          'adc-notification__title': !this.isInline,
          hidden: !this.isInline && !hasTitle,
          block: hasTitle && !this.isInline,
          'mt-2': hasTitle || this.isInline,
          'mb-1.5': hasTitle || this.isInline,
          'mr-4': hasTitle && !this.isInline,
          'px-2': this.isInline,
          'adc-inline-notification__title': this.isInline,
        })}"
      >
        <slot name="title">${this.title}</slot>
      </div>
    `;
  }

  _renderClose(): TemplateResult | undefined {
    return this.canClose
      ? html`
          <adc-button-icon
            size="sm"
            id="closeNotification"
            aria-label="${ifDefined(this.closeLabel)}"
            labelText="${ifDefined(this.closeLabel)}"
            icon="action:close"
            @click=${this._handleClose}
            kind="ghost"
            class="${classMap({
              'focus:outline-blue-070': true,
              'pt-0.5': true,
              'mr-1.5': this.isInline,
              'my-0': !this.isInline,
              'mr-3': !this.isInline,
              'ml-0': !this.isInline,
              'cursor-pointer': true,
              'inline-flex': true,
              'border-none': true,
              'bg-transparent': true,
              'px-0': true,
              'pb-0': true,
            })}"
          ></adc-button-icon>
        `
      : undefined;
  }

  _renderIcon(): TemplateResult {
    return html`<div
      class="${classMap({
        'text-blue-070': this.kind === NOTIFICATION_KIND.INFO,
        'text-green-070': this.kind === NOTIFICATION_KIND.SUCCESS,
        'text-orange-070': this.kind === NOTIFICATION_KIND.WARNING,
        'text-red-070': this.kind === NOTIFICATION_KIND.ERROR,
        'inline-flex': true,
        'mt-0.5': true,
        'mx-4': true,
        'mb-0': true,
        'ml-2': this.isInline,
      })}"
    >
      ${iconsOfKinds[this.kind]}
    </div>`;
  }

  /**
   * Sets the role for a11y purposes. Also sets an id for the notification.
   */
  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'alert');
    }

    if (!this.hasAttribute('id')) {
      this.setAttribute('id', `adcNotification_${Common.count++}`);
    }
    super.connectedCallback();
  }

  /**
   * Whenever the close button is clicked, the notification is removed from the
   * DOM.
   */
  _handleClose(): void {
    emit(this, 'adc-close');

    const notification = document.querySelector(`#${this.getAttribute('id')}`);

    if (notification) {
      const parent = notification.parentNode;
      (parent as Element).removeChild(notification);
    }
  }
}
