import '@aileron/button';
import '@aileron/button-icon';
import '@aileron/divider';
import { emit } from '@aileron/shared/event';
import { Tailwind } from '@aileron/shared/tailwind-element';
import { html, LitElement } from 'lit';
import { property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { Common } from './common';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

const TailwindLitElement = Tailwind(LitElement);

/**
 * Notification
 * @element adc-notification
 * @summary Used to display alert and status messages to the user at the page level.
 * @fires adc-expand - listens for an expand event on the tooltip.
 * @fires adc-collapse - listens for a collapse event on the tooltip.
 * @fires adc-close - listens for a close event on the tooltip.
 * @slot default - slot for text body content
 * @slot link - slot for anchor tags
 * @slot title - slot to set the header title text
 * @attr {string} [title=undefined] - Header Title for the Notification Component
 * @attr {"success" | "information" | "warning" | "error"} [kind='information'] - determines the style of the notification component
 * @attr {boolean} [can-close=false] - Gives the ability to close and remove the notification from the dom
 * @attr {boolean} [fullwidth] - Gives the notification full width styling
 * @attr {boolean} [is-collapsible] - Gives collapse/expand functionality
 */
export class Notification extends Common {
  static styles = [TailwindLitElement.styles || [], styles];

  isInline = false;

  @state() open = false;

  @property({ type: Boolean, reflect: true }) fullwidth = false;
  @property({ reflect: true, type: Boolean, attribute: 'is-collapsible' })
  isCollapsible = false;

  _renderFooter(): TemplateResult {
    return html`
      <adc-divider spacing="16" class="pr-4" dashed></adc-divider>
      ${this._renderFooterButtons()}
    `;
  }

  _renderText(): TemplateResult {
    return html`
      <div
        class=${classMap({
          'adc-notification__expand-wrapper': true,
          'max-h-0': true,
          'overflow-hidden': true,
          'adc-notification__no-footer': !this.isCollapsible,
        })}
      >
        <div
          class="font-sans font-regular text-base line-height-6 text-neutral-010 dark:text-neutral-130 flex flex-col grow align-to pr-4"
        >
          <slot></slot>
          <slot name="link"></slot>
        </div>
        ${this.isCollapsible ? this._renderFooter() : ''}
      </div>
    `;
  }

  _renderExpand(): TemplateResult {
    return html`
      <adc-button-icon
        size="sm"
        id="collapse-expand"
        aria-label=${this.open ? 'collapse' : 'expand'}
        labelText=${this.open ? 'collapse' : 'expand'}
        icon="navigation:chevron-down"
        @click=${this._handleOpen}
        kind="ghost"
        class="my-0 mr-3 ml-0 cursor-pointer inline-flex align-start border-none bg-transparent p-0"
      ></adc-button-icon>
    `;
  }

  _renderFooterButtons(): TemplateResult {
    return html`<div
      class="adc-notification__footer-buttons px-0 pt-0 pb-4 flex justify-end"
    >
      ${this.canClose
        ? html`<adc-button
            kind="ghost"
            type="button"
            @click=${this._handleClose}
            id="dismiss-button"
            size="sm"
          >
            ${this.closeLabel}
          </adc-button>`
        : ''}

      <adc-button
        kind="secondary"
        type="button"
        @click=${this._handleOpen}
        id="collapse-button"
        size="sm"
      >
        Collapse
      </adc-button>
    </div>`;
  }

  render(): TemplateResult {
    return html`
      <div
        class="
        bg-neutral-140
        dark:bg-neutral-000
        inline-flex
        pt-3
        px-0
        pb-0
        justify-left
        border
        border-solid
        border-l-2
        rounded-[0.125rem]
      ${classMap({
          'w-full': this.fullwidth,
          'border-blue-070': this.kind === 'information',
          'border-green-070': this.kind === 'success',
          'border-orange-070': this.kind === 'warning',
          'border-red-070': this.kind === 'error',
        })}"
      >
        ${this._renderIcon()}
        <div
          ?open=${this.isCollapsible
            ? this.open
            : this.hasSlotController.test('link') ||
              this.hasSlotController.test('[default]')}
          class="adc-notification__content-wrapper"
        >
          <div
            class=${classMap({
              'adc-notification__title-wrapper': true,
              'text-neutral-010': true,
              'dark:text-neutral-130': true,
              flex: true,
              'justify-between': true,
              grow: true,
              'align-top': true,
              'mb-3': true,
              'adc-notification__has-content':
                this.hasSlotController.test('[default]'),
            })}
          >
            ${this._renderTitle()}
            ${this.isCollapsible ? this._renderExpand() : this._renderClose()}
          </div>
          ${this.hasSlotController.test('link') ||
          this.hasSlotController.test('[default]')
            ? this._renderText()
            : ''}
        </div>
      </div>
    `;
  }

  /**
   * Whenever the expand/collapse button is clicked, the content is collapsed
   * in the DOM.
   */
  _handleOpen() {
    if (this.open) {
      emit(this, 'adc-collapse');
    } else {
      emit(this, 'adc-expand');
    }
    this.open = !this.open;
  }
}

try {
  customElements.define('adc-notification', Notification);
} catch (e) {
  // do nothing
}
