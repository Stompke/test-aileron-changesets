import { Notification } from './notification';
import { InlineNotification } from './inline-notification.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-notification': Notification;
    'adc-inline-notification': InlineNotification;
  }
}
