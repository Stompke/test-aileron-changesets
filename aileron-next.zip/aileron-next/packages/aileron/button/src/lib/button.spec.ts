import type { Button } from './button';
import './button';

const kinds = ['primary', 'secondary', 'ghost'];

describe('<adc-button>', () => {
  let button: Button;
  beforeEach(() => {
    document.body.innerHTML = `<h1>Custom element test</h1> <adc-button></adc-button>`;
    button = document.querySelector('adc-button') as Button;
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(button?.nodeType).toBe(1);
    });

    kinds.forEach((kind) => {
      it(`should be accessible when kind is "${kind}"`, () => {
        button.kind = kind as Button['kind'];
        expect(button?.nodeType).toBe(1);
      });
    });

    it('should have correct default values', () => {
      expect(button?.autofocus).toBe(false);
      expect(button?.disabled).toBe(false);
      expect(button?.kind).toBe('primary');
      expect(button?.labelText).toBe('');
      expect(button?.size).toBe('');
      expect(button?.type).toBe('button');
    });

    it('should render as a <button>', async () => {
      expect(button.shadowRoot?.querySelector('button')).not.toBeNull();
    });
  });

  describe('when disabled', () => {
    it('should be accessible', async () => {
      button.disabled = true;
      await button?.updateComplete;
      expect(button?.nodeType).toBe(1);
    });

    it('should disable the native <button> when rendering a <button>', async () => {
      button.disabled = true;
      button.requestUpdate();
      await button?.updateComplete;
      expect(
        button.shadowRoot?.querySelector('button[disabled]')
      ).not.toBeNull();
    });

    it('should not bubble up clicks', async () => {
      button.disabled = true;
      const handleClickStub = vi.fn();

      button.handleClick = handleClickStub;

      button?.requestUpdate();
      await button?.updateComplete;

      button.shadowRoot?.querySelector('button')?.click();

      expect(handleClickStub).not.toHaveBeenCalled();
    });
  });

  describe('methods', () => {
    it('should emit adc-click event after clicking', async () => {
      const dispatchEventStub = vi.fn();
      button.dispatchEvent = dispatchEventStub;
      const buttonElement = button?.shadowRoot?.querySelector('button');
      buttonElement?.click();

      expect(dispatchEventStub.mock.calls[0][0].type).toBe('adc-click');
    });

    it('should emit adc-focus event after focus', async () => {
      const dispatchEventStub = vi.fn();

      button.dispatchEvent = dispatchEventStub;
      const buttonElement = button?.shadowRoot?.querySelector('button');
      buttonElement?.focus();

      expect(dispatchEventStub).toHaveBeenCalled();
      expect(dispatchEventStub.mock.calls[0][0].type).toBe('adc-focus');
    });

    it('should emit adc-blur event after blur', async () => {
      const dispatchEventStub = vi.fn();

      button.dispatchEvent = dispatchEventStub;
      const buttonElement = button?.shadowRoot?.querySelector('button');

      buttonElement?.focus();
      buttonElement?.blur();

      await button?.updateComplete;
      expect(dispatchEventStub.mock.calls[1][0].type).toBe('adc-blur');
    });

    it('should focus the inner button', async () => {
      const buttonElement = button.shadowRoot?.querySelector(
        'button'
      ) as HTMLButtonElement;
      const focusStub = vi.fn();
      buttonElement.focus = focusStub;

      button?.focus();
      await button?.updateComplete;

      expect(focusStub).toHaveBeenCalled();
    });

    it('should blur the inner button', async () => {
      const buttonElement = button.shadowRoot?.querySelector(
        'button'
      ) as HTMLButtonElement;
      const blurStub = vi.fn();

      buttonElement.blur = blurStub;

      button?.focus();
      await button?.updateComplete;

      button?.blur();
      await button?.updateComplete;

      expect(blurStub).toHaveBeenCalled();
    });
  });
});
