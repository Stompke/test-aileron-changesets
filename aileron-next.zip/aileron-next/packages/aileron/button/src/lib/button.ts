import { AileronElement } from '@aileron/shared/aileron-element';
import { closestElement } from '@aileron/shared/closest-element';
import { emit } from '@aileron/shared/event';
import { FormSubmitController } from '@aileron/shared/form';
import { HasSlotController } from '@aileron/shared/slot';
import { html } from 'lit';
import { property, query } from 'lit/decorators.js';
import { ClassMapDirective, classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';
import { DirectiveResult } from 'lit/directive';

/**
 * @ignore
 */
export const BUTTON_KIND = {
  PRIMARY: 'primary',
  SECONDARY: 'secondary',
  GHOST: 'ghost',
} as const;

/**
 * @ignore
 */
export const BUTTON_SIZE = {
  SMALL: 'sm',
  FIELD: 'field',
  FULLWIDTH: 'fullwidth',
  SMALL_FULLWIDTH: 'sm fullwidth',
  DEFAULT: '',
} as const;

/**
 * @ignore
 */
export const BUTTON_TYPE = {
  BUTTON: 'button',
  SUBMIT: 'submit',
  RESET: 'reset',
  MENU: 'menu',
} as const;

type ButtonKind = (typeof BUTTON_KIND)[keyof typeof BUTTON_KIND];
type ButtonSize = (typeof BUTTON_SIZE)[keyof typeof BUTTON_SIZE];
type ButtonType = (typeof BUTTON_TYPE)[keyof typeof BUTTON_TYPE];

/**
 * Button
 * @element adc-button
 * @summary adc-button is a clickable elements that is used to trigger actions. They communicate calls to action to the user and allow users to interact with pages in a variety of ways.
 * @fires adc-click - listens for a click event on the button.
 * @fires adc-focus - listens for a focus event on the button.
 * @fires adc-blur - listens for a blur event on the button.
 * @attr {string} [label-text] - The text-content of the button, could also be
 * the `<slot>` content.
 * @slot default - text content slot (default)
 * @slot leading-icon - This is a slot for an icon before text.
 * @slot trailing-icon - This is a slot for an icon after text.
 * @csspart interactive - The internal html button element.
 */
export class Button extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * @ignore
   */
  @query('button') buttonNode!: HTMLButtonElement;

  /**
   * @ignore
   */
  private readonly hasSlotController = new HasSlotController(
    this,
    'leading-icon',
    'trailing-icon'
  );

  /**
   * @ignore
   */
  private readonly formSubmitController = new FormSubmitController(this, {
    form: (input: HTMLInputElement) => {
      if (input.hasAttribute('form')) {
        const doc = input.getRootNode() as Document | ShadowRoot;
        const formId = input.getAttribute('form') as string;

        return doc.getElementById(formId) as HTMLFormElement;
      }

      return input.closest('form');
    },
  });

  /**
   * `true` if the button should have input focus when the page loads.
   * @attr {boolean} [autofocus]
   *
   */
  @property({ type: Boolean, reflect: true }) autofocus = false;

  /**
   * `true` if the button should be disabled.
   * @attr {boolean} [disabled]
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * The text-content of the button, could also be the `<slot>` content.
   * @attr {string} [label-text]
   */
  @property({ attribute: 'label-text' }) labelText = '';

  /**
   * Button kind.
   * @attr {"primary"|"secondary"|"ghost"} [kind]
   */
  @property({ reflect: true }) kind: ButtonKind = BUTTON_KIND.PRIMARY;

  /**
   * Button size.
   * @attr {"field"|"fullwidth"|"sm fullwidth"|"sm"|""} [size]
   */
  @property({ reflect: true }) size: ButtonSize = BUTTON_SIZE.DEFAULT;

  /**
   * The default behavior of a `<button>`.
   * @attr {"button" | "submit" | "reset" | "menu"} [type]
   */
  @property({ reflect: true }) type: ButtonType = BUTTON_TYPE.BUTTON;

  /**
   * The href of the button, if one is needed
   * @type {string}
   */
  @property({ reflect: true }) href = '';

  /**
   * @ignore
   */
  click() {
    this.buttonNode.click();
  }

  /**
   * @ignore
   */
  focus(options?: FocusOptions) {
    this.buttonNode.focus(options);
  }

  /**
   * @ignore
   */
  blur() {
    this.buttonNode.blur();
  }

  /**
   * @ignore
   */
  handleBlur() {
    emit(this, 'adc-blur');
  }

  /**
   * @ignore
   */
  handleFocus() {
    emit(this, 'adc-focus');
  }

  /**
   * @ignore
   * @fires click - listens for a click event on the button.
   */
  handleClick() {
    if (this.type === 'submit') {
      this.formSubmitController.submit(this);
    }

    emit(this, 'adc-click');
  }

  getClassMap(): DirectiveResult<typeof ClassMapDirective> {
    const baseClasses = {
      'appearance-none': true,
      'cursor-pointer': true,
      flex: true,
      'items-center': true,
      'justify-center': true,
      'gap-3': true,
      'h-12': !this.size.includes('sm'),
      'h-9': this.size.includes('sm'),
      'w-full': this.size.includes('fullwidth'),
      'mt-6': this.size.includes('field'),
      'px-4': true,
      rounded: true,
      'text-base': true,
      'font-sans': true,
      'font-medium': true,
      'box-border': true,
      'adc-button--has-only-icon':
        (this.hasSlotController.test('leading-icon') ||
          this.hasSlotController.test('trailing-icon')) &&
        !this.hasSlotController.test('[default]'),
      'adc-button--has-trailing-icon':
        this.hasSlotController.test('trailing-icon'),
      'adc-button--has-leading-icon':
        this.hasSlotController.test('leading-icon'),
      //Base Outline styles
      'active:outline': true,
      'active:outline-2': true,
      'active:outline-offset-2': true,
      'active:outline-blue-070': true,
      'focus:outline': true,
      'focus:outline-2': true,
      'focus:outline-offset-2': true,
      'focus:outline-blue-070': true,
      //Base Disabled styles
      'disabled:cursor-default': true,
      'disabled:pointer-events-none': true,
    };
    const defaultClosest = !!closestElement('.container-default', this);
    const secondaryClosest = !!closestElement('.container-secondary', this);
    const tertiaryClosest = !!closestElement('.container-tertiary', this);

    let kindClasses = {};

    switch (this.kind) {
      case 'primary':
        kindClasses = {
          //Primary text styles
          'text-neutral-140': true,
          'dark:text-neutral-000': true,
          //Primary background styles
          'bg-blue-060': true,
          'dark:bg-blue-080': true,
          'hover:bg-blue-070': true,
          'dark:hover:bg-blue-070': true,
          'active:bg-blue-080': true,
          'dark:active:bg-blue-070': true,
          //Primary Disabled styles
          'disabled:text-neutral-140': true,
          'dark:disabled:text-neutral-000': true,
          'disabled:bg-neutral-090': true,
          'dark:disabled:bg-neutral-050': true,
        };
        break;
      case 'secondary':
        kindClasses = {
          //Secondary text styles
          'text-blue-060': true,
          'dark:text-blue-080': true,
          //Secondary background styles
          'bg-transparent': true,
          'dark:bg-transparent': true,
          'hover:bg-neutral-130': defaultClosest,
          'dark:hover:bg-neutral-010': defaultClosest,
          'active:bg-neutral-120': defaultClosest,
          'dark:active:bg-neutral-020': defaultClosest,
          'hover:bg-neutral-120': secondaryClosest,
          'dark:hover:bg-neutral-020': secondaryClosest,
          'active:bg-neutral-110': secondaryClosest,
          'dark:active:bg-neutral-030': secondaryClosest,
          'hover:bg-neutral-110': tertiaryClosest,
          'dark:hover:bg-neutral-030': tertiaryClosest,
          'active:bg-neutral-100': tertiaryClosest,
          'dark:active:bg-neutral-040': tertiaryClosest,
          //Secondary disabled styles
          'disabled:text-neutral-090': true,
          'dark:disabled:text-neutral-050': true,
          'dark:disabled:bg-transparent': true,
          'disabled:border-neutral-090': true,
          'dark:disabled:border-neutral-050': true,
          //Secondary border styles
          border: true,
          'border-solid': true,
          'border-blue-060': true,
          'dark:border-blue-080': true,
          'hover:border-blue-070': true, //Dark also
          'active:border-blue-080': true,
          'dark:active:border-blue-060': true,
        };
        break;
      case 'ghost':
        kindClasses = {
          //Ghost text styles
          'text-blue-060': true,
          'dark:text-blue-080': true,
          //Ghost background styles
          'bg-transparent': true,
          'dark:bg-transparent': true,
          'hover:bg-neutral-130': defaultClosest,
          'dark:hover:bg-neutral-010': defaultClosest,
          'active:bg-neutral-120': defaultClosest,
          'dark:active:bg-neutral-020': defaultClosest,
          'hover:bg-neutral-120': secondaryClosest,
          'dark:hover:bg-neutral-020': secondaryClosest,
          'active:bg-neutral-110': secondaryClosest,
          'dark:active:bg-neutral-030': secondaryClosest,
          'hover:bg-neutral-110': tertiaryClosest,
          'dark:hover:bg-neutral-030': tertiaryClosest,
          'active:bg-neutral-100': tertiaryClosest,
          'dark:active:bg-neutral-040': tertiaryClosest,
          //Ghost disabled styles
          'disabled:text-neutral-090': true,
          'dark:disabled:text-neutral-050': true,
          'dark:disabled:bg-transparent': true,
          //No border
        };
        break;
    }
    return classMap(Object.assign(baseClasses, kindClasses));
  }

  render(): TemplateResult {
    if (this.href === '') {
      return html` <button
        id="button"
        part="interactive"
        class="adc-button ${this.getClassMap()}"
        ?autofocus=${this.autofocus}
        ?disabled=${this.disabled}
        aria-disabled=${this.disabled ? 'true' : 'false'}
        type=${this.type}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @click=${this.handleClick}
      >
        <slot name="leading-icon"></slot>
        <slot>${this.labelText}</slot>
        <slot name="trailing-icon"></slot>
      </button>`;
    }
    return html`
      <a
        id="button"
        part="interactive"
        class="adc-button ${this.getClassMap()}"
        ?autofocus=${this.autofocus}
        ?disabled=${this.disabled}
        aria-disabled=${this.disabled ? 'true' : 'false'}
        type=${this.type}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @click=${this.handleClick}
        href="${this.href}"
      >
        <slot name="leading-icon"></slot>
        <slot>${this.labelText}</slot>
        <slot name="trailing-icon"></slot>
      </a>
    `;
  }

  updated(changedProperties: PropertyValues): void {
    super.updated(changedProperties);
    if (changedProperties.has('disabled')) {
      if (this.disabled) {
        this.buttonNode.setAttribute('disabled', 'disabled');
      } else {
        this.buttonNode.removeAttribute('disabled');
      }
    }
  }
}

try {
  customElements.define('adc-button', Button);
} catch (e) {
  // do nothing
}
