# @aileron/button

## 1.7.5-next.0

### Patch Changes

- d41e2d29: version bump

## 1.7.4

### Patch Changes

- 1f298c59: fix: updated bad version dependencies
- cedc7699: fix: update all components for eslint
