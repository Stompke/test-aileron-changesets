import { Icon } from './icon.js';

declare global {
  interface HTMLElementTagNameMap {
    'adc-icon': Icon;
  }
}
