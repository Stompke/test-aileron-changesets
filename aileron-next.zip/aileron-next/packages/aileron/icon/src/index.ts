export * from './lib/icon';
