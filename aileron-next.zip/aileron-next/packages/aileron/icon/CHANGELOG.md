# @aileron/icon

## 2.0.1-next.0

### Patch Changes

- d41e2d29: version bump

## 2.0.0

### Major Changes

- 60066416: Added null check for fetchIcon
