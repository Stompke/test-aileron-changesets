# @aileron/icon

### For Icon documentation, please visit our link to all component documention at:
* [Icon](https://animated-doodle-g3kyvlm.pages.github.io/components/icon/)
