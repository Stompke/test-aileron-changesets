var path = require('path');

/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [
    require(path.join(__dirname, '../../../dist/packages/aileron/tailwind')),
  ],
  content: [path.join(__dirname, './src/**/*.ts')],
};
