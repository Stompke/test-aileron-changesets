# @aileron/button-icon

### For documentation, please visit our [Button-Icon documentation page](https://animated-doodle-g3kyvlm.pages.github.io/components/button-icon/).
