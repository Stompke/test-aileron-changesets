# @aileron/button-icon

## 1.7.5-next.0

### Patch Changes

- d41e2d29: version bump
- Updated dependencies [d41e2d29]
  - @aileron/icon@2.0.1-next.0

## 1.7.4

### Patch Changes

- 1f298c59: fix: updated bad version dependencies
- cedc7699: fix: update all components for eslint
- Updated dependencies [60066416]
  - @aileron/icon@2.0.0
