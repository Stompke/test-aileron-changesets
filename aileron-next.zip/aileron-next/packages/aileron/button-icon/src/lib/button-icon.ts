import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { closestElement } from '@aileron/shared/closest-element';
import { emit } from '@aileron/shared/event';
import { FormSubmitController } from '@aileron/shared/form';
import { HasSlotController } from '@aileron/shared/slot';
import { html } from 'lit';
import { DirectiveResult } from 'lit/directive.js';
import { property, query } from 'lit/decorators.js';
import { ClassMapDirective, classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';

/**
 * @ignore
 */
export const ICON_SIZE = {
  SMALL: '16',
  LARGE: '24',
} as const;

/**
 * @ignore
 */
export const BUTTON_KIND = {
  PRIMARY: 'primary',
  SECONDARY: 'secondary',
  GHOST: 'ghost',
} as const;

/**
 * @ignore
 */
export const BUTTON_SIZE = {
  SMALL: 'sm',
  FIELD: 'field',
  DEFAULT: '',
} as const;

/**
 * @ignore
 */
export const BUTTON_TYPE = {
  BUTTON: 'button',
  SUBMIT: 'submit',
  RESET: 'reset',
  MENU: 'menu',
} as const;

type IconSize = (typeof ICON_SIZE)[keyof typeof ICON_SIZE];
type ButtonKind = (typeof BUTTON_KIND)[keyof typeof BUTTON_KIND];
type ButtonSize = (typeof BUTTON_SIZE)[keyof typeof BUTTON_SIZE];
type ButtonType = (typeof BUTTON_TYPE)[keyof typeof BUTTON_TYPE];

/**
 * Button Icon
 * @element adc-button-icon
 * @summary Button Icons are used to trigger actions through the use of glyphs without text.
 * @attr {string} [label-text] - The text-content of the button, added as a slot that is visually hidden.
 * @attr {boolean} [autofocus] - `true` if the button should have input focus when the page loads.
 * @attr {boolean} [disabled] - `true` if the button should be disabled.
 * @attr {string} [label-text] - The text-content of the button, added as a slot that is visually hidden.
 * @attr {"primary"|"secondary"|"ghost"} [kind] - Button kind.
 * @attr {"sm"|"field"|""} [size] - Button size.
 * @attr {"button" | "submit" | "reset" | "menu"} [type] - The default behavior of a `<button>`.
 * @attr {string} [icon] - The icon to display. eg. `"navigation:arrow-right"`
 * @attr {boolean} [outlined] - Sets the icon as an outlined icon.
 * @attr {boolean} [filled] - Sets the icon as a filled icon.
 * @fires adc-click - listens for a click event on the button.
 * @fires adc-focus - listens for a focus event on the button.
 * @fires adc-blur - listens for a blur event on the button.
 * @slot default - Assistive text for screen readers, also attribute label-text.
 * @csspart button-icon - The internal html button element.
 * @csspart icon - Styles to the adc-icon element.
 */
export class ButtonIcon extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @property({ type: Boolean, reflect: true }) autofocus = false;
  @property({ type: Boolean, reflect: true }) disabled = false;
  @property({ attribute: 'label-text' }) labelText = '';
  @property({ reflect: true }) kind: ButtonKind = BUTTON_KIND.PRIMARY;
  @property() size: ButtonSize = BUTTON_SIZE.DEFAULT;
  @property({ reflect: true }) type: ButtonType = BUTTON_TYPE.BUTTON;
  @property() icon!: string;
  @property({ reflect: true, type: Boolean }) outlined = false;
  @property({ reflect: true, type: Boolean }) filled = false;
  @property({ reflect: true, type: String }) name = '';
  @property({ reflect: true, type: String, attribute: 'icon-size' })
  iconSize: IconSize = ICON_SIZE.LARGE;

  /**
   * @ignore
   */
  @query('button') buttonNode!: HTMLButtonElement;

  /**
   * @ignore
   */
  // @ts-expect-error interactiveController needs to be defined
  private readonly hasSlotController = new HasSlotController(this);

  /**
   * @ignore
   */
  private readonly formSubmitController = new FormSubmitController(this, {
    form: (input: HTMLInputElement) => {
      if (input.hasAttribute('form')) {
        const doc = input.getRootNode() as Document | ShadowRoot;
        const formId = input.getAttribute('form');

        if (formId) {
          return doc.getElementById(formId) as HTMLFormElement;
        }
      }

      return input.closest('form');
    },
  });

  click() {
    this.buttonNode.click();
  }

  focus(options?: FocusOptions) {
    this.buttonNode.focus(options);
  }

  blur() {
    this.buttonNode.blur();
  }

  handleBlur() {
    emit(this, 'adc-blur');
  }

  handleFocus() {
    emit(this, 'adc-focus');
  }

  handleClick() {
    if (this.type === BUTTON_TYPE.SUBMIT) {
      this.formSubmitController.submit(this);
    }

    emit(this, 'adc-click');
  }

  updated(changedProperties: PropertyValues) {
    super.updated(changedProperties);
    if (changedProperties.has('disabled')) {
      if (this.disabled) {
        this.buttonNode.setAttribute('disabled', 'disabled');
      } else {
        this.buttonNode.removeAttribute('disabled');
      }
    }
  }

  getClassMap(): DirectiveResult<typeof ClassMapDirective> {
    const baseClasses = {
      rounded: true,
      'items-center': true,
      'justify-center': true,
      'appearance-none': true,
      'border-0': true, //Not in button also?
      'box-border': true,
      'cursor-pointer': true,
      flex: true,
      'h-12': !this.size.includes(BUTTON_SIZE.SMALL),
      'w-12': !this.size.includes(BUTTON_SIZE.SMALL),
      'h-9': this.size.includes(BUTTON_SIZE.SMALL),
      'w-9': this.size.includes(BUTTON_SIZE.SMALL),
      'p-0': true,
      'mt-5': this.size.includes(BUTTON_SIZE.FIELD), //Was 20px in styles.ts
      '-mt-px': this.size.includes(BUTTON_SIZE.SMALL),
      'focus:outline': true,
      'focus:outline-2': true,
      'focus:outline-offset-2': true,
      'focus:outline-blue-070': true,
      'disabled:pointer-events-none': true,
    };
    const defaultClosest = !!closestElement('.container-default', this);
    const secondaryClosest = !!closestElement('.container-secondary', this);
    const tertiaryClosest = !!closestElement('.container-tertiary', this);

    let kindClasses = {};

    switch (this.kind) {
      case 'primary':
        kindClasses = {
          'text-neutral-140': true,
          'dark:text-neutral-000': true,
          'bg-blue-060': true,
          'dark:bg-blue-080': true,
          'hover:bg-blue-070': true,
          'dark:hover:bg-blue-070': true,
          'active:bg-blue-080': true,
          'dark:active:bg-blue-060': true,
          'dark:focus:bg-blue-080': true,
          'disabled:bg-neutral-090': true,
          'dark:disabled:bg-neutral-050': true,
        };
        break;
      case 'secondary':
        kindClasses = {
          'text-blue-060': true,
          'dark:text-blue-080': true,
          'bg-transparent': true,
          'hover:bg-neutral-130': defaultClosest,
          'hover:bg-neutral-120': secondaryClosest,
          'hover:bg-neutral-110': tertiaryClosest,
          'dark:hover:bg-neutral-010': defaultClosest,
          'dark:hover:bg-neutral-020': secondaryClosest,
          'dark:hover:bg-neutral-030': tertiaryClosest,
          'active:bg-neutral-120': defaultClosest,
          'active:bg-neutral-110': secondaryClosest,
          'active:bg-neutral-100': tertiaryClosest,
          'dark:active:bg-neutral-020': defaultClosest,
          'dark:active:bg-neutral-030': secondaryClosest,
          'dark:active:bg-neutral-040': tertiaryClosest,
          border: true,
          'border-solid': true,
          'border-blue-060': true,
          'dark:border-blue-080': true,
          'hover:border-blue-070': true,
          //dark:hover:border:bg the same
          'active:border-blue-080': true,
          'dark:active:border-blue-060': true,
          //Focus falls back to normal light/dark
          'disabled:text-neutral-090': true,
          'dark:disabled:text-neutral-050': true,
          'disabled:border-neutral-090': true,
          'dark:disabled:border-neutral-050': true,
        };
        break;
      case 'ghost':
        kindClasses = {
          'text-blue-060': true,
          'dark:text-blue-080': true,
          'bg-transparent': true,
          'hover:bg-neutral-130': defaultClosest,
          'hover:bg-neutral-120': secondaryClosest,
          'hover:bg-neutral-110': tertiaryClosest,
          'dark:hover:bg-neutral-010': defaultClosest,
          'dark:hover:bg-neutral-020': secondaryClosest,
          'dark:hover:bg-neutral-030': tertiaryClosest,
          'active:bg-neutral-120': defaultClosest,
          'active:bg-neutral-110': secondaryClosest,
          'active:bg-neutral-100': tertiaryClosest,
          'dark:active:bg-neutral-020': defaultClosest,
          'dark:active:bg-neutral-030': secondaryClosest,
          'dark:active:bg-neutral-040': tertiaryClosest,
          //Is 1px border spacing required for ghost?
          // "border": true,
          // "border-solid": true,
          // "border-transparent": true,,
          'disabled:text-neutral-090': true,
          'dark:disabled:text-neutral-050': true,
        };
        break;
    }
    return classMap(Object.assign(baseClasses, kindClasses));
  }

  render(): TemplateResult {
    return html`
      <button
        id="button-icon"
        name=${this.name}
        part="interactive button-icon"
        class="${this.getClassMap()}"
        ?autofocus=${this.autofocus}
        ?disabled=${this.disabled}
        aria-disabled=${this.disabled ? 'true' : 'false'}
        aria-label=${this.labelText}
        type=${this.type}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @click=${this.handleClick}
      >
        <adc-icon
          exportparts="icon"
          ?outlined=${this.outlined}
          ?filled=${this.filled}
          icon=${this.icon}
          size=${this.iconSize}
        ></adc-icon>
        <span class="sr-only">
          <slot>${this.labelText}</slot>
        </span>
      </button>
    `;
  }
}

try {
  customElements.define('adc-button-icon', ButtonIcon);
} catch (e) {
  // do nothing
}
