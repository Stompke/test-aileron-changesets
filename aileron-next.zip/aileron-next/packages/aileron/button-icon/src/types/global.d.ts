import { ButtonIcon } from './button-icon.ts';

declare global {
  interface HTMLElementTagNameMap {
    'adc-button-icon': ButtonIcon;
  }
}
