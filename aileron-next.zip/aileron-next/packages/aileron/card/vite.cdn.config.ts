import { defineConfig } from 'vite';
import ViteTsConfigPathsPlugin from 'vite-tsconfig-paths';
import replace from '@rollup/plugin-replace';
import pkg from './package.json';
import { env } from 'process';

// https://vitejs.dev/config/
export default defineConfig({
  build: {
    lib: {
      entry: 'src/index.ts',
      name: '@aileron/card',
      fileName: () => `card.js`,
    },
    rollupOptions: {
      output: [
        {
          name: '@aileron/card',
          dir: `dist/packages/aileron/card/dist/card@${env.NODE_ENV === 'production' ? 'latest' : 'next'}`,
          format: 'umd',
        },
        {
          name: '@aileron/card',
          dir: `dist/packages/aileron/card/dist/card@${pkg.version}`,
          format: 'umd',
        },
      ],
      plugins: [
        replace({
          'process.env.NODE_ENV': JSON.stringify('production'),
          preventAssignment: true,
        }),
      ],
    },
  },
  plugins: [
    ViteTsConfigPathsPlugin({
      root: '../../../',
    }),
  ],
});
