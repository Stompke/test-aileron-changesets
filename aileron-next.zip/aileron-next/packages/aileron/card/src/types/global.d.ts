import { Card } from './card';
import { CardMedia } from './card-media.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-card': Card;
    'adc-card-media': CardMedia;
  }
}
