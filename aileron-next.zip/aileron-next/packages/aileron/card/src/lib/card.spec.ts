import type { Card, CardMedia } from '../index';
import '../index';

describe('<adc-card>', () => {
  let card: Card;
  let cardMedia: CardMedia;
  beforeEach(() => {
    document.body.innerHTML = `
    <h1>Custom element test</h1>
    <adc-card>
      <adc-card-media slot="media" src="https://picsum.photos/200/300">This is now a media card!</adc-card-media>
    </adc-card>`;
    card = document.querySelector('adc-card');
    cardMedia = document.querySelector('adc-card-media');
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(card?.nodeType).toBe(1);
    });

    it('should contain the id card', async () => {
      const element = card.shadowRoot?.querySelector('#card');

      expect(element).not.toBeNull();
    });
  });

  describe('when provided an element in the slot "media" to render an adc-card-media', () => {
    it('should pass accessibility tests', async () => {
      await expect(card?.nodeType).toBe(1);
    });

    it('should render the child content', async () => {
      expect(cardMedia?.textContent).toBe('This is now a media card!');
    });

    it('should render the media content', () => {
      const media = card?.querySelector('adc-card-media[slot=media]');

      expect(media).not.toBeNull();
    });

    it('should accept "media" as an assigned child in the shadow root', () => {
      const slot = card.shadowRoot?.querySelector(
        'slot[name=media]'
      ) as HTMLSlotElement;
      const childNodes = slot.assignedNodes({ flatten: true });

      expect(childNodes.length).toBe(1);
    });

    it('should contain the id', () => {
      const mediaCard = card?.querySelector('adc-card-media') as CardMedia;
      const media = mediaCard.shadowRoot?.querySelector('#card-media');

      expect(media).not.toBeNull();
    });
  });
});
