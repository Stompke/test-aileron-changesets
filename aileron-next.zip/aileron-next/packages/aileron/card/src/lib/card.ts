import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * @ignore
 */
export const CARD_SIZE = {
  LARGE: 'lg',
  REGULAR: '',
} as const;

/**
 * @ignore
 */
export const CARD_ORIENTATION = {
  VERTICAL: 'vertical',
  HORIZONTAL: 'horizontal',
} as const;

/**
 * @ignore
 */
export const CARD_MEDIA_ASPECT_RATIO = {
  SIXTEEN_NINE: '16-9',
  SQUARE: 'square',
} as const;

/**
 * @ignore
 */
export type Size = typeof CARD_SIZE.LARGE | typeof CARD_SIZE.REGULAR;

/**
 * @ignore
 */
export type Orientation =
  | typeof CARD_ORIENTATION.VERTICAL
  | typeof CARD_ORIENTATION.HORIZONTAL;

/**
 * Card
 * @element adc-card
 * @summary Cards are a highly flexible component for displaying a wide variety of content, including informational, getting started, how-to, next steps, and more.
 * @slot default - Default slot, used for the content of the card.
 * @slot media - This slot is intended for use with the adc-card-media component.
 * @csspart base - base container element of adc-card
 * @csspart content - container for content slot
 * @attr {number} [elevation="0"] - Sets the elevation of the card, or removes it if the value is `0`
 * @attr {"lg" | ""} [size=""] - Sets the padding for the card.
 * @attr {"vertical" | "horizontal"} [orientation="vertical"] - Sets the orientation of the card.
 */
export class Card extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @property({ type: Number }) elevation = 0;
  @property() size: Size = CARD_SIZE.REGULAR;
  @property({ reflect: true }) orientation: Orientation =
    CARD_ORIENTATION.VERTICAL;

  render(): TemplateResult {
    const { elevation, orientation, size } = this;

    return html`<div
      id="card"
      part="base"
      class="font-sans font-regular text-base line-height-6 relative flex flex-auto shrink-0 rounded bg-neutral-140 box-border after:absolute after:box-border after:w-full after:h-full after:top-0 after:left-0 after:border after:border-solid after:border-transparent after:pointer-events-none${classMap(
        {
          'flex-row': orientation === CARD_ORIENTATION.HORIZONTAL,
          'flex-col': orientation === CARD_ORIENTATION.VERTICAL,
          border: !elevation,
          'border-solid': !elevation,
          'border-neutral-070': !elevation,
          'after:rounded': !elevation,
          'shadow-sm': elevation === 1,
          shadow: elevation === 2,
          'shadow-md': elevation === 3,
          'shadow-lg': elevation === 4,
          'shadow-xl': elevation === 5,
          'rounded-lg': size === CARD_SIZE.LARGE,
        }
      )}"
    >
      <slot name="media"></slot>
      <div
        part="content"
        class="h-[calc(100%-2rem)] pt-4 pb-0 px-4 mt-0 mb-0 last:p-4 ${classMap(
          {
            'pt-6': size === CARD_SIZE.LARGE,
            'px-6': size === CARD_SIZE.LARGE,
            'last:p-6': size === CARD_SIZE.LARGE,
          }
        )}"
      >
        <slot></slot>
      </div>
    </div>`;
  }
}

try {
  customElements.define('adc-card', Card);
} catch (e) {
  // do nothing
}
