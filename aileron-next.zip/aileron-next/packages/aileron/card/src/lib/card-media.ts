import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { styleMap } from 'lit/directives/style-map.js';
import styles from './styles.css?inline';
import { CARD_MEDIA_ASPECT_RATIO, CARD_ORIENTATION } from './card';
import type { Card } from './card';
import type { TemplateResult } from 'lit';

type Orientation = (typeof CARD_ORIENTATION)[keyof typeof CARD_ORIENTATION];
type Ratio =
  (typeof CARD_MEDIA_ASPECT_RATIO)[keyof typeof CARD_MEDIA_ASPECT_RATIO];

/**
 * CardMedia
 * @element adc-card-media
 * @summary Media used within the Card component to display an image at the top of the card.
 * @attr {"16-9" | "square"} [ratio='16-9'] - Sets the aspect ratio of the media.
 * @attr {"vertical" | "horizontal"} [orientation='vertical'] - Sets the orientation of the card.
 * @attr {string} [src=''] - Sets the source of the image.
 */
export class CardMedia extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @property({ reflect: true }) orientation: Orientation =
    CARD_ORIENTATION.VERTICAL;
  @property() ratio: Ratio = CARD_MEDIA_ASPECT_RATIO.SIXTEEN_NINE;
  @property() src = '';

  render(): TemplateResult {
    const { ratio, src } = this;

    const mediaStyles = {
      backgroundImage: src ? `url(${src})` : '',
    };

    return html`<div
      id="card-media"
      class="rounded-tl rounded-tr rounded-br-none rounded-bl-none  relative box-border bg-no-repeat bg-center bg-cover w-full h-full after:block after:clear-both${classMap(
        {
          'aspect-video': ratio === CARD_MEDIA_ASPECT_RATIO.SIXTEEN_NINE,
          'aspect-square': ratio === CARD_MEDIA_ASPECT_RATIO.SQUARE,
        }
      )}"
      style=${styleMap(mediaStyles)}
    ></div>`;
  }

  connectedCallback(): void {
    const card = this.parentElement as Card;

    if (!this.hasAttribute('slot')) {
      this.setAttribute('slot', 'media');
    }

    if (card.hasAttribute('orientation')) {
      this.orientation = <Orientation>card.orientation;
    }

    super.connectedCallback();
  }
}

try {
  customElements.define('adc-card-media', CardMedia);
} catch (e) {
  // do nothing
}
