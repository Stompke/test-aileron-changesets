import '@aileron/button-icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { animateTo, stopAnimations } from '@aileron/shared/animate';
import { DeviceDetector } from '@aileron/shared/device-detector';
import { emit, waitForEvent } from '@aileron/shared/event';
import { Modal } from '@aileron/shared/modal';
import { lockBodyScrolling, unlockBodyScrolling } from '@aileron/shared/scroll';
import { HasSlotController } from '@aileron/shared/slot';
import { watch } from '@aileron/shared/watch';
import {
  getAnimation,
  setDefaultAnimation,
} from '@aileron/utilities/animation-registry';
import { html } from 'lit';
import { property, query } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import styles from './styles.css?inline';

/**
 * Dialog
 * @summary The dialog is a component used to display content that you don't want to leave the page for.
 * @element adc-dialog
 * @fires adc-request-close - fires when the dialog is requested to close.
 * @fires adc-show - fires when the dialog is shown.
 * @fires adc-after-show - fires after the dialog is shown.
 * @fires adc-hide - fires when the dialog is hidden.
 * @fires adc-after-hide - fires after the dialog is hidden.
 * @fires adc-initial-focus - fires when the dialog is shown and focus is set.
 * @part base - Parent element that wraps both the overlay and panel.
 * @part overlay - The dimmed background layer used for hiding the page.
 * @part panel - Panel is the outside shape of the dialog.
 * @part header - This is where the title exists and is a child of panel.
 * @part image - Used to provide an image for the header, is a child of header.
 * @part title - The dialog title, this is an h2 and a child of the header.
 * @part body - This is where the main content lives and is a child of panel.
 * @part footer - This sits below the body content and is a child of panel.
 * @part close-button - Close button provided by the dialog.
 * @attr {string} [label-text=''] - The text-content of the heading, could also be
 * the `<span slot="label" />` content.
 * @attr {boolean} open - Whether the dialog is open.
 * @attr {boolean} [no-close-button] - Whether to show the close button.
 * @attr {string} variant - Controls the size of the dialog.
 * @slot default - text content slot (default)
 * @slot label - This is a slot for the text in the header.
 * @slot footer - This is a slot for content in the footer, namely buttons.
 * @slot image - This is a slot for the dialog image to be placed at the top in the header section.
 * @slot loading - This is a slot for the loading component that overlays the content.
 */
export class Dialog extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @query('#dialog') dialog!: HTMLElement;
  @query('#dialogPanel') panel!: HTMLElement;
  @query('#dialogOverlay') overlay!: HTMLElement;

  private readonly hasSlotController = new HasSlotController(
    this,
    'footer',
    'label',
    'image',
    'loading'
  );
  private modal!: Modal;
  private originalTrigger!: HTMLElement | null;
  private isLoading!: boolean;

  @property({ type: Boolean, reflect: true }) open = false;
  @property({ attribute: 'label-text' }) labelText!: string;
  @property({ type: Boolean, attribute: 'no-close-button', reflect: true })
  noCloseButton = false;
  @property() variant: 'message' | 'fullscreen' = 'message';

  /**
   * Instantiates the modal and adds tab-index to the main dialog.
   */
  connectedCallback() {
    super.connectedCallback();

    this.modal = new Modal(this);
    this.tabIndex = -1;
  }

  /**
   * Toggles the dialog open/closed. If opened, initializes the modal, and
   * adds a style to lock body scrolling.
   */
  firstUpdated() {
    const deviceDetector = new DeviceDetector(navigator.userAgent);
    const device = deviceDetector.getDevice().toLowerCase();
    const browser = deviceDetector.getBrowser().toLowerCase();
    if (device !== 'iphone' && device !== 'ipad' && browser !== 'safari') {
      this.panel.setAttribute('aria-modal', 'true');
    }

    this.dialog.hidden = !this.open;

    if (this.open) {
      this.modal.activate();

      lockBodyScrolling(this);
    }

    this.handleLoadingSlotChange();
  }

  /**
   * Removes the styles for locking body scrolling.
   */
  disconnectedCallback(): void {
    super.disconnectedCallback();

    unlockBodyScrolling(this);
  }

  /**
   * Handles the action for showing the dialog.
   * @returns {Promise<void>}|undefined
   */
  async show() {
    if (this.open) {
      return undefined;
    }

    this.open = true;
    return waitForEvent(this, 'adc-after-show');
  }

  /**
   * Handles the action for hiding the dialog.
   * @returns {Promise<void>}|undefined
   */
  async hide() {
    if (!this.open) {
      return undefined;
    }

    this.open = false;

    return waitForEvent(this, 'adc-after-hide');
  }

  /**
   * Handles setting focus to the panel when the dialog is shown.
   * @param options - standard focus options,
   * https://developer.mozilla.org/en-US/docs/Web/API/FocusEvent/FocusEvent
   */
  focus(options?: FocusOptions) {
    this.panel.focus(options);
  }

  /**
   * Handles the action for closing the dialog, triggers `hide()` on success.
   * @fires adc-request-close - fires when the dialog is requested to close.
   * @param source "close-button" | "keyboard" | "overlay" - the source of the close event.
   * @returns
   */
  private requestClose(source: 'close-button' | 'keyboard' | 'overlay') {
    const adcRequestClose = emit(this, 'adc-request-close', {
      cancelable: true,
      detail: { source },
    });

    if (adcRequestClose.defaultPrevented) {
      const animation = getAnimation(this, 'dialog.denyClose');
      try {
        animateTo(this.panel, animation.keyframes, animation.options);
      } catch (error) {
        //do nothing
      }

      return;
    }

    this.hide();
  }

  /**
   * Handles the action for closing the dialog when the "Escape" key is pressed.
   * @param event - keyboard event for key detection
   */
  handleKeyDown(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      event.stopPropagation();
      this.requestClose('keyboard');
    }
  }

  /**
   * Handles functionality when the open variable is updated. When the
   * dialog is opened, add events for focusin, keydown and keyup. Locks the body
   * scrolling behavior. If autofocus is set, focus that element or the panel if not.
   *
   * TODO: When using JAWS with the Firefox browser, the dialog is not focused when it is shown. Ref #200
   *
   * @fires adc-show - fires when the dialog is shown.
   * @fires adc-after-show - fires after the dialog is shown.
   * @fires adc-hide - fires when the dialog is hidden.
   * @fires adc-after-hide - fires after the dialog is hidden.
   * @fires adc-initial-focus - fires when the dialog is shown and focus is set.
   */
  @watch('open', { waitUntilFirstUpdate: true })
  async handleOpenChange() {
    if (this.open) {
      emit(this, 'adc-show');
      this.originalTrigger = document.activeElement as HTMLElement;
      this.modal.activate();

      lockBodyScrolling(this);

      const autoFocusTarget = this.querySelector<HTMLElement>('[autofocus]');
      if (autoFocusTarget) {
        autoFocusTarget.removeAttribute('autofocus');
      }

      try {
        await Promise.all([
          stopAnimations(this.dialog),
          stopAnimations(this.overlay),
        ]);
      } catch (error) {
        // do nothing
      }

      this.dialog.hidden = false;

      requestAnimationFrame(() => {
        const adcInitialFocus = emit(this, 'adc-initial-focus', {
          cancelable: true,
        });

        if (!adcInitialFocus.defaultPrevented) {
          if (autoFocusTarget) {
            (autoFocusTarget as HTMLInputElement).focus({
              preventScroll: true,
            });
          } else {
            this.focus({ preventScroll: true });
          }
        }

        if (autoFocusTarget) {
          autoFocusTarget.setAttribute('autofocus', '');
        }
      });

      const panelAnimation = getAnimation(this, 'dialog.show');
      const overlayAnimation = getAnimation(this, 'dialog.overlay.show');
      try {
        await Promise.all([
          animateTo(
            this.panel,
            panelAnimation.keyframes,
            panelAnimation.options
          ),
          animateTo(
            this.overlay,
            overlayAnimation.keyframes,
            overlayAnimation.options
          ),
        ]);
      } catch (error) {
        // do nothing
      }

      emit(this, 'adc-after-show');
    } else {
      emit(this, 'adc-hide');
      this.modal.deactivate();

      try {
        await Promise.all([
          stopAnimations(this.dialog),
          stopAnimations(this.overlay),
        ]);
      } catch (error) {
        // do nothing
      }

      const panelAnimation = getAnimation(this, 'dialog.hide');
      const overlayAnimation = getAnimation(this, 'dialog.overlay.hide');

      try {
        await Promise.all([
          animateTo(
            this.panel,
            panelAnimation.keyframes,
            panelAnimation.options
          ),
          animateTo(
            this.overlay,
            overlayAnimation.keyframes,
            overlayAnimation.options
          ),
        ]);
      } catch (error) {
        // do nothing
      }

      this.dialog.hidden = true;

      unlockBodyScrolling(this);

      const trigger = this.originalTrigger;
      if (typeof trigger?.focus === 'function') {
        setTimeout(() => trigger.focus());
      }

      emit(this, 'adc-after-hide');
    }
  }

  handleLoadingSlotChange() {
    this.isLoading = this.hasSlotController.test('loading');
  }

  renderLoading() {
    return html`<div class="min-h-[300px]">
      <slot @slotchange=${this.handleLoadingSlotChange} name="loading"></slot>
    </div>`;
  }

  renderHeader() {
    return html` <div
      part="header"
      class="flex-auto px-24 relative pt-24 ${classMap({
        'pb-24': !this.labelText && !this.noCloseButton,
      })}"
    >
      <div part="image" class="flex justify-center">
        <slot name="image"></slot>
      </div>
      <h2
        part="title"
        class="font-sans font-regular text-3xl line-height-8 m-0 mr-64"
        id="title"
      >
        <slot name="label">
          ${this.labelText?.length > 0 ? this.labelText : undefined}
        </slot>
      </h2>
      ${!this.noCloseButton
        ? html`<adc-button-icon
            exportparts="button-icon: close-button"
            class="absolute top-16 right-16 z-10"
            kind="ghost"
            label-text="Close Dialog"
            icon="action:close"
            @click=${() => this.requestClose('close-button')}
            id="closeButton"
          >
          </adc-button-icon>`
        : undefined}
    </div>`;
  }

  renderPanelContent() {
    return html` ${this.labelText || !this.noCloseButton
        ? this.renderHeader()
        : undefined}
      <div
        part="body"
        class="font-sans font-regular text-base line-height-6 overflow-auto my-24 px-24 flex-auto"
      >
        <slot></slot>
      </div>
      <div
        part="footer"
        class="px-24 flex-initial justify-end pb-24${classMap({
          flex: this.hasSlotController.test('footer'),
          hidden: !this.hasSlotController.test('footer'),
        })}"
      >
        <slot name="footer"></slot>
      </div>`;
  }

  /**
   * Renders the full dialog and overlay components.
   * @returns {TemplateResult} - the template for the dialog.
   */
  render() {
    return html`
      <div
        id="dialog"
        part="base"
        class="flex items-center justify-center fixed inset-0 z-50"
        @keydown=${this.handleKeyDown}
      >
        <div
          id="dialogOverlay"
          part="overlay"
          class="bg-[rgba(0,0,0,0.4)] fixed inset-0"
          @click=${() => this.requestClose('overlay')}
          tabindex="-1"
        ></div>
        <div
          id="dialogPanel"
          part="panel"
          class="shadow-xl rounded-lg flex w-auto flex-col bg-neutral-140 focus:outline-0 max-w-[calc(100vw-2rem)] max-h-[calc(100vh-2rem)] sm:min-w-[356px] sm:max-w-[546px] sm:max-h-[80vh] md:min-w-[389px] md:max-w-[596px] ${classMap(
            {
              flex: this.open,
              relative: this.open,
              'opacity-100': this.open,
              'transform-none': this.open,
              'h-full': this.variant === 'fullscreen',
              'sm:max-w-[calc(100vw-4rem)]': this.variant === 'fullscreen',
              'sm:max-h-[80vh]': this.variant === 'fullscreen',
              'md:max-w-[calc(100vw-4rem)]': this.variant === 'fullscreen',
              'lg:max-w-[1216px]': this.variant === 'fullscreen',
            }
          )}"
          role="dialog"
          aria-hidden=${this.open ? 'false' : 'true'}
          aria-label=${ifDefined(this.labelText ? this.labelText : undefined)}
          aria-labelledby=${ifDefined(!this.labelText ? 'title' : undefined)}
          tabindex="-1"
        >
          ${this.isLoading ? this.renderLoading() : this.renderPanelContent()}
        </div>
      </div>
    `;
  }
}

/**
 * Sets the animation keyframes, easing and duration for the showing the dialog.
 * @function getDefaultAnimation
 */
setDefaultAnimation('dialog.show', {
  keyframes: [
    { opacity: 0, transform: 'scale(0.8)' },
    { opacity: 1, transform: 'scale(1)' },
  ],
  options: {
    duration: 250,
    easing: 'ease',
  },
});

/**
 * Sets the animation keyframes, easing and duration for the hiding the dialog.
 * @function getDefaultAnimation
 */
setDefaultAnimation('dialog.hide', {
  keyframes: [
    { opacity: 1, transform: 'scale(1)' },
    { opacity: 0, transform: 'scale(0.8)' },
  ],
  options: {
    duration: 250,
    easing: 'ease',
  },
});

/**
 * Sets the animation keyframes, easing and duration for the denying close of the dialog.
 * @function getDefaultAnimation
 */
setDefaultAnimation('dialog.denyClose', {
  keyframes: [
    { transform: 'scale(1)' },
    { transform: 'scale(1.02)' },
    { transform: 'scale(1)' },
  ],
  options: {
    duration: 250,
  },
});

/**
 * Sets the animation keyframes, easing and duration for the showing the dialog overlay.
 * @function getDefaultAnimation
 */
setDefaultAnimation('dialog.overlay.show', {
  keyframes: [{ opacity: 0 }, { opacity: 1 }],
  options: {
    duration: 250,
  },
});

/**
 * Sets the animation keyframes, easing and duration for the hiding the dialog overlay.
 * @function getDefaultAnimation
 */
setDefaultAnimation('dialog.overlay.hide', {
  keyframes: [{ opacity: 1 }, { opacity: 0 }],
  options: {
    duration: 250,
  },
});

try {
  customElements.define('adc-dialog', Dialog);
} catch (e) {
  // do nothing
}
