import type { Dialog } from './dialog';
import './dialog';

describe('<adc-dialog>', () => {
  let dialog: Dialog;
  beforeEach(() => {
    document.body.innerHTML = `
    <adc-dialog
      id="dialog"
      class="dialog-container"
    >
      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
      labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
      laboris nisi ut aliquip ex ea commodo consequat.
      <adc-button slot="footer">Cancel</adc-button>
    </adc-dialog>
    `;
    dialog = document.querySelector('adc-dialog') as Dialog;
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      document.body.innerHTML = `<h1>Custom element test</h1><adc-dialog>dialog</adc-dialog>`;

      expect(dialog?.nodeType).toBe(1);
    });
    it('should have correct default values', () => {
      expect(dialog?.variant).toBe('message');
      expect(dialog.open).toBe(false);
      expect(dialog.noCloseButton).toBe(false);
      expect(dialog.labelText).toBe(undefined);
    });
    it('should not render fullscreen div', async () => {
      const element = dialog.shadowRoot?.querySelector('.h-full');
      expect(element).toBeNull();
    });
    it('should not render the header when there is neither a labelText nor a close-button', async () => {
      dialog.labelText = '';
      dialog.noCloseButton = true;
      await dialog.updateComplete;
      const header = dialog.shadowRoot?.querySelector('[part=header]');
      expect(header).toBeNull();
    });
  });

  describe('when properties has been settled', () => {
    it('should render fullscreen div', async () => {
      dialog.variant = 'fullscreen';
      await dialog.updateComplete;
      const element = dialog.shadowRoot?.querySelector('.h-full');
      expect(element).not.toBeNull();
    });

    it('should render the header when there is a labelText', async () => {
      dialog.labelText = 'Dialog Title';
      await dialog.updateComplete;
      const header = dialog.shadowRoot?.querySelector('div[part=header]');
      expect(header).not.toBeNull();
    });

    it('should render close button when there is a labelText', async () => {
      dialog.labelText = 'Dialog Title';
      dialog.requestUpdate();
      await dialog.updateComplete;
      const closeButton = dialog.shadowRoot?.querySelector('#closeButton');
      expect(closeButton).not.toBeNull();
    });

    it('should not render close button when there is not a labelText and noCloseButton is false', async () => {
      dialog.labelText = '';
      dialog.noCloseButton = false;
      dialog.requestUpdate();
      await dialog.updateComplete;
      const closeButton = dialog.shadowRoot?.querySelector('#closeButton');
      expect(closeButton).not.toBeNull();
    });

    it('should not render close button when noCloseButton is true', async () => {
      dialog.labelText = 'Dialog Title';
      dialog.noCloseButton = true;
      await dialog.updateComplete;
      const closeButton = dialog.shadowRoot?.querySelector('#closeButton');
      expect(closeButton).toBeNull();
    });
  });

  describe('methods', () => {
    it('should open after call show()', async () => {
      dialog.show();
      await dialog.updateComplete;
      expect(dialog.open).toBe(true);
    });

    it('should close after call hide()', async () => {
      dialog.open = true;
      await dialog.updateComplete;
      dialog.hide();
      await dialog.updateComplete;
      expect(dialog.open).toBe(false);
    });
    it('should close clicking on overlay', async () => {
      dialog.open = true;
      dialog.requestUpdate();
      await dialog.updateComplete;
      const overlay = dialog.shadowRoot?.querySelector(
        '#dialogOverlay'
      ) as HTMLElement;
      overlay.click();
      await dialog.updateComplete;
      expect(dialog.open).toBe(false);
    });
    it('should close clicking on close button', async () => {
      dialog.open = true;
      dialog.labelText = 'Dialog Title';
      dialog.noCloseButton = false;
      dialog.requestUpdate();
      await dialog.updateComplete;
      const closeButton = dialog.shadowRoot?.querySelector(
        '#closeButton'
      ) as HTMLElement;

      closeButton.click();

      await dialog.updateComplete;
      expect(dialog.open).toBe(false);
    });
    it('should return undefined after call show() when open is true', async () => {
      dialog.open = true;
      const result = await dialog.show();
      expect(result).toBe(undefined);
    });
    it('should return undefined after call hide() when open is false', async () => {
      dialog.open = false;
      const result = await dialog.hide();
      expect(result).toBe(undefined);
    });
  });
});
