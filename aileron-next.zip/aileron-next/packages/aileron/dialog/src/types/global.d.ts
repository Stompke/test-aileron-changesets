import { Dialog } from './dialog.js';

declare global {
  interface HTMLElementTagNameMap {
    'adc-dialog': Dialog;
  }
}
