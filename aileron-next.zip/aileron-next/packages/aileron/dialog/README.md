# @aileron/dialog

### For Dialog documentation, please visit our link to all component documention at:
* [Dialog](https://animated-doodle-g3kyvlm.pages.github.io/components/dialog/)
