import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Action drawer header.
 * @element adc-action-drawer-header
 * @summary Child component of the adc-action-drawer component that is used to display the header content of the action drawer.
 * @slot default - default slot
 */
export class ActionDrawerHeader extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  render(): TemplateResult {
    return html`<slot></slot>`;
  }
}

try {
  customElements.define('adc-action-drawer-header', ActionDrawerHeader);
} catch (e) {
  // do nothing
}
