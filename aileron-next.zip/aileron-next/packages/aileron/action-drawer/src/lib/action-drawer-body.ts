import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Action drawer body.
 * @element adc-action-drawer-body
 * @summary Child component of adc-action-drawer that is used to display the body content of the action drawer.
 * @parentComponent adc-action-drawer
 * @slot default - default slot
 */
export class ActionDrawerBody extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  render(): TemplateResult {
    return html`<div
      class="font-sans font-regular text-base line-height-6 mt-16 overflow-y-auto relative"
    >
      <slot></slot>
    </div>`;
  }
}

try {
  customElements.define('adc-action-drawer-body', ActionDrawerBody);
} catch (e) {
  // do nothing
}
