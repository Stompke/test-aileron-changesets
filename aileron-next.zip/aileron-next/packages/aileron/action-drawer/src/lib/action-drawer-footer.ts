import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Action drawer footer.
 * @element adc-action-drawer-footer
 * @summary Child component of the adc-action-drawer component that is used to display the footer content of the action drawer.
 * @slot default - default slot
 */
export class ActionDrawerFooter extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  render(): TemplateResult {
    return html`
      <div class="flex justify-end">
        <slot></slot>
      </div>
    `;
  }
}

try {
  customElements.define('adc-action-drawer-footer', ActionDrawerFooter);
} catch (e) {
  // do nothing
}
