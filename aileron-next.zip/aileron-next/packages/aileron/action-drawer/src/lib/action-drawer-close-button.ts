import { FocusVisiblePolyfillMixin } from '@aileron/shared/focus-visible';
import { AileronElement } from '@aileron/shared/aileron-element';
import '@aileron/icon';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Action drawer close button.
 * @element adc-action-drawer-close-button
 * @summary Button Icon that handles dismissing the Action Drawer component.
 * @csspart button The button element that wraps the close icon.
 * @attr {string} [assistive-text='Close'] - Hidden accessible text for screen readers.
 */
export class ActionDrawerCloseButton extends FocusVisiblePolyfillMixin(
  AileronElement
) {
  static styles = [AileronElement.styles || [], styles];

  @property({ attribute: 'assistive-text' }) assistiveText = 'Close';

  render(): TemplateResult {
    return html`
      <button
        part="button"
        aria-label="${ifDefined(this.assistiveText)}"
        class="adc-action-drawer__close flex absolute right-16 top-16 appearance-none border-0 text-blue-060 cursor-pointer p-16 max-[800px]:p-0"
        title="${ifDefined(this.assistiveText)}"
      >
        <adc-icon icon="action:close"></adc-icon>
      </button>
    `;
  }
}

try {
  customElements.define(
    'adc-action-drawer-close-button',
    ActionDrawerCloseButton
  );
} catch (e) {
  // do nothing
}
