import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Action drawer heading.
 * @element adc-action-drawer-heading
 * @summary Defines the styles for the action drawer heading, used in the adc-action-drawer-header component.
 * @slot default - Header text for the action drawer.
 */
export class ActionDrawerHeading extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  render(): TemplateResult {
    return html`<div
      class="font-sans font-bold text-xl line-height-6_5 text-neutral-010"
    >
      <slot></slot>
    </div>`;
  }
}

try {
  customElements.define('adc-action-drawer-heading', ActionDrawerHeading);
} catch (e) {
  // do nothing
}
