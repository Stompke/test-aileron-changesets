import { ActionDrawer } from './action-drawer.component';
import { ActionDrawerBody } from './action-drawer-body.component';
import { ActionDrawerCloseButton } from './action-drawer-close-button.component';
import { ActionDrawerFooter } from './action-drawer-footer.component';
import { ActionDrawerHeader } from './action-drawer-header.component';
import { ActionDrawerHeading } from './action-drawer-heading.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-action-drawer': ActionDrawer;
    'adc-action-drawer-body': ActionDrawerBody;
    'adc-action-drawer-close-button': ActionDrawerCloseButton;
    'adc-action-drawer-footer': ActionDrawerFooter;
    'adc-action-drawer-header': ActionDrawerHeader;
    'adc-action-drawer-heading': ActionDrawerHeading;
  }
}
