# @aileron/divider

## 2.1.5-next.0

### Patch Changes

- d41e2d29: version bump

## 2.1.4

### Patch Changes

- 6ddd465c: fix: update the styles of multiple components
- cedc7699: fix: update all components for eslint
