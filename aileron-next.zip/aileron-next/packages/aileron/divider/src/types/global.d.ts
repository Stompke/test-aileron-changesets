import { Divider } from './divider.js';

declare global {
  interface HTMLElementTagNameMap {
    'adc-divider': Divider;
  }
}
