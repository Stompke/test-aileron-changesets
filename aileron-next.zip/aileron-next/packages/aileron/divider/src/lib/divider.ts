import { AileronElement } from '@aileron/shared/aileron-element';
import { HasSlotController } from '@aileron/shared/slot';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Divider
 * @element adc-divider
 * @summary A divider is a thin line that groups content in lists and layouts.
 */
export class Divider extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  private readonly hasSlotController = new HasSlotController(this);
  /**
   * Sets the stroke from solid to dashed
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) dashed = false;

  /**
   * Deprecated - Use spacing instead
   * @type {"x-small" | "small" | "medium" | "large"}
   */
  @property({ reflect: true }) size = 'small';

  /**
   * Sets the margin spacing of the divider
   * @type {"12" | "16" | "24" | "32" | "40" | "48" | "64"}
   */
  @property({ reflect: true }) spacing = '12';

  /**
   * Sets the color of the divider
   * @type {"default" | "secondary" | "tertiary"}
   */
  @property({ reflect: true }) color = 'default';

  firstUpdated(): void {
    if (this.hasSlotController.test('[default]')) {
      const slotElement = this.shadowRoot?.querySelector('slot');
      const elements = slotElement?.assignedElements();
      elements?.forEach((element) =>
        element.setAttribute('role', 'presentation')
      );
    }
  }

  render(): TemplateResult {
    return html`<div
      part="divider"
      role="separator"
      class="font-sans font-regular text-sm line-height-4 flex outline-0 align-top items-center text-center w-full antialiased mx-0 after:flex-1 after:border-0 after:border-b before:flex-1 before:border-0 before:border-b before:border-solid before:border-neutral-070 ${classMap(
        {
          'after:border-neutral-070': this.color === 'default',
          'before:border-neutral-070': this.color === 'default',
          'after:border-neutral-090': this.color === 'secondary',
          'before:border-neutral-090': this.color === 'secondary',
          'after:border-neutral-100': this.color === 'tertiary',
          'before:border-neutral-100': this.color === 'tertiary',
          'dark:after:border-neutral-050': this.color === 'secondary',
          'dark:before:border-neutral-050': this.color === 'secondary',
          'dark:after:border-neutral-040': this.color === 'tertiary',
          'dark:before:border-neutral-040': this.color === 'tertiary',
          'before:mr-2': this.hasSlotController.test('[default]'),
          'after:ml-2': this.hasSlotController.test('[default]'),
          'before:border-dashed': this.dashed,
          'after:border-dashed': this.dashed,
          'before:border-solid': !this.dashed,
          'after:border-solid': !this.dashed,
          'my-3': this.spacing === '12',
          'my-2': this.size === 'x-small',
          'my-4': this.spacing === '16' || this.size === 'small',
          'my-6': this.spacing === '24' || this.size === 'medium',
          'my-8': this.spacing === '32' || this.size === 'large',
          'my-10': this.spacing === '40',
          'my-12': this.spacing === '48',
          'my-16': this.spacing === '64',
        }
      )}"
    >
      <slot></slot>
    </div>`;
  }
}

try {
  customElements.define('adc-divider', Divider);
} catch (e) {
  // do nothing
}
