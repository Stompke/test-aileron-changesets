# @aileron/divider

### For Divider documentation, please visit our link to all component documention at:
* [Divider](https://animated-doodle-g3kyvlm.pages.github.io/components/divider/)
