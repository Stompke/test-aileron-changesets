# @aileron/nav-bar

## 1.5.5-next.0

### Patch Changes

- d41e2d29: version bump
- Updated dependencies [d41e2d29]
  - @aileron/icon@2.0.1-next.0
  - @aileron/tag@1.5.5-next.0

## 1.5.4

### Patch Changes

- 6ddd465c: fix: update the styles of multiple components
- Updated dependencies [60066416]
- Updated dependencies [6ddd465c]
  - @aileron/icon@2.0.0
  - @aileron/tag@1.5.4
