import '@aileron/icon';
import { Focusable } from '@aileron/shared/focusable';
import { Tailwind } from '@aileron/shared/tailwind-element';
import { html, LitElement } from 'lit';
import { property, queryAssignedElements } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

const TailwindLitElement = Tailwind(LitElement);

/**
 * Nav Link
 * @element adc-nav-link
 * @summary The nav link is used to display a list of navigation links in the Nav bar.
 * @slot Default - Text for the link.
 * @csspart title - Immediate parent of the text and icon.
 * @csspart expando - The button that wraps the title and icon.
 * @attr {string} icon - The icon to display.
 * @attr {boolean} disabled - `true` if the nav link should be disabled.
 * @attr {boolean} open - `true` if the nav link should be open.
 */
export class NavLink extends Focusable {
  static styles = [TailwindLitElement.styles || [], styles];
  @queryAssignedElements() unnamedSlotEls!: HTMLElement[];

  @property({ type: Boolean, reflect: true }) disabled = false;
  @property({ type: Boolean, reflect: true }) open = false;
  @property({ attribute: 'icon' }) icon = '';

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'listitem');
    }

    super.connectedCallback();
  }

  handleClick(): void {
    this.unnamedSlotEls[0].click();
  }

  render(): TemplateResult {
    const { disabled, open, icon } = this;

    return html` <button
      tabindex="-1"
      ?disabled="${disabled}"
      type="button"
      part="expando"
      @click="${this.handleClick}"
      class="adc-nav-bar__heading font-sans font-regular text-base line-height-6"
      aria-controls="content"
      aria-expanded=${open}
    >
      <span part="title" class="adc-nav-bar__title">
        <adc-icon size="24" icon=${icon}></adc-icon>
        <span
          class="adc-nav-bar_label font-sans font-regular text-xl line-height-6"
          ><slot></slot
        ></span>
      </span>
    </button>`;
  }
}

try {
  customElements.define('adc-nav-link', NavLink);
} catch (e) {
  // do nothing
}
