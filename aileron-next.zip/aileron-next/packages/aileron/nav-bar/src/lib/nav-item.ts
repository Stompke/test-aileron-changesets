import '@aileron/icon';
import { Focusable } from '@aileron/shared/focusable';
import { Tailwind } from '@aileron/shared/tailwind-element';
import { html, LitElement } from 'lit';
import { property, queryAssignedElements } from 'lit/decorators.js';
import { getBadgeIconName } from './nav-bar';
import styles from './styles.css?inline';
import type { LinkItem } from './link-item';
import type { TemplateResult } from 'lit';

const TailwindLitElement = Tailwind(LitElement);

/**
 * Nav item.
 * @element adc-nav-item
 * @summary The nav item is used to display a list of navigation items in the Nav bar.
 * @fires {CustomEvent<{ open: boolean; }>} adc-nav-item-beingtoggled - Event fired when the item is being
 * opened or closed.
 * @fires {CustomEvent<{ open: boolean; }>} adc-nav-item-toggled - Event fired when the item is opened or
 * closed.
 * @slot Default - The default slot for the nav item text.
 * @csspart content - The content of the item.
 * @csspart title - The title of the item.
 * @csspart expando - The expando of the item.
 * @csspart expando-icon - The expando icon of the item.
 *
 */
export class NavItem extends Focusable {
  static styles = [TailwindLitElement.styles || [], styles];
  @queryAssignedElements({ selector: 'adc-link-item' }) _listItems!: LinkItem[];

  get linkItems(): LinkItem[] {
    return this._listItems;
  }
  private _handleUserInitiatedToggle(open = !this.open) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      detail: {
        open,
      },
    };

    /**
     * @ignore
     */
    if (
      this.dispatchEvent(
        new CustomEvent(
          (this.constructor as typeof NavItem).eventBeforeToggle,
          init
        )
      )
    ) {
      if (!this.disabled) {
        this.open = open;

        /**
         * @ignore
         */
        this.dispatchEvent(
          new CustomEvent(
            (this.constructor as typeof NavItem).eventToggle,
            init
          )
        );
      }
    }
  }

  private _handleLinkItemSelect() {
    this._handleUserInitiatedToggle(!this.closeOnItemSelected);
  }

  private _handleClickExpando() {
    if (!this.toggleOff) {
      this._handleUserInitiatedToggle();
    }
  }

  private readonly _handleKeydownExpando = ({ key }: KeyboardEvent) => {
    if (!this.toggleOff) {
      if (this.open && (key === 'Esc' || key === 'Escape')) {
        this._handleUserInitiatedToggle(false);
      }
    }
  };

  /**
   * `true` if the NavItem item should be disabled.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /**
   * `true` if the NavItem item should be highlighted.
   */
  @property({ type: Boolean, reflect: true }) highlight = false;

  /**
   * `true` if the NavItem should be open.
   */
  @property({ type: Boolean, reflect: true }) open = false;

  /**
   * `true` if the NavItem toggle should be turned off. (i.e. turn of open and close NavItem)
   */
  @property({ type: Boolean, reflect: true, attribute: 'toggle-off' })
  toggleOff = false;

  /**
   * `true` if the NavItem should close when a nav-item is selected.
   */
  @property({
    type: Boolean,
    reflect: true,
    attribute: 'close-on-item-selected',
  })
  closeOnItemSelected = false;

  /**
   * The label text.
   */
  @property({ attribute: 'label-text' }) labelText = '';

  /**
   * The aria-label text.
   */
  @property({ attribute: 'a11y-label' }) a11yLabel = '';

  /**
   * The aileron icon to display based on icon text name provided.  For example: airport:waitlist
   */
  @property({ attribute: 'icon' }) icon = '';

  /**
   * The aileron icon to display outlined version of icon.  For example: <adc-icon icon="airport:waitlist" outlined></adc-icon>
   */
  @property({ type: Boolean, attribute: 'icon-outlined' }) iconOutlined = false;

  /**
   * Display the number of new items available in this section as a number icon.
   */
  @property({ type: Number, reflect: true, attribute: 'badge-count' })
  badgeCount = 0;

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'listitem');
    }

    super.connectedCallback();

    this.addEventListener('adc-link-item-click', this._handleLinkItemSelect);
  }

  disconnectedCallback(): void {
    super.disconnectedCallback();

    this.removeEventListener('adc-link-item-click', this._handleLinkItemSelect);
  }

  render(): TemplateResult {
    const {
      a11yLabel,
      disabled,
      highlight,
      open,
      toggleOff,
      labelText,
      icon,
      iconOutlined,
      _handleClickExpando,
      _handleKeydownExpando,
    } = this;

    return html` <button
        ?disabled="${disabled}"
        ?highlight="${highlight}"
        ?toggle-off="${toggleOff}"
        type="button"
        part="expando"
        class="adc-nav-bar__heading font-sans font-regular text-base line-height-6"
        aria-controls="content"
        aria-expanded=${open}
        @click="${_handleClickExpando}"
        @keydown="${_handleKeydownExpando}"
      >
        <span part="title" class="adc-nav-bar__title">
          <adc-icon
            aria-hidden="true"
            size="24"
            icon=${icon}
            ?outlined=${iconOutlined}
          ></adc-icon>
          <span
            aria-label="${a11yLabel}"
            class="adc-nav-bar_label font-sans font-regular text-xl line-height-6"
            >${labelText}</span
          >
          ${this.badgeCount && this.badgeCount > 0 && !this.open
            ? html`<div class="fullCircle">
                <adc-icon
                  icon="${getBadgeIconName(this.badgeCount)}"
                  size="24"
                  filled
                ></adc-icon>
              </div>`
            : html`<span></span> `}
        </span>

        ${this.toggleOff
          ? html`<span></span>`
          : html`<adc-icon
              icon="navigation:chevron-down"
              part="expando-icon"
              size="24"
              class="adc-nav-bar__icon chevron-down"
            ></adc-icon> `}
      </button>
      <div
        id="content"
        part="content"
        class="adc-nav-bar__content--wrapper"
        ?hidden=${!this.open}
      >
        <div
          class="adc-nav-bar__content font-sans font-regular text-base line-height-6"
        >
          <ul>
            <slot></slot>
          </ul>
        </div>
      </div>`;
  }

  /**
   * The name of the custom event fired before this accordion item is being
   * toggled upon a user gesture. Cancellation of this event stops the
   * user-initiated action of toggling this accordion item.
   */
  static get eventBeforeToggle(): string {
    return 'adc-nav-item-beingtoggled';
  }

  /**
   * The name of the custom event fired after this accordion item is toggled
   * upon a user gesture.
   */
  static get eventToggle(): string {
    return 'adc-nav-item-toggled';
  }
}

try {
  customElements.define('adc-nav-item', NavItem);
} catch (e) {
  // do nothing
}
