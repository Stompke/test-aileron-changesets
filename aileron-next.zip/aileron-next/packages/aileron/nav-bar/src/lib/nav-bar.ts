import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property, queryAll, queryAssignedElements } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';
import type { NavItem } from './nav-item';

/**
 * @ignore
 */
export function getBadgeIconName(value: number) {
  const units = [
    '',
    'one',
    'two',
    'three',
    'four',
    'five',
    'six',
    'seven',
    'eight',
    'nine',
  ];

  return `numerical:${units[value]}`;
}

/**
 * NavBar component
 * @element adc-nav-bar
 * @summary The nav bar is used to display a list of navigation items.
 * @attr {string} [a11y-label=''] - Text used for screen readers.
 * @slot Default - Expects nav-items and nav-links.
 */
export class NavBar extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  @queryAll('adc-nav-item') textNode!: HTMLElement;
  @queryAssignedElements({ selector: 'adc-nav-item' }) _listItems!: NavItem[];

  @property({ attribute: 'a11y-label' }) a11yLabel = '';

  render(): TemplateResult {
    return html`<slot></slot>`;
  }

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'navigation');
    }

    if (!this.hasAttribute('aria-label')) {
      this.setAttribute('aria-label', this.a11yLabel);
    }

    super.connectedCallback();
    this.addEventListener('adc-link-item-click', this._handleSelect);
  }

  disconnectedCallback(): void {
    super.disconnectedCallback();

    this.removeEventListener('adc-link-item-click', this._handleSelect);
  }

  _handleSelect() {
    const linkItems = this._listItems.map((node) => {
      return node.linkItems;
    });

    linkItems.forEach((items) => {
      items.forEach((item) => {
        item.clearSelected();
      });
    });
  }
}

try {
  customElements.define('adc-nav-bar', NavBar);
} catch (e) {
  // do nothing
}
