import './nav-bar';

describe('<adc-nav-bar>', () => {
  describe('should be accessible', () => {
    it('should be accessible', () => {
      document.body.innerHTML = `
        <h1>Custom element test</h1>
        <adc-nav-bar>
          <adc-nav-item label-text="Account summary" icon="airport:waitlist">
            <adc-link-item selected tag-name="NEW" badge-count="5"><a href="javascript:void(0)">Dashboard</a></adc-link-item>
            <adc-link-item tag-name="NEW" badge-count="3"><a href="javascript:void(0)">My benefits</a></adc-link-item>
            <adc-link-item><a href="javascript:void(0)">Activity</a></adc-link-item>
          </adc-nav-item>
        </adc-nav-bar>`;
      const accordion = document.querySelector('adc-nav-bar');

      expect(accordion?.nodeType).toBe(1);
    });
  });
});
