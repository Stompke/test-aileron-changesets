import '@aileron/icon';
import '@aileron/tag';
import { Tailwind } from '@aileron/shared/tailwind-element';
import { emit } from '@aileron/shared/event';
import { Focusable } from '@aileron/shared/focusable';
import { html, LitElement } from 'lit';
import { property, query, queryAssignedElements } from 'lit/decorators.js';
import { getBadgeIconName } from './nav-bar';
import styles from './styles.css?inline';
import type { TemplateResult, PropertyValues } from 'lit';

const TailwindLitElement = Tailwind(LitElement);

/**
 * LinkItem
 * @element adc-link-item
 * @summary Link items are used to navigate to different pages with in the nav-bar.
 * @fires {CustomEvent} adc-link-item-click - Event fired when the item is being selected.
 * @slot Default - Text for the link.
 */
export class LinkItem extends Focusable {
  static styles = [TailwindLitElement.styles || [], styles];
  @query('.link-item') textNode!: HTMLElement;
  @queryAssignedElements() unnamedSlotEls!: HTMLElement[];

  clearSelected() {
    this.textNode.classList.remove('selected');
  }

  @property({ type: Boolean, reflect: true }) route = false;
  @property({ type: Boolean, reflect: true }) selected = false;
  @property({ type: Number, reflect: true, attribute: 'badge-count' })
  badgeCount = 0;
  @property({ type: String, reflect: true, attribute: 'a11y-tag-text' })
  a11yTagText = '';
  @property({ type: String, reflect: true, attribute: 'a11y-role' }) a11yRole =
    'tab';
  @property({ type: String, reflect: true, attribute: 'a11y-badge-count-text' })
  a11yBadgeCountText = '';
  @property({ type: String, reflect: true, attribute: 'tag-name' }) tagName =
    '';

  /**
   * Keeps track of the number of link-item instances.
   * @private
   */
  static instanceCount = 0;

  _handleSelection() {
    this.unnamedSlotEls[0].click();
    emit(this, 'adc-link-item-click', {
      detail: { value: `adc-link-item-${LinkItem.instanceCount++}` },
    });
    this.textNode.classList.add('selected');
  }

  private readonly _handleKeydown = ({ key }: KeyboardEvent) => {
    if (key === 'Enter') {
      this._handleSelection();
    }
  };

  /**
   * Whenever the link is first rendered we set a unique id
   * @param changes
   */
  firstUpdated(changes: PropertyValues): void {
    super.firstUpdated(changes);

    if (!this.hasAttribute('id')) {
      this.id = `adc-link-item-${LinkItem.instanceCount++}`;
    }

    // Prevent routes or link passed into slot from being tabbable
    this.unnamedSlotEls[0].setAttribute('tabindex', '-1');
  }

  render(): TemplateResult {
    return html` <li>
      <div
        tabindex="0"
        role="${this.a11yRole as string}"
        aria-current=${this.selected}
        aria-selected=${this.selected}
        class="link-item font-sans font-regular text-base line-height-6 ${this
          .selected
          ? 'selected'
          : ''}"
        @click=${this._handleSelection}
        @keydown=${this._handleKeydown}
        part="link-item"
      >
        <slot></slot>
        <div class="badges">
          ${this.tagName
            ? html` <span aria-hidden="true" class="link-item-badge"
                  ><adc-tag
                    label-text="${this.tagName}"
                    position="rtl"
                    kind="success"
                    variant=""
                  ></adc-tag
                ></span>
                <span class="hidden-accessible">,${this.a11yTagText}</span>`
            : html`<span aria-hidden="true"></span> `}
          ${this.badgeCount && this.badgeCount > 0
            ? html`
                  <div aria-hidden="true" class="fullCircle"><adc-icon icon="${getBadgeIconName(
                    this.badgeCount
                  )}" size="24" filled></adc-icon></span></div>
                  <span class="hidden-accessible">,${
                    this.a11yBadgeCountText
                  }</span>`
            : html`<span aria-hidden="true"></span> `}
        </div>
      </div>
    </li>`;
  }
}

try {
  customElements.define('adc-link-item', LinkItem);
} catch (e) {
  // do nothing
}
