import './nav-bar';
import { html } from 'lit-html';

export default {
  title: 'Components/NavBar',
  component: 'adc-nav-bar',
};

const Template = (
  { open } = {
    open: false,
  }
) => {
  return html`
    <adc-nav-bar>
      <adc-nav-item
        toggle-off
        open
        label-text="Account summary"
        icon="airport:waitlist"
      >
        <adc-link-item selected tag-name="NEW" badge-count="5"
          ><a href="javascript:void(0)">Dashboard</a></adc-link-item
        >
        <adc-link-item tag-name="NEW" badge-count="3"
          ><a href="javascript:void(0)">My benefits</a></adc-link-item
        >
        <adc-link-item><a href="javascript:void(0)">Activity</a></adc-link-item>
      </adc-nav-item>
      <adc-nav-item label-text="Rewards" icon="aadvantage:instant-status-pass">
        <adc-link-item
          ><a href="javascript:void(0)"
            >Choice / Gifted rewards</a
          ></adc-link-item
        >
        <adc-link-item
          ><a href="javascript:void(0)">Enhance with miles</a></adc-link-item
        >
        <adc-link-item
          ><a href="javascript:void(0)">Rewards history</a></adc-link-item
        >
      </adc-nav-item>
      <adc-nav-item label-text="Wallet" icon="airport:wallet">
        <adc-link-item
          ><a href="javascript:void(0)">Promotions</a></adc-link-item
        >
        <adc-link-item new
          ><a href="javascript:void(0)">Rewards history</a></adc-link-item
        >
        <adc-link-item
          ><a href="javascript:void(0)">Payment methods</a></adc-link-item
        >
        <adc-link-item badge-count="1"
          ><a href="javascript:void(0)">Travel credit</a></adc-link-item
        >
      </adc-nav-item>
      <adc-nav-item
        open
        label-text="Profile / Settings"
        icon="operation:settings"
      >
        <adc-link-item badge-count="1"
          ><a href="javascript:void(0)">Personal information</a></adc-link-item
        >
        <adc-link-item badge-count="9"
          ><a href="javascript:void(0)"
            >Reserveration preferences</a
          ></adc-link-item
        >
        <adc-link-item
          ><a href="javascript:void(0)">Email and fare alerts</a></adc-link-item
        >
        <adc-link-item
          ><a href="javascript:void(0)">BeNotified</a></adc-link-item
        >
        <adc-link-item
          ><a href="javascript:void(0)">Book award travel</a></adc-link-item
        >
      </adc-nav-item>
      <adc-nav-link ?open=${open} icon="navigation:arrow-single-right"
        ><a href="javascript:void(0)">Logout</a>
      </adc-nav-link>
    </adc-nav-bar>
  `;
};

export const Default = (args) => Template(args);

Default.parameters = {
  jest: 'nav-bar.test.ts',
};
