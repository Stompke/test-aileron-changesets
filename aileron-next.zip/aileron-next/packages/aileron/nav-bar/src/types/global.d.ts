import { NavBar } from './nav-bar';
import { LinkItem } from './link-item.component';
import { NavItem } from './nav-item.component';
import { NavLink } from './nav-link.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-nav-bar': NavBar;
    'adc-link-item': LinkItem;
    'adc-nav-item': NavItem;
    'adc-nav-link': NavLink;
  }
}
