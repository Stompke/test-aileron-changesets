import { defineConfig } from 'vite';
import ViteTsConfigPathsPlugin from 'vite-tsconfig-paths';
import replace from '@rollup/plugin-replace';
import { env } from 'process';
import pkg from './package.json';

// https://vitejs.dev/config/
export default defineConfig({
  build: {
    lib: {
      entry: 'src/index.ts',
      name: '@aileron/nav-bar',
      fileName: () => `nav-bar.js`,
    },
    rollupOptions: {
      output: [
        {
          name: '@aileron/nav-bar',
          dir: `dist/packages/aileron/nav-bar/dist/nav-bar@${env.NODE_ENV === 'production' ? 'latest' : 'next'}`,
          format: 'umd',
        },
        {
          name: '@aileron/nav-bar',
          dir: `dist/packages/aileron/nav-bar/dist/nav-bar@${pkg.version}`,
          format: 'umd',
        },
      ],
      plugins: [
        replace({
          'process.env.NODE_ENV': JSON.stringify('production'),
          preventAssignment: true,
        }),
      ],
    },
  },
  plugins: [
    ViteTsConfigPathsPlugin({
      root: '../../../',
    }),
  ],
});
