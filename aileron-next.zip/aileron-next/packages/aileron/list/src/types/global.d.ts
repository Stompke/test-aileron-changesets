import { List } from './list';

declare global {
  interface HTMLElementTagNameMap {
    'adc-list': List;
  }
}
