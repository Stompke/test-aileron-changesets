import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * @ignore
 */
export const ICON_KIND = {
  SUCCESS: 'success',
  ERROR: 'error',
  DEFAULT: 'default',
} as const;

type IconKind = (typeof ICON_KIND)[keyof typeof ICON_KIND];

/**
 * List item
 * @element adc-list-item
 * @summary A list item is a component that is used to display information in all
 * list components.
 * @slot default - Set the content of the list item.
 * @slot nested - Used when a child is set as a nested list.
 * @attr {"success"|"error"|"default"} [kind="default"] - Display an icon if the list item is a
 * `success`, `error`, and nothing when `default`.
 * @attr {boolean} [nested=false] - Used when the list item is a parent of a nested list.
 */
export class ListItem extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @property({ type: String, reflect: false }) kind: IconKind =
    ICON_KIND.DEFAULT;
  @property({ type: Boolean, reflect: true }) nested = false;

  /**
   * @ignore
   */
  private _hasNestedChild = false;

  /**
   * Sets the private `_hasNestedChild` property. Forces
   * the re-rendering of the component.
   * @private
   */
  private _handleSlotChangeNested({ target }: Event) {
    this._hasNestedChild =
      (target as HTMLSlotElement).assignedNodes().length > 0;
    this.requestUpdate();
  }

  /**
   * Sets the prop `nested` to true if the parent element is a nested selector.
   * Also sets the role for a11y.
   */
  connectedCallback(): void {
    this.toggleAttribute(
      'nested',
      !!this.closest((this.constructor as typeof ListItem).selectorNestedList)
    );
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'listitem');
    }
    super.connectedCallback();
  }

  render(): TemplateResult {
    const {
      _hasNestedChild: hasNestedChild,
      _handleSlotChangeNested: handleSlotChangeNested,
    } = this;
    return html`
      <div
        class="font-sans font-regular text-base line-height-6 list-item text-neutral-000"
      >
        <adc-icon
          icon="signal:checkmark"
          class="relative -top-[3px] text-green-070 ${classMap({
            inline: this.kind === 'success',
            hidden: this.kind !== 'success',
          })}"
        ></adc-icon>
        <adc-icon
          icon="action:close"
          class="relative -top-[3px] text-red-070 ${classMap({
            inline: this.kind === 'error',
            hidden: this.kind !== 'error',
          })}"
        ></adc-icon>
        <slot></slot>
        <div ?hidden="${!hasNestedChild}">
          <slot name="nested" @slotchange="${handleSlotChangeNested}"></slot>
        </div>
      </div>
    `;
  }

  /**
   * @private
   */
  static get selectorNestedList(): string {
    return 'adc-ordered-list[slot="nested"],adc-unordered-list[slot="nested"]';
  }
}

try {
  customElements.define('adc-list-item', ListItem);
} catch (e) {
  // do nothing
}
