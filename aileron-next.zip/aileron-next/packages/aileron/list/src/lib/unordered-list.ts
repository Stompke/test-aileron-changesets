import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import styles from './styles.css?inline';

/**
 * Unordered list
 * @element adc-unordered-list
 * @summary An unordered list is a component that is used to display information in a
 * bullet list format.
 * @slot default - expecting adc-list-item
 */
export class UnorderedList extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  /**
   * If there is a parent list item, then the list is nested.
   */
  connectedCallback() {
    if (
      this.closest((this.constructor as typeof UnorderedList).selectorListItem)
    ) {
      this.setAttribute('slot', 'nested');
    } else {
      this.removeAttribute('slot');
    }

    super.connectedCallback();
  }

  protected render() {
    return html`
      <ul
        class="list-disc ps-24 m-0 ${classMap({
          'list-[circle]': this.getAttribute('slot') === 'nested',
        })}"
      >
        <slot></slot>
      </ul>
    `;
  }

  /**
   * @private
   */
  static get selectorListItem() {
    return 'adc-list-item';
  }
}

try {
  customElements.define('adc-unordered-list', UnorderedList);
} catch (e) {
  // do nothing
}
