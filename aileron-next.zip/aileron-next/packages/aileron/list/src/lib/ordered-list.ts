import { html } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { UnorderedList } from './unordered-list';

/**
 * Unordered list
 * @element adc-ordered-list
 * @summary An ordered list is a component that is used to display information in a
 * numbered list format.
 * @slot default - expecting adc-list-item
 */
export class OrderedList extends UnorderedList {
  render() {
    return html`
      <ol
        class="list-decimal ps-6 m-0 ${classMap({
          'list-[lower-latin]': this.getAttribute('slot') === 'nested',
        })}"
      >
        <slot></slot>
      </ol>
    `;
  }
}

try {
  customElements.define('adc-ordered-list', OrderedList);
} catch (e) {
  // do nothing
}
