import { OrderedList, ListItem, ICON_KIND } from '../index';
import '../index';

type IconKind = (typeof ICON_KIND)[keyof typeof ICON_KIND];

const kinds = [
  { kind: 'success', icon: 'checkmark' },
  { kind: 'error', icon: 'error' },
];

describe('<adc-list>', () => {
  let orderedList: OrderedList;
  let orderedListItem: ListItem;
  beforeEach(() => {
    document.body.innerHTML = `
    <adc-ordered-list>
      <adc-list-item>Item 1</adc-list-item>
      <adc-list-item>Item 2</adc-list-item>
      <adc-list-item>
        Item 3
        <adc-ordered-list id="nestedElement">
          <adc-list-item>First nested item</adc-list-item>
          <adc-list-item>Second nested item</adc-list-item>
          <adc-list-item>Third nested item</adc-list-item>
          <adc-list-item>Fourth nested item</adc-list-item>
          <adc-list-item>Fifth nested item</adc-list-item>
        </adc-ordered-list>
      </adc-list-item>
      <adc-list-item>Item 4</adc-list-item>
      <adc-list-item>Item 5</adc-list-item>
    </adc-ordered-list>
    `;
    orderedList = document.querySelector('adc-ordered-list') as OrderedList;
    orderedListItem = document.querySelector('adc-list-item') as ListItem;

    document.body.innerHTML = `
    <adc-unordered-list>
      <adc-list-item kind="default">Item 1</adc-list-item>
      <adc-list-item kind="default">Item 2</adc-list-item>
      <adc-list-item kind="default">Item 3</adc-list-item>
      <adc-list-item kind="default">Item 4</adc-list-item>
      <adc-list-item kind="default">Item 5</adc-list-item>
    </adc-unordered-list>
    `;
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(orderedList?.nodeType).toBe(1);
    });
    it('should have correct default values', () => {
      expect(orderedListItem?.kind).toBe('default');
      expect(orderedListItem.nested).toBe(false);
    });
    it('should render a order list', () => {
      const orderedElement = orderedList.shadowRoot?.querySelector('ol');
      expect(orderedElement).not.toBeNull();
    });
    it('should contain the class list-[lower-latin] when there are nested items', () => {
      const firstNestedItem = orderedList.querySelector('#nestedElement');
      const orderedElement = firstNestedItem?.shadowRoot?.querySelector('ol');
      expect(orderedElement?.classList.contains('list-[lower-latin]')).toBe(
        true
      );
    });
  });
  describe('when properties has been settled', () => {
    kinds.forEach((kind) => {
      it(`should contain the property kind: ${kind.kind}`, () => {
        orderedListItem.kind = kind.kind as IconKind;

        expect(orderedListItem?.kind).toBe(kind.kind);
      });
    });
  });
});
