import { Overflow } from './overflow';

declare global {
  interface HTMLElementTagNameMap {
    'adc-overflow': Overflow;
  }
}
