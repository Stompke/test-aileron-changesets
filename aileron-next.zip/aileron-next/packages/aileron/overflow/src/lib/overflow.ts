import '@aileron/button';
import { emit } from '@aileron/shared/event';
import { HostListenerMixin } from '@aileron/shared/host-listener';
import { html, LitElement } from 'lit';
import { property } from 'lit/decorators.js';
import type { TemplateResult } from 'lit';

/**
 * Overflow
 * @element adc-overflow
 * @summary A component that allows for content to be hidden and shown with a button.
 * @slot Default - slot to set the content of the overflow component
 * @fires {CustomEvent} adc-overflow-close - listens for a close event.
 * @fires {CustomEvent} adc-overflow-open - listens for a close event.
 * @attr {boolean} [disabled] - Disabled the buttons
 * @attr {boolean} [has-read-less-button] - Adds or Removes the "Read Less" button to the component
 * @attr {boolean} [open] - Open state of the component
 * @attr {string} [read-more-button-text] - "Read More" button text
 * @attr {string} [read-less-button-text] - "Read Less" button text
 */
export class Overflow extends HostListenerMixin(LitElement) {
  @property({ type: Boolean, reflect: true }) disabled = false;
  @property({ type: Boolean, attribute: 'has-read-less-button' }) hasReadLessButton = false;
  @property({ reflect: true, attribute: 'read-more-button-text' }) readMoreButtonText = 'Read More';
  @property({ reflect: true, attribute: 'read-less-button-text' }) readLessButtonText = 'Read Less';
  @property({ type: Boolean, reflect: true }) open = false;

  private handleToggleOpen() {
    if (this.open) {
      emit(this, 'adc-overflow-close');
    } else {
      emit(this, 'adc-overflow-open');
    }

    this.open = !this.open;
  }

  private getButtonText() {
    return this.open ? this.readLessButtonText : this.readMoreButtonText;
  }

  private shouldDisplayExtraContent() {
    // TODO this is extraneous currently but could be replaced with an event
    // observer
    return this.open;
  }

  private shouldDisplayToggleButton() {
    if (this.hasReadLessButton || !this.open) {
      return true;
    }
    return false;
  }

  _getToggleButton(): TemplateResult {
    return html`
      <adc-button ?disabled=${this.disabled} @click="${this.handleToggleOpen}">
        ${this.getButtonText()}
      </adc-button>
    `;
  }

  _getContent(): TemplateResult {
    return html`
      <div class="overflow-content">
        <slot></slot>
      </div>
    `;
  }

  render(): TemplateResult {
    return html`
      ${this.shouldDisplayExtraContent() ? this._getContent() : ''}
      ${this.shouldDisplayToggleButton() ? this._getToggleButton() : ''}
    `;
  }
}

try {
  customElements.define('adc-overflow', Overflow);
} catch (e) {
  // do nothing
}
