import type { Overflow } from './overflow';
import './overflow';

describe('<adc-overflow>', () => {
  let overflow: Overflow;
  beforeEach(() => {
    document.body.innerHTML = `
    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
      labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
      laboris nisi ut aliquip ex ea commodo consequat.
    </p>
    <adc-overflow>
      <p>
        Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
        pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum.
      </p>
      <p>
        Duis Overflow aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
        fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
        officia deserunt mollit anim id est laborum.
      </p>
      <img alt="" src="http://placekitten.com/g/200/300" />
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris</p>
      <img alt="" src="http://placekitten.com/g/400/300" />
    </adc-overflow>
    `;
    overflow = document.querySelector('adc-overflow') as Overflow;
  });
  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(overflow?.nodeType).toBe(1);
    });
    it('should have correct default values', () => {
      expect(overflow?.readMoreButtonText).toBe('Read More');
      expect(overflow?.readLessButtonText).toBe('Read Less');
      expect(overflow?.hasReadLessButton).toBe(false);
      expect(overflow?.disabled).toBe(false);
      expect(overflow?.open).toBe(false);
    });
    it('should display the read-more button', () => {
      const button = overflow.shadowRoot?.querySelector('adc-button');
      expect(button?.textContent?.trim()).toBe('Read More');
    });
  });
  describe('when properties has been settled', () => {
    it(`should display read-less button after clicking read-more button`, async () => {
      overflow.open = false;
      overflow.hasReadLessButton = true;
      await overflow.updateComplete;
      const button = overflow.shadowRoot
        ?.querySelector('adc-button')
        ?.shadowRoot?.querySelector('button') as HTMLButtonElement;
      const adcButton = overflow.shadowRoot?.querySelector(
        'adc-button'
      ) as HTMLButtonElement;
      button.click();
      overflow?.requestUpdate();
      await overflow?.updateComplete;
      expect(adcButton?.textContent?.trim()).toBe('Read Less');
    });
    it(`should open after clicking read-more button`, async () => {
      const button = overflow.shadowRoot
        ?.querySelector('adc-button')
        ?.shadowRoot?.querySelector('button') as HTMLButtonElement;
      button?.click();
      await overflow.updateComplete;
      expect(overflow?.open).toBe(true);
    });
    it(`should close after clicking read-less button`, async () => {
      overflow.open = true;
      overflow.hasReadLessButton = true;
      await overflow.updateComplete;
      const button = overflow.shadowRoot
        ?.querySelector('adc-button')
        ?.shadowRoot?.querySelector('button') as HTMLButtonElement;
      button.click();
      await overflow.updateComplete;
      expect(overflow?.open).toBe(false);
    });
    it('should display the content when open is true', async () => {
      overflow.open = true;
      overflow.requestUpdate();
      await overflow.updateComplete;
      const content = overflow?.shadowRoot?.querySelector('.overflow-content');
      expect(content).not.toBeNull();
    });

    it('should not display the content when open is false', async () => {
      overflow.open = false;
      await overflow.updateComplete;
      const content = overflow?.shadowRoot?.querySelector('.overflow-content');
      expect(content).toBeNull();
    });
    it('should disable the <adc-button> when disabled is true', async () => {
      overflow.disabled = true;
      overflow.requestUpdate();
      await overflow.updateComplete;
      expect(
        overflow?.shadowRoot?.querySelector('adc-button[disabled]')
      ).not.toBeNull();
    });
    it('should change the read-more button text', async () => {
      overflow.readMoreButtonText = 'Testing read more text';
      overflow.open = false;
      overflow.hasReadLessButton = false;
      await overflow.updateComplete;
      expect(overflow?.readMoreButtonText).toBe('Testing read more text');
    });
    it('should change the read-less button text', async () => {
      overflow.readMoreButtonText = 'Testing read less text';
      overflow.open = true;
      overflow.hasReadLessButton = true;
      overflow.requestUpdate();
      await overflow.updateComplete;
      expect(overflow?.readMoreButtonText).toBe('Testing read less text');
    });
    it('should not display the read-less button when hasReadLessButton is false', async () => {
      overflow.readMoreButtonText = 'Testing read less text';
      overflow.open = true;
      overflow.hasReadLessButton = false;
      overflow.requestUpdate();
      await overflow.updateComplete;
      const button = overflow.shadowRoot?.querySelector('adc-button');
      expect(button).toBeNull();
    });
  });
});
