# @aileron/overflow

## 1.5.9-next.0

### Patch Changes

- d41e2d29: version bump
- Updated dependencies [d41e2d29]
  - @aileron/button@1.7.5-next.0
