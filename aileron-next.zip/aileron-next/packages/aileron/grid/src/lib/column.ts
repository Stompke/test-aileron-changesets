import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Column
 * @element adc-column
 * @summary A column is a container for content.
 * @slot Default - Content rendered inside the column.
 */
export class Column extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  /**
   * Sets the column width for desktop by number of columns.
   * @type {number}
   */
  @property({ attribute: 'col-desktop', type: Number }) colDesktop = 0;

  /**
   * Sets the column width for tablet by number of columns.
   * @type {number}
   */
  @property({ attribute: 'col-tablet', type: Number }) colTablet = 0;

  /**
   * Sets the column width for phone by number of columns.
   * @type {number}
   */
  @property({ attribute: 'col-phone', type: Number }) colPhone = 0;

  /**
   * Sets the column offset for desktop by number of columns.
   * @type {number}
   */
  @property({ attribute: 'col-desktop-offset', type: Number })
  colDesktopOffset = 0;

  /**
   * Sets the column offset for tablet by number of columns.
   * @type {number}
   */
  @property({ attribute: 'col-tablet-offset', type: Number })
  colTabletOffset = 0;

  /**
   * Sets the column offset for phone by number of columns.
   * @type {number}
   */
  @property({ attribute: 'col-phone-offset', type: Number }) colPhoneOffset = 0;

  render(): TemplateResult {
    return html`<slot></slot>`;
  }
}

try {
  customElements.define('adc-column', Column);
} catch (e) {
  // do nothing
}
