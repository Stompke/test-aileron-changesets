import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Grid row
 * @element adc-row
 * @summary A row is a container for columns.
 * @slot Default - Accepts adc-column
 */
export class Row extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * This is set from adc-grid whenever form is set to true.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true, attribute: 'has-form' })
  hasForm = false;

  /**
   * This is set from adc-grid whenever reverse is set to true.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) reverse = false;

  render(): TemplateResult {
    return html`<slot></slot>`;
  }
}

try {
  customElements.define('adc-row', Row);
} catch (e) {
  // do nothing
}
