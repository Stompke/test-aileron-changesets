import { AileronElement } from '@aileron/shared/aileron-element';
import { forEach } from '@aileron/utilities/foreach';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { Row } from './row';
import type { TemplateResult, PropertyValues } from 'lit';

/**
 * @ignore
 */
export const GRID_POSITION = {
  START: 'start',
  END: 'end',
  CENTER: 'center',
  EMPTY: '',
} as const;

type GridPosition = (typeof GRID_POSITION)[keyof typeof GRID_POSITION];

/**
 * Grid
 * @element adc-grid
 * @summary A grid is a container for rows and columns.
 * @slot Default - Accepts adc-row
 * @attr {"start"|"end"|"center"|""} [position=''] - Sets the position of the grid based on flex.
 */
export class Grid extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * Sets the position of the grid based on flex.
   * @type {"start"|"end"|"center"|""}
   */
  @property({ type: String }) position: GridPosition = GRID_POSITION.EMPTY;

  /**
   * Sets the child rows to render in reverse order.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) reverse = false;

  /**
   * Sets the flush property on the grid, which uses padding instead of margin.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) flush = false;

  /**
   * Set to true if the grid is used within a form.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) form = false;

  /**
   * Set nested to true if the grid is used within another grid.
   * @type {boolean}
   */
  @property({ type: Boolean, reflect: true }) nested = false;

  render(): TemplateResult {
    return html`<slot></slot>`;
  }

  /**
   * If the parent DOM node is an adc-column, then it is a nested grid.
   */
  connectedCallback(): void {
    super.connectedCallback();
    if (this.closest('adc-column')) {
      this.nested = true;
    }
  }

  updated(changedProperties: PropertyValues): void {
    const { selectorGridRow } = this.constructor as typeof Grid;

    if (changedProperties.has('reverse')) {
      const { reverse } = this;

      forEach(this.querySelectorAll(selectorGridRow), (elem) => {
        (elem as Row).reverse = reverse;
      });
    }

    if (changedProperties.has('form')) {
      const { form } = this;
      forEach(this.querySelectorAll(selectorGridRow), (elem) => {
        (elem as Row).hasForm = form;
      });
    }
  }

  /**
   * @private
   */
  static get selectorGridRow(): string {
    return 'adc-row';
  }
}

try {
  customElements.define('adc-grid', Grid);
} catch (e) {
  // do nothing
}
