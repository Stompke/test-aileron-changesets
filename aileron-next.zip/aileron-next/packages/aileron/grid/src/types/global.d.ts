import { Grid } from './grid';
import { Row } from './row.component';
import { Column } from './column.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-grid': Grid;
    'adc-row': Row;
    'adc-column': Column;
  }
}
