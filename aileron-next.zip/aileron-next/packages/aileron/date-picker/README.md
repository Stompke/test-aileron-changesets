# @aileron/date-picker

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build @aileron/date-picker` to build the library.

## Running unit tests

Run `nx test @aileron/date-picker` to execute the unit tests via [Vite](https://vitest.dev/).
