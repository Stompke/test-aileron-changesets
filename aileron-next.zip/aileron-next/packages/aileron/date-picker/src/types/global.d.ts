import { DatePicker } from './date-picker';
import { CalendarNavigation } from './calendar-navigation.component';
import { Calendar } from './calendar.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-date-picker': DatePicker;
    'adc-adc-calendar-navigation': CalendarNavigation;
    'adc-calendar': Calendar;
  }
}
