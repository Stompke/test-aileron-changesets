import { AileronElement } from '@aileron/shared/aileron-element';
import { emit } from '@aileron/shared/event';
import '@aileron/button-icon';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css';

/**
 * @element adc-calendar-navigation
 * @private
 */
export class CalendarNavigation extends AileronElement {
  @property({ attribute: 'label-text' }) labelText!: string;
  @property({ type: Boolean }) disabled = false;
  @property() icon!: string;
  static styles = [AileronElement.styles || [], styles];

  clickHandler() {
    emit(this, 'adc-click');
  }

  render() {
    return html`
      <adc-button-icon
        icon=${this.icon}
        size="md"
        outlined
        class="calendar__button"
        type="button"
        kind="ghost"
        @click=${this.clickHandler}
        ?disabled=${this.disabled}
      >
        <slot>${this.labelText}</slot>
      </adc-button-icon>
    `;
  }
}

try {
  customElements.define('adc-calendar-navigation', CalendarNavigation);
} catch (e) {
  // do nothing
}

declare global {
  interface HTMLElementTagNameMap {
    'adc-calendar-navigation': CalendarNavigation;
  }
}
