import { emit } from '@aileron/shared/event';
import '@aileron/button-icon';
import { configureStore } from '@reduxjs/toolkit';
import {
  parseISO,
  isSameMonth,
  isThisYear,
  isBefore,
  isAfter,
  startOfDay,
  add,
} from 'date-fns';
import format from 'date-fns/format';
import * as locales from 'date-fns/locale';
import startOfWeek from 'date-fns/startOfWeek';
import { html, PropertyValues } from 'lit';
import { property, state, queryAll, query } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { styleMap } from 'lit/directives/style-map.js';
import './calendar-navigation.component';
import calendarSlice, {
  decrementMonth,
  incrementMonth,
  setFirstSelection,
  setSecondSelection,
  buildCalendar,
  clearCalendar,
  setShowMultipleMonths,
  setState,
  MonthState,
  ReduxState,
  DayState,
} from './calendar.slice';
import styles from './styles.css?inline';
import type { Unsubscribe, Store } from 'redux';
import { AileronElement } from '@aileron/shared/aileron-element';

const iconNumberMap: Record<string, string> = {
  '1': 'numerical:one',
  '2': 'numerical:two',
  '3': 'numerical:three',
  '4': 'numerical:four',
  '5': 'numerical:five',
  '6': 'numerical:six',
  '7': 'numerical:seven',
  '8': 'numerical:eight',
  '9': 'numerical:nine',
  '10': 'numerical:ten',
  '11': 'numerical:eleven',
  '12': 'numerical:twelve',
  '13': 'numerical:thirteen',
  '14': 'numerical:fourteen',
  '15': 'numerical:fifteen',
  '16': 'numerical:sixteen',
  '17': 'numerical:seventeen',
  '18': 'numerical:eighteen',
  '19': 'numerical:nineteen',
  '20': 'numerical:twenty',
  '21': 'numerical:twenty-one',
  '22': 'numerical:twenty-two',
  '23': 'numerical:twenty-three',
  '24': 'numerical:twenty-four',
  '25': 'numerical:twenty-five',
  '26': 'numerical:twenty-six',
  '27': 'numerical:twenty-seven',
  '28': 'numerical:twenty-eight',
  '29': 'numerical:twenty-nine',
  '30': 'numerical:thirty',
  '31': 'numerical:thirty-one',
};

const availableArrowsByDirection = [
  'ArrowLeft',
  'ArrowRight',
  'ArrowUp',
  'ArrowDown',
];

const doubleCalendarMinWidth = 704;
const doubleCalendarMaxWidth = 762;
const singleCalendarMinWidth = 296;
const singleCalendarMaxWidth = 406;

const getCalendarWidth = ({
  showMultipleMonths,
  offsetWidth,
}: {
  showMultipleMonths: boolean;
  offsetWidth: number;
}) => {
  let newWidth: number;

  if (showMultipleMonths) {
    if (
      offsetWidth >= doubleCalendarMinWidth &&
      offsetWidth <= doubleCalendarMaxWidth
    ) {
      newWidth = offsetWidth;
    } else {
      if (offsetWidth > doubleCalendarMaxWidth) {
        newWidth = doubleCalendarMaxWidth;
      } else {
        newWidth = doubleCalendarMinWidth;
      }
    }
    newWidth = (newWidth - 8) / 2; // subract gap & divide total width for 2 calendars
  } else {
    if (offsetWidth > singleCalendarMinWidth) {
      if (offsetWidth < singleCalendarMaxWidth) {
        newWidth = offsetWidth;
      } else {
        newWidth = singleCalendarMaxWidth;
      }
    } else {
      newWidth = singleCalendarMinWidth;
    }
  }

  return newWidth;
};

const underscoreToHyphen = (value: string) => {
  if (value?.includes('_')) {
    return value.replace('_', '-');
  }
  return value;
};

const getCookie = (name: string) => {
  const cookies = document.cookie.split('; ');
  for (const cookie of cookies) {
    const singleCookie = cookie.split('=');
    if (singleCookie[0] === name) {
      return singleCookie[1];
    }
  }
  return null;
};

const getDefaultLocale = () => {
  const urlLocale = new URLSearchParams(location.search).get('locale');
  if (urlLocale) return underscoreToHyphen(urlLocale);

  const cookieLocale = getCookie('sessionLocale');

  if (cookieLocale) return underscoreToHyphen(cookieLocale);

  return 'en-US';
};

/**
 * Calendar
 * @element adc-calendar
 * @attr {string} [locale] - Locale code. Examples are 'en-US', 'fr-FR',
 * @attr {string} [weekday-format] - How the weekday names are represented. Options are "short" or "narrow". Defaults to "narrow"
 * @attr {string} [min-date-string] - The minimum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
 * @attr {string} [max-date-string] - The maximum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
 * @attr {number} [max-days-out] - The maximum number of days out that can be selected.
 * @attr {boolean} [show-current-year] - Shows the current year next to month name.
 * @attr {boolean} [show-price] - Shows price next to date
 * @attr {boolean} [single-day-selection] - Calendar only selects one day, not a range of days.
 * @attr {boolean} [manual-selection] - firstSelection and secondSelection dates are only selected after user has specified to do so, by clicking the appropriate tab or text input.
 * @attr {boolean} [enable-past-selection] - Able to select days in the past
 * @attr {boolean} [show-multiple-months] - Whether calendar shows two months or one month
 * @fires adc-select - listens for a selection of a date
 * @fires adc-next-month-animation-start - listens for next month animation to start
 * @fires adc-next-month-animation-end - listens for next month animation to end
 * @fires adc-prev-month-animation-start - listens for previous month animation to start
 * @fires adc-prev-month-animation-end - listens for previous month animation to end
 */

export class Calendar extends AileronElement {
  private storeUnsubscribe!: Unsubscribe;

  @property({ type: Object })
  store: Store = configureStore({
    devTools: {
      name: '@aileron/calendar',
      trace: true,
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
    reducer: {
      calendar: calendarSlice,
    },
  });

  connectedCallback() {
    super.connectedCallback();
    this.storeUnsubscribe = this.store.subscribe(() =>
      this.stateChanged(this.store.getState())
    );
    this.stateChanged(this.store.getState());

    addEventListener('resize', this.setSizes);
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    this.storeUnsubscribe();
    removeEventListener('resize', this.setSizes);
  }

  /**
   * @private
   */
  static styles = [AileronElement.styles || [], styles];

  @state() month!: MonthState[];
  @state() currentDate!: string;
  @state() firstSelection!: string;
  @state() secondSelection!: string;
  @state() modifyFirstSelection!: boolean;
  @state() dateFnsLocale!: string;

  @queryAll('.calendar__grid')
  calendarGridContainer!: HTMLDivElement[];

  @queryAll('.calendar__day')
  calendarDays!: HTMLDivElement[];

  @queryAll('.calendar')
  calendars!: HTMLDivElement[];

  @queryAll('.calendar__day--price')
  prices!: HTMLDivElement[];

  @query('.multiple-calendars')
  multipleCalendars: any;

  @query('.adc-calendar-day--has-focus')
  focusedDate: any;

  private _locale = 'en-US';

  set locale(val: string) {
    const oldVal = this._locale;
    if (val === '') {
      this._locale = getDefaultLocale();
    } else {
      this._locale = underscoreToHyphen(val);
    }
    this.requestUpdate('locale', oldVal);
  }

  /**
   * Locale code. Examples are 'en-US', 'fr-FR',
   * @attr {string} [locale]
   * @type {string}
   */
  @property({ reflect: true })
  get locale() {
    return this._locale;
  }

  /**
   * The minimum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
   * @attr {string} [min-date-string]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'min-date-string' })
  minDateString!: string;

  /**
   * The maximum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
   * @attr {string} [max-date-string]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'max-date-string' })
  maxDateString!: string;

  /**
   * The maximum number of days out that can be selected.
   * @attr {number} [max-days-out]
   * @type {number}
   */
  @property({ reflect: true, attribute: 'max-days-out' }) maxDaysOut!: number;

  /**
   * How the weekday names are represented. Options are "short" or "narrow". Defaults to "narrow"
   * @attr {string} [weekday-format]
   * @type {string}
   */
  @property({
    reflect: true,
    attribute: 'weekday-format',
    converter: (value) => {
      if (value === 'short' || value === 'narrow') {
        return value;
      }
      return 'narrow';
    },
  })
  weekdayFormat = 'narrow';

  /**
   * Shows the current year next to month name
   * @attr {boolean} [show-current-year]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'show-current-year' })
  showCurrentYear = false;

  /**
   * Shows price next to date
   * @attr {boolean} [show-price]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'show-price' })
  showPrice = false;

  /**
   * Whether calendar shows two months or one month
   * @attr {boolean} [show-multiple-months]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'show-multiple-months' })
  showMultipleMonths = true;

  /**
   * Calendar only selects one day, not a range of days.
   * @attr {boolean} [single-day-selection]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'single-day-selection' })
  singleDaySelection = false;

  /**
   * firstSelection and secondSelection dates are only selected after user has specified to do so, by clicking the appropriate tab or text input.
   * @attr {boolean} [manual-selection]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'manual-selection' })
  manualSelection = false;

  /**
   * Able to select days in the past
   * @attr {boolean} [enablePastSelection]
   * @type {boolean}
   */
  @property({ type: Boolean, attribute: 'enable-past-selection' })
  enablePastSelection = false;

  setSizes = async () => {
    if (this.offsetWidth !== 0) {
      this.handlePriceSizes();

      await this.updateComplete;
      this.calendars.forEach(
        (calendar) =>
          (calendar.style.width = `${getCalendarWidth({
            showMultipleMonths: this.showMultipleMonths,
            offsetWidth: this.offsetWidth,
          })}px`)
      );

      this.multipleCalendars.style.marginLeft = `-${
        getCalendarWidth({
          showMultipleMonths: this.showMultipleMonths,
          offsetWidth: this.offsetWidth,
        }) + 8
      }px`;
    }
  };

  stateChanged(calendarState: ReduxState) {
    this.month = calendarState.calendar.month;
    this.currentDate = calendarState.calendar.currentDate;
    this.firstSelection = calendarState.calendar.firstSelection;
    this.secondSelection = calendarState.calendar.secondSelection;
    this.modifyFirstSelection = calendarState.calendar.modifyFirstSelection;
    this.dateFnsLocale = calendarState.calendar.dateFnsLocale;
    this.requestUpdate();
  }

  async handlePriceSizes() {
    // Set calendar price styles
    await this.updateComplete;
    if (this.offsetWidth < 358) {
      this.prices.forEach((price) => (price.style.transform = 'scale(.75)'));
      this.prices.forEach((price) => (price.style.bottom = '0'));
    } else {
      this.prices.forEach((price) => (price.style.transform = ''));
      this.prices.forEach((price) => (price.style.bottom = ''));
    }
  }

  protected firstUpdated() {
    this.store.dispatch(clearCalendar());
    this.store.dispatch(
      buildCalendar({
        date: this.currentDate,
      })
    );
    this.setSizes();

    this.multipleCalendars.addEventListener('transitionend', () => {
      const classesToRemove = ['transition-transform', 'duration-200'];

      if (this.multipleCalendars.style.transform.includes('-')) {
        // Increment Month
        this.store.dispatch(incrementMonth());
        emit(this, 'adc-next-month-animation-end');
      } else if (!this.multipleCalendars.style.transform.includes('-')) {
        // Decrement Month
        this.store.dispatch(decrementMonth());
        emit(this, 'adc-prev-month-animation-end');
      }

      // Remove all transition classes
      classesToRemove.forEach((classToRemove) =>
        this.multipleCalendars.classList.remove(classToRemove)
      );

      // Hide other calendars after transition (mainly for screen readers)
      this.calendars.forEach((calendar, index) =>
        index === 0 || index === 3 || (!this.showMultipleMonths && index === 2)
          ? calendar.classList.add('invisible')
          : null
      );

      this.multipleCalendars.style.transform = `none`;
    });
  }

  updated(changedProperties: PropertyValues) {
    if (changedProperties.has('locale')) {
      if (this.locale.split('-').length === 1) {
        this.store.dispatch(
          setState({ name: 'dateFnsLocale', value: this.locale })
        ); // "en" => "en"
      } else {
        const joinedLocale = this.locale.split('-').join('');

        if ((locales as any)[joinedLocale] !== undefined) {
          this.store.dispatch(
            setState({ name: 'dateFnsLocale', value: joinedLocale })
          ); // "en-US" => "enUS"
        } else {
          this.store.dispatch(
            setState({
              name: 'dateFnsLocale',
              value: this.locale.split('-')[0],
            })
          ); // "fr-FR" => "fr"
        }
      }

      this.store.dispatch(setState({ name: 'locale', value: this.locale }));
    }

    if (changedProperties.has('showMultipleMonths')) {
      this.store.dispatch(
        setShowMultipleMonths(!changedProperties.get('showMultipleMonths'))
      );
    }
  }

  nextMonthAnimation(multipleCalendars: HTMLElement) {
    emit(this, 'adc-next-month-animation-start');
    this.calendars.forEach((calendar) =>
      calendar.classList.remove('invisible')
    );
    multipleCalendars.classList.add('transition-transform');
    multipleCalendars.classList.add('duration-200');
    multipleCalendars.style.transform = `translateX(-${
      getCalendarWidth({
        showMultipleMonths: this.showMultipleMonths,
        offsetWidth: this.offsetWidth,
      }) + 8
    }px)`;
  }
  prevMonthAnimation(multipleCalendars: HTMLElement) {
    emit(this, 'adc-prev-month-animation-start');
    this.calendars.forEach((calendar) =>
      calendar.classList.remove('invisible')
    );
    multipleCalendars.classList.add('transition-transform');
    multipleCalendars.classList.add('duration-200');
    multipleCalendars.style.transform = `translateX(${
      getCalendarWidth({
        showMultipleMonths: this.showMultipleMonths,
        offsetWidth: this.offsetWidth,
      }) + 8
    }px)`;
  }

  handleSelectDay(date: string, isDisabled: boolean, beforeDeparture: boolean) {
    if (!isDisabled) {
      if (this.singleDaySelection) {
        this.store.dispatch(
          setFirstSelection({
            firstSelection: date,
            manualSelection: this.manualSelection,
          })
        );
      } else if (this.manualSelection) {
        if (this.modifyFirstSelection) {
          this.store.dispatch(
            setFirstSelection({
              firstSelection: date,
              manualSelection: this.manualSelection,
            })
          );
        } else {
          this.store.dispatch(
            setSecondSelection({
              secondSelection: date,
              manualSelection: this.manualSelection,
            })
          );
        }
      } else {
        // Automatic Selection

        if (!this.firstSelection || beforeDeparture) {
          this.store.dispatch(
            setFirstSelection({
              firstSelection: date,
              manualSelection: this.manualSelection,
            })
          );
        } else if (!this.secondSelection) {
          this.store.dispatch(
            setSecondSelection({
              secondSelection: date,
              manualSelection: this.manualSelection,
            })
          );
        } else {
          this.store.dispatch(
            setFirstSelection({
              firstSelection: date,
              manualSelection: this.manualSelection,
            })
          );
        }
      }

      emit(this, 'adc-select');
    }
  }

  disableMonthButton() {
    if (this.enablePastSelection) return false;

    if (
      this.month.length &&
      isSameMonth(
        parseISO(this.currentDate),
        parseISO(this.month[1].name as string)
      )
    ) {
      return true;
    }
    return false;
  }

  handleGridRangeOver(e: Event, monthIndex: number) {
    const firstCalendarGrid = this.calendarGridContainer[1];
    const secondCalendarGrid = this.calendarGridContainer[2];

    // Adds to one calendar grid
    if (monthIndex === 1) {
      firstCalendarGrid.classList.add('calendar__grid-range-hover');
    } else if (monthIndex === 2) {
      // Adds to both calendar grids
      firstCalendarGrid.classList.add('calendar__grid-range-hover');
      secondCalendarGrid.classList.add('calendar__grid-range-hover');
    }

    // Adds to individual hovered day
    (e.target as HTMLElement).parentElement?.classList.add('hovered-day');
  }

  handleGridRangeOut(e: Event) {
    // Removes from all calendar grids
    this.calendarGridContainer.forEach((calendar) => {
      calendar.classList.remove('calendar__grid-range-hover');
    });

    // removes from individual hovered day
    (e.target as HTMLElement).parentElement?.classList.remove('hovered-day');
  }

  createMonthName(date: string) {
    if (
      // show year w/ month name if showCurrentYear is true
      this.showCurrentYear ||
      // show year w/ month name if Year is not current dates Year
      !isThisYear(parseISO(date))
    ) {
      return parseISO(date).toLocaleString(this.locale, {
        month: 'long',
        year: 'numeric',
      });
    }
    return parseISO(date).toLocaleString(this.locale, { month: 'long' });
  }

  startListeningToKeyboard() {
    this.addEventListener('keydown', this.handleKeydown);

    const stopListeningToKeyboard = () => {
      this.removeEventListener('keydown', this.handleKeydown);

      this.removeEventListener('focusout', stopListeningToKeyboard);
    };

    this.addEventListener('focusout', stopListeningToKeyboard);
  }

  handleKeydown(event: KeyboardEvent) {
    const { code } = event;
    if (!availableArrowsByDirection.includes(code)) {
      return;
    }

    const selectMonthWrapperElement =
      this.focusedDate.parentElement.parentElement.parentElement.parentElement;
    const dateParentElement = this.focusedDate.parentElement;

    if (code === 'ArrowRight') {
      if (dateParentElement.nextElementSibling) {
        dateParentElement.nextElementSibling
          .querySelector('.calendar__day')
          .focus();
      } else if (this.showMultipleMonths) {
        if (selectMonthWrapperElement.nextElementSibling) {
          selectMonthWrapperElement.nextElementSibling
            .querySelector('.calendar__grid')
            .firstElementChild.querySelector('.calendar__day')
            .focus();
        }
      }
    } else if (code === 'ArrowLeft') {
      if (dateParentElement.previousElementSibling) {
        dateParentElement.previousElementSibling
          .querySelector('.calendar__day')
          .focus();
      } else if (this.showMultipleMonths) {
        if (selectMonthWrapperElement.previousElementSibling) {
          selectMonthWrapperElement.previousElementSibling
            .querySelector('.calendar__grid')
            .lastElementChild.querySelector('.calendar__day')
            .focus();
        }
      }
    } else if (code === 'ArrowUp') {
      let currentFocusedDateParent = dateParentElement;
      let count = 0;
      for (let i = 0; i < 7; i++) {
        if (!currentFocusedDateParent.previousElementSibling) {
          if (this.showMultipleMonths) {
            if (selectMonthWrapperElement.previousElementSibling) {
              let currentFocusedDayEndOfMonth =
                selectMonthWrapperElement.previousElementSibling.querySelector(
                  '.calendar__grid'
                ).lastElementChild;

              for (i = 1; i < 7 - count; i++) {
                currentFocusedDayEndOfMonth =
                  currentFocusedDayEndOfMonth.previousElementSibling;
              }
              currentFocusedDayEndOfMonth
                .querySelector('.calendar__day')
                .focus();
            }
          }
          return;
        }
        count++;
        currentFocusedDateParent =
          currentFocusedDateParent.previousElementSibling;
      }
      currentFocusedDateParent.querySelector('.calendar__day').focus();
    } else if (code === 'ArrowDown') {
      let currentFocusedDateParent = dateParentElement;
      let count = 0;
      for (let i = 0; i < 7; i++) {
        if (!currentFocusedDateParent.nextElementSibling) {
          if (this.showMultipleMonths) {
            if (selectMonthWrapperElement.nextElementSibling) {
              let currentFocusedDayBegginingOfMonth =
                selectMonthWrapperElement.nextElementSibling.querySelector(
                  '.calendar__grid'
                ).firstElementChild;
              for (i = 1; i < 7 - count; i++) {
                currentFocusedDayBegginingOfMonth =
                  currentFocusedDayBegginingOfMonth.nextElementSibling;
              }
              currentFocusedDayBegginingOfMonth
                .querySelector('.calendar__day')
                .focus();
            }
          }
          return;
        }
        count++;
        currentFocusedDateParent = currentFocusedDateParent.nextElementSibling;
      }
      currentFocusedDateParent.querySelector('.calendar__day').focus();
    }

    event.preventDefault();
  }

  handleFocus(e: Event) {
    (e.target as HTMLElement).classList.add('adc-calendar-day--has-focus');
  }

  handleBlur(e: Event) {
    (e.target as HTMLElement).classList.remove('adc-calendar-day--has-focus');
  }

  render() {
    this.setSizes();
    const createWeekdays = () => {
      return html`
        <div
          class="calendar__weekdays text-center grid grid-cols-7 m-2 w-full justify-items-center
      ${classMap({
            'first:pr-8': this.showMultipleMonths,
          })}
      "
        >
          ${Array(7)
            .fill(null)
            .map((_, index) => {
              const startDate = startOfWeek(new Date(), {
                locale: (locales as any)[this.dateFnsLocale],
              });
              const indexDay = new Date(
                startDate.getFullYear(),
                startDate.getMonth(),
                startDate.getDate() + index
              );
              let weekdayType;
              if (this.weekdayFormat === 'short') {
                weekdayType = 'E';
              } else {
                weekdayType = 'EEEEE';
              }
              const result = format(indexDay, weekdayType, {
                locale: (locales as any)[this.dateFnsLocale],
              });
              return html`
                <div
                  class="calendar__weekday flex items-center justify-center rounded text-neutral-060 w-48 h-48 m-2 bg-transparent text-[14px] font-['AmericanSans'] font-[400] leading-[1rem] tracking-[.01rem]"
                >
                  ${result}
                </div>
              `;
            })}
        </div>
      `;
    };
    return html`
      <div
        class="overflow-hidden
          ${classMap({
          'max-w-[406px]': !this.showMultipleMonths,
          'min-w-[296px]': !this.showMultipleMonths,
          'max-w-[762px]': this.showMultipleMonths,
          'min-w-[704px]': this.showMultipleMonths,
        })}
        "
      >
        <!-- Arrows container -->
        <div class="relative">
          <div
            class="calendar__navigation--container flex absolute top-0 z-10 w-full
            ${classMap({
              'max-w-[406px]': !this.showMultipleMonths,
              'min-w-[296px]': !this.showMultipleMonths,
              'max-w-[762px]': this.showMultipleMonths,
              'min-w-[704px]': this.showMultipleMonths,
            })}
            "
          >
            <div class="m-2 w-full justify-between flex">
              ${html`<adc-calendar-navigation
                  ?disabled=${this.disableMonthButton()}
                  class="p-2 bg-neutral-140 ${classMap({
                    'pointer-events-none': this.disableMonthButton(),
                  })}"
                  icon="navigation:chevron-left"
                  @click=${() =>
                    this.prevMonthAnimation(this.multipleCalendars)}
                  >Previous Month</adc-calendar-navigation
                >
                <adc-calendar-navigation
                  class="p-2 bg-neutral-140"
                  icon="navigation:chevron-right"
                  @click=${() =>
                    this.nextMonthAnimation(this.multipleCalendars)}
                  >Next Month</adc-calendar-navigation
                > `}
            </div>
          </div>
        </div>

        <!-- Week Days Container -->

        <div class="relative">
          <div
            class="flex absolute top-[64px] w-full
          ${classMap({
              'max-w-[406px]': !this.showMultipleMonths,
              'min-w-[296px]': !this.showMultipleMonths,
              'max-w-[762px]': this.showMultipleMonths,
              'min-w-[704px]': this.showMultipleMonths,
            })}
          "
          >
            ${createWeekdays()}
            ${this.showMultipleMonths ? createWeekdays() : ''}
          </div>
        </div>

        <!-- Calendar Grids -->
        <div
          @focusin=${this.startListeningToKeyboard}
          class="multiple-calendars grid translate-x-0 min-w-[1120px] gap-8"
          style="
          grid-template-columns: repeat(4, 1fr);
          margin-left: -${getCalendarWidth({
            showMultipleMonths: this.showMultipleMonths,
            offsetWidth: this.offsetWidth,
          }) + 8}px;
        "
        >
          ${this.month.map((element, monthIndex) => {
            return html`
              <div
                class="calendar
              ${classMap({
                  invisible:
                    monthIndex === 0 ||
                    monthIndex === 3 ||
                    (!this.showMultipleMonths && monthIndex === 2),
                  'max-w-[406px]': !this.showMultipleMonths,
                  'min-w-[296px]': !this.showMultipleMonths,
                  'max-w-[377px]': this.showMultipleMonths,
                  'min-w-[348px]': this.showMultipleMonths,
                })}"
                style="width: ${getCalendarWidth({
                  showMultipleMonths: this.showMultipleMonths,
                  offsetWidth: this.offsetWidth,
                })}px;"
              >
                <div class=" grid grid-cols-7 p-2 mb-8 h-[56px]">
                  <div
                    class="
                flex
                justify-center
                items-center
                calendar-month
                calendar__month
                text-neutral-000
                font-['AmericanSans']
                text-center
                col-span-7
                "
                  >
                    ${this.createMonthName(element.name as string)}
                  </div>
                </div>
                <div
                  class="calendar__weekday-grid-container p-2 mt-[60px] h-[349px]"
                >
                  <div
                    class="calendar__grid grid grid-cols-7 justify-items-center gap-4 p-2 ${classMap(
                      {
                        'calendar__grid-range-enabled':
                          (this.manualSelection
                            ? !this.modifyFirstSelection
                            : true) &&
                          !this.singleDaySelection &&
                          !this.secondSelection,
                      }
                    )}"
                  >
                    ${element.days.map((day: DayState, index: number) => {
                      let beforeToday = false;
                      let beforeMinDate = false;
                      let afterMaxDate = false;
                      let beforeDeparture = false;
                      let afterDeparture = false;

                      const createMaxDaysOutDate = () => {
                        if (this.maxDaysOut) {
                          return add(new Date(), {
                            days: this.maxDaysOut,
                          }).toISOString();
                        }

                        return '';
                      };

                      if (typeof day.date === 'string') {
                        beforeToday = isBefore(
                          startOfDay(parseISO(day.date)),
                          startOfDay(parseISO(this.currentDate))
                        );
                        beforeMinDate = isBefore(
                          startOfDay(parseISO(day.date)),
                          startOfDay(parseISO(this.minDateString))
                        );
                        afterMaxDate = isAfter(
                          startOfDay(parseISO(day.date)),
                          startOfDay(
                            parseISO(
                              this.maxDateString || createMaxDaysOutDate()
                            )
                          )
                        );
                        beforeDeparture = isBefore(
                          parseISO(day.date),
                          parseISO(this.firstSelection)
                        );
                        afterDeparture = isBefore(
                          parseISO(this.firstSelection),
                          parseISO(day.date)
                        );
                      }

                      const isDisabled =
                        afterMaxDate ||
                        beforeMinDate ||
                        (beforeToday && !this.enablePastSelection) ||
                        (this.manualSelection &&
                          !this.modifyFirstSelection &&
                          beforeDeparture);
                      return html`
                        <div
                          class="calendar__day--wrapper relative w-full ${classMap(
                            {
                              first__day: index === 0,
                              'calendar__day--departure-wrapper':
                                day.isDeparture as boolean,
                              'calendar__day--after-departure-month-wrapper':
                                index === 0 && afterDeparture,
                            }
                          )}
                            "
                          style="${index === 0
                            ? styleMap({
                                gridColumnStart: this.month[monthIndex]
                                  .firstDayOfMonth as unknown as string,
                              })
                            : undefined}
                       "
                        >
                          ${this.showPrice
                            ? html`<div
                                class="calendar__day--price font-['AmericanSans'] font-[400] text-[12px] leading-4 text-center pointer-events-none w-full absolute bottom-[7px]
                        ${classMap({
                                  'text-green-060':
                                    !day.isDeparture && !day.isArrival,
                                  'text-neutral-140':
                                    (day.isDeparture as boolean) ||
                                    (day.isArrival as boolean),
                                })}
                        "
                              >
                                $9,999
                              </div>`
                            : ''}

                          <adc-button-icon
                            @focus=${this.handleFocus}
                            @blur=${this.handleBlur}
                            icon="${iconNumberMap[day.value]}"
                            size="sm"
                            icon-size="16"
                            type="button"
                            kind="ghost"
                            data-date=${day.date}
                            ?disabled=${isDisabled}
                            @mouseover=${(e: Event) =>
                              this.handleGridRangeOver(e, monthIndex)}
                            @mouseout=${(e: Event) =>
                              this.handleGridRangeOut(e)}
                            @click=${() =>
                              this.handleSelectDay(
                                day.date as string,
                                isDisabled,
                                beforeDeparture
                              )}
                            class="calendar__day rounded w-full aspect-square ${classMap(
                              {
                                first__day: index === 0,
                                'calendar__day-show-price': this.showPrice,
                                'calendar__day--departure':
                                  day.isDeparture as boolean,
                                'calendar__day--after-departure-month':
                                  index === 0 && afterDeparture,
                                'calendar__day--arrival':
                                  day.isArrival as boolean,
                                'calendar__day--highlight-day':
                                  ((day.isArrival as boolean) &&
                                    !this.modifyFirstSelection &&
                                    this.manualSelection &&
                                    !this.singleDaySelection &&
                                    this.firstSelection &&
                                    this.secondSelection) ||
                                  ((day.isDeparture as boolean) &&
                                    this.modifyFirstSelection &&
                                    this.manualSelection &&
                                    !this.singleDaySelection &&
                                    this.firstSelection &&
                                    this.secondSelection),
                                border:
                                  day.isToday &&
                                  !day.isDeparture &&
                                  !day.isArrival,
                                'border-solid':
                                  day.isToday &&
                                  !day.isDeparture &&
                                  !day.isArrival,
                                'border-[#637E9C]':
                                  day.isToday &&
                                  !day.isDeparture &&
                                  !day.isArrival,
                                'bg-blue-120': day.isInRange as boolean,
                                'text-neutral-010':
                                  afterMaxDate ||
                                  beforeMinDate ||
                                  (beforeToday && !this.enablePastSelection),
                                'text-neutral-140':
                                  (day.isDeparture as boolean) ||
                                  (day.isArrival as boolean),
                                'text-neutral-090': isDisabled,

                                'hover:bg-neutral-130':
                                  !day.isDeparture &&
                                  !day.isArrival &&
                                  !day.isInRange, // grey
                                'active:bg-neutral-120':
                                  !day.isDeparture &&
                                  !day.isArrival &&
                                  !day.isInRange, // grey

                                'calendar__day--disabled':
                                  afterMaxDate || beforeToday || beforeMinDate,

                                'hover:bg-blue-120':
                                  this.firstSelection &&
                                  !this.secondSelection &&
                                  !day.isDeparture &&
                                  !day.isArrival &&
                                  !day.isInRange &&
                                  afterDeparture &&
                                  !this.singleDaySelection, // light blue
                                'active:bg-blue-100':
                                  (this.firstSelection &&
                                    !this.secondSelection &&
                                    (!day.isDeparture as boolean) &&
                                    (!day.isArrival as boolean) &&
                                    (!day.isInRange as boolean) &&
                                    afterDeparture &&
                                    !this.singleDaySelection) ||
                                  (day.isInRange as boolean), // light blue
                                'hover:bg-blue-110': day.isInRange as boolean, // light blue

                                'bg-blue-060':
                                  (day.isDeparture as boolean) ||
                                  (day.isArrival as boolean), // dark blue
                                'active:bg-blue-080':
                                  (day.isDeparture as boolean) ||
                                  (day.isArrival as boolean), // dark blue
                                'hover:bg-blue-070':
                                  (day.isDeparture as boolean) ||
                                  (day.isArrival as boolean), // dark blue
                                'pointer-events-none':
                                  isDisabled ||
                                  (this.manualSelection &&
                                    beforeDeparture &&
                                    !this.modifyFirstSelection),
                              }
                            )}"
                          >
                            <slot>${day.screenReader}</slot>
                          </adc-button-icon>
                        </div>
                      `;
                    })}
                  </div>
                </div>
              </div>
            `;
          })}
        </div>
      </div>
    `;
  }
}

try {
  customElements.define('adc-calendar', Calendar);
} catch (e) {
  // do nothing
}

declare global {
  interface HTMLElementTagNameMap {
    'adc-calendar': Calendar;
  }
}
