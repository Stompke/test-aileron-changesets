import { createSlice } from "@reduxjs/toolkit";
import { parseISO, isSameMonth, isSameDay, isBefore, isToday, isAfter } from "date-fns";
import format from "date-fns/format";
import * as locales from "date-fns/locale";
import { v1 as uuidv1 } from "uuid";
import type { PayloadAction } from "@reduxjs/toolkit";

export type Weekday =
  | "Sunday"
  | "Monday"
  | "Tuesday"
  | "Wednesday"
  | "Thursday"
  | "Friday"
  | "Saturday";

export interface DayState {
  weekday: number | null;
  date: string | null;
  value: number;
  isToday: boolean;
  selected?: boolean;
  isDeparture?: boolean;
  isArrival?: boolean;
  isInRange?: boolean;
  screenReader?: string;
}

export interface MonthState {
  id: string;
  name: string | null;
  value: number;
  firstDayOfMonth: number;
  lastDayOfMonth: number;
  days: DayState[];
}

export interface CalendarState {
  currentDate: string;
  month: MonthState[];
  firstSelection: string;
  secondSelection: string;
  modifyFirstSelection: boolean;
  showMultipleMonths: boolean;
  locale: string;
  dateFnsLocale: string;
  manualSelection: boolean;
}

export interface ReduxState {
  calendar: CalendarState;
}

const formatDateScreenReader = (dateToFormat: Date, state: CalendarState) => {
  const isDeparture = isSameDay(dateToFormat, parseISO(state.firstSelection));
  const isArrival = isSameDay(dateToFormat, parseISO(state.secondSelection));
  const dateIsToday = isToday(dateToFormat);
  const dateString = dateToFormat.toLocaleString(state.locale, {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric"
  });

  const handleSelectionText = () => {
    const departureText = "click to set departure";
    const arrivalText = "click to set arrival";

    if (state.modifyFirstSelection) {
      return departureText;
    }

    if (state.modifyFirstSelection) {
      return departureText;
    }

    // on 2nd selection, && manual selection
    if (state.manualSelection && !state.modifyFirstSelection) {
      return arrivalText;
    }

    // on 2nd selection, if date is before departure, "click to select as departure"
    if (state.firstSelection && isBefore(dateToFormat, parseISO(state.firstSelection))) {
      return departureText;
    }

    // on 2nd selection, if date is after or the same as departure, "click to select as arrival"
    return arrivalText;
  };
  const fullString = `${dateIsToday ? "Today's date, " : ""}${
    isDeparture ? "Selected departure date, " : ""
  } ${isArrival ? "Selected arrival date, " : ""} ${dateString}, ${handleSelectionText()}`;
  return fullString;
};

const createMonthDays = ({
  date,
  days,
  state,
  daysInMonth,
}: {
  date: Date;
  days: DayState[];
  state: CalendarState;
  daysInMonth: number;
}) => {
  [...Array(daysInMonth)].forEach((_, day: number) => {
    const current = new Date(date.getTime());
    current.setDate(day + 1);
    const screenReaderString = formatDateScreenReader(current, state);

    days.push({
      date: current.toISOString(),
      value: current.getDate(),
      screenReader: screenReaderString,
      weekday: current.getDay(),
      isToday: isToday(current),
      isDeparture: isSameDay(current, parseISO(state.firstSelection)),
      isArrival: isSameDay(current, parseISO(state.secondSelection)),
      isInRange:
        !!state.firstSelection &&
        !!state.secondSelection &&
        !isBefore(current, parseISO(state.firstSelection)) &&
        isBefore(current, parseISO(state.secondSelection)),
    });
  });
};

const createMonthData = ({
  newMonth,
  state,
}: {
  newMonth: Date;
  state: CalendarState;
}) => {
  const date = new Date(newMonth);
  const month = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  const monthNumber = date.getMonth();
  const daysInMonth = month.getDate();
  const firstDayOfMonth = parseInt(
    format(date, 'e', { locale: (locales as any)[state.dateFnsLocale] }),
    10
  );
  const lastDayOfMonth = month.getDay();
  const days: DayState[] = [];

  createMonthDays({ date, days, state, daysInMonth });

  return {
    id: uuidv1(),
    name: date.toISOString(),
    value: monthNumber,
    firstDayOfMonth,
    lastDayOfMonth,
    days,
  };
};

const initialState: CalendarState = {
  currentDate: new Date().toISOString(),
  month: [],
  firstSelection: "",
  secondSelection: "",
  modifyFirstSelection: true,
  showMultipleMonths: true,
  manualSelection: true,
  locale: "en-US",
  dateFnsLocale: "enUS"
};

const calendarSlice = createSlice({
  name: "calendar",
  initialState,
  reducers: {
    setCurrentDate(state, action: PayloadAction<string>) {
      state.currentDate = action.payload;
    },
    setState(state: any, action: PayloadAction<{ name: string; value: any }>) {
      const { name, value } = action.payload;
      state[name] = value;

      if (name === "modifyFirstSelection") {
        if (state.month.length > 0) {
          const currentSelectedMonth = state.month[1].days[0].date;
          calendarSlice.caseReducers.buildCalendar(state, {
            payload: {
              date: currentSelectedMonth || state.currentDate
            },
            type: "calendar/buildCalendar"
          });
        }
      }
      if (name === "locale") {
        calendarSlice.caseReducers.refreshCalendar(state);
      }
    },
    setShowMultipleMonths(state, action: PayloadAction<boolean>) {
      state.showMultipleMonths = action.payload;
    },
    jumpToDate(state, action: PayloadAction<{ modifyFirstSelection: boolean }>) {
      const currentSelectedMonth = state.month[1].days[0].date;

      const { modifyFirstSelection } = action.payload;

      state.modifyFirstSelection = modifyFirstSelection; // change tab or text input

      if (!currentSelectedMonth) return;
      if (!state.firstSelection && !state.secondSelection) {
        if (!isSameMonth(parseISO(state.currentDate), parseISO(currentSelectedMonth))) {
          // remove old calendar
          calendarSlice.caseReducers.clearCalendar(state);

          // generate new calendar
          calendarSlice.caseReducers.buildCalendar(state, {
            payload: {
              date: state.currentDate
            },
            type: "calendar/buildCalendar"
          });
          return;
        }
      }

      if (!state.firstSelection && state.secondSelection) {
        if (!isSameMonth(parseISO(state.secondSelection), parseISO(currentSelectedMonth))) {
          // remove old calendar
          calendarSlice.caseReducers.clearCalendar(state);

          // generate new calendar
          calendarSlice.caseReducers.buildCalendar(state, {
            payload: {
              date: state.secondSelection
            },
            type: "calendar/buildCalendar"
          });
          return;
        }
      } else if (state.firstSelection && !state.secondSelection) {
        if (!isSameMonth(parseISO(state.firstSelection), parseISO(currentSelectedMonth))) {
          // remove old calendar
          calendarSlice.caseReducers.clearCalendar(state);

          // generate new calendar
          calendarSlice.caseReducers.buildCalendar(state, {
            payload: {
              date: state.firstSelection
            },
            type: "calendar/buildCalendar"
          });
          return;
        }
      }

      if (state.firstSelection && state.secondSelection) {
        // Dates are on the same Month && Year
        if (isSameMonth(parseISO(state.firstSelection), parseISO(state.secondSelection))) {
          // remove old calendar
          calendarSlice.caseReducers.clearCalendar(state);

          // generate new calendar
          calendarSlice.caseReducers.buildCalendar(state, {
            payload: {
              date: state.firstSelection
            },
            type: "calendar/buildCalendar"
          });
          return;
          // }
        }
      }

      if (modifyFirstSelection) {
        // set modifyFirstSelection to True
        if (state.firstSelection) {
          if (
            parseISO(state.firstSelection).getMonth() !==
              parseISO(currentSelectedMonth).getMonth() ||
            parseISO(state.firstSelection).getFullYear() !==
              parseISO(currentSelectedMonth).getFullYear()
          ) {
            // remove old calendar
            calendarSlice.caseReducers.clearCalendar(state);

            // generate new calendar
            calendarSlice.caseReducers.buildCalendar(state, {
              payload: {
                date: state.firstSelection || state.currentDate
              },
              type: "calendar/buildCalendar"
            });
          }
        }
      } else {
        // set modifyFirstSelection to False
        if (state.secondSelection) {
          // CREATE for Single Month or Multiple Month
          if (state.showMultipleMonths) {
            if (
              parseISO(state.secondSelection).getMonth() !==
                parseISO(currentSelectedMonth).getMonth() + 1 ||
              parseISO(state.secondSelection).getFullYear() !==
                parseISO(currentSelectedMonth).getFullYear()
            ) {
              //

              // remove old calendar
              calendarSlice.caseReducers.clearCalendar(state);

              const secondSelectionForDoubleCalendar = parseISO(state.secondSelection);
              secondSelectionForDoubleCalendar.setMonth(
                parseISO(state.secondSelection).getMonth() + -1
              );

              // generate new calendar
              calendarSlice.caseReducers.buildCalendar(state, {
                payload: {
                  date: secondSelectionForDoubleCalendar.toISOString()
                },
                type: "calendar/buildCalendar"
              });
            } //
          } else {
            if (
              parseISO(state.secondSelection).getMonth() !==
                parseISO(currentSelectedMonth).getMonth() ||
              parseISO(state.secondSelection).getFullYear() !==
                parseISO(currentSelectedMonth).getFullYear()
            ) {
              //
              // remove old calendar
              calendarSlice.caseReducers.clearCalendar(state);

              // generate new calendar
              calendarSlice.caseReducers.buildCalendar(state, {
                payload: {
                  date: state.secondSelection
                },
                type: "calendar/buildCalendar"
              });
            } //
          }
        }
      }
    },
    clearCalendar(state) {
      state.month = [];
    },
    clearDates(state) {
      const currentSelectedMonth = state.month[1].days[0].date;

      state.firstSelection = "";
      state.secondSelection = "";
      state.modifyFirstSelection = true;

      // remove old calendar
      calendarSlice.caseReducers.clearCalendar(state);

      calendarSlice.caseReducers.buildCalendar(state, {
        payload: {
          date: currentSelectedMonth || state.currentDate
        },
        type: "calendar/buildCalendar"
      });
    },
    setFirstSelectionOnly(state, action: PayloadAction<string>) {
      state.firstSelection = action.payload;
      calendarSlice.caseReducers.refreshCalendar(state);
    },
    setSecondSelectionOnly(state, action: PayloadAction<string>) {
      state.secondSelection = action.payload;
      calendarSlice.caseReducers.refreshCalendar(state);
    },
    setFirstSelection(
      state,
      action: PayloadAction<{ firstSelection: string; manualSelection?: boolean }>
    ) {
      const { firstSelection, manualSelection } = action.payload;
      state.firstSelection = firstSelection;
      if (!manualSelection) {
        // Auto Selection
        state.secondSelection = "";
        state.modifyFirstSelection = false;
      } else {
        // Manual Selection
        if (state.secondSelection) {
          if (isAfter(parseISO(state.firstSelection), parseISO(state.secondSelection))) {
            state.secondSelection = "";
          }
        }
      }
      const currentSelectedMonth = state.month[1].days[0].date;

      // remove old calendar
      calendarSlice.caseReducers.clearCalendar(state);

      // generate new calendar
      calendarSlice.caseReducers.buildCalendar(state, {
        payload: {
          date: currentSelectedMonth || state.currentDate
        },
        type: "calendar/buildCalendar"
      });
    },
    setSecondSelection(
      state,
      action: PayloadAction<{ secondSelection: string; manualSelection?: boolean }>
    ) {
      const { secondSelection, manualSelection } = action.payload;
      state.secondSelection = secondSelection;
      const currentSelectedMonth = state.month[1].days[0].date;
      if (!manualSelection) {
        // Auto Selection
        state.modifyFirstSelection = true;
      } else {
        // Manual Selection
      }

      // remove old calendar
      calendarSlice.caseReducers.clearCalendar(state);

      // generate new calendar
      calendarSlice.caseReducers.buildCalendar(state, {
        payload: {
          date: currentSelectedMonth || state.currentDate
        },
        type: "calendar/buildCalendar"
      });
    },
    buildCalendar(state, action: PayloadAction<{ date: string }>) {
      calendarSlice.caseReducers.clearCalendar(state);
      const numberOfCalendars = state.showMultipleMonths ? 3 : 2;
      const curDate = parseISO(action.payload.date);

      for (let i = -1; i < numberOfCalendars; i++) {
        const newMonth = new Date(curDate.getTime());
        newMonth.setMonth(newMonth.getMonth() + i);
        newMonth.setDate(1);
        const monthData = createMonthData({ newMonth: newMonth, state: state });
        state.month.push(monthData);
      }
    },
    incrementMonth(state) {
      state.month.shift();

      const lastMonthInList = state.month[state.month.length - 1];
      const newMonth = new Date(parseISO(lastMonthInList.days[0].date as string).getTime());
      newMonth.setMonth(newMonth.getMonth() + 1);
      newMonth.setDate(1);

      const monthData = createMonthData({ newMonth: newMonth, state: state });

      state.month.push(monthData);
    },
    decrementMonth(state) {
      state.month.pop();

      const firstMonthInList = state.month[0];

      const newMonth = new Date(parseISO(firstMonthInList.days[0].date as string).getTime());
      newMonth.setMonth(newMonth.getMonth() - 1);
      newMonth.setDate(1);

      const monthData = createMonthData({ newMonth: newMonth, state: state });

      state.month.unshift(monthData);
    },
    refreshCalendar(state) {
      const currentSelectedMonth = state.month[1].days[0].date;

      // remove old calendar
      calendarSlice.caseReducers.clearCalendar(state);

      // generate new calendar
      calendarSlice.caseReducers.buildCalendar(state, {
        payload: {
          date: currentSelectedMonth || state.currentDate
        },
        type: "calendar/buildCalendar"
      });
    }
  }
});

export const {
  setCurrentDate,
  incrementMonth,
  decrementMonth,
  buildCalendar,
  setSecondSelection,
  setFirstSelection,
  clearCalendar,
  jumpToDate,
  clearDates,
  setShowMultipleMonths,
  setState,
  setFirstSelectionOnly,
  setSecondSelectionOnly,
  refreshCalendar
} = calendarSlice.actions;

export default calendarSlice.reducer;
