import "./date-picker";
import { html, TemplateResult } from "lit-html";
import { ifDefined } from "lit-html/directives/if-defined.js";
import { expect } from "@storybook/jest";
import { userEvent } from "@storybook/testing-library";

export default {
  title: "Components/Date-Picker",
  component: "adc-date-picker",
  parameters: {
    actions: {
      handles: [
        "adc-next-month-animation-end",
        "adc-prev-month-animation-end",
        "adc-next-month-animation-start",
        "adc-prev-month-animation-start",
        "adc-select",
        "adc-clear-dates"
      ]
    }
  },
  argTypes: {
    kind: {
      type: {
        name: "text",
        required: false
      },
      table: {
        defaultValue: { summary: '"dialog"' }
      },
      options: ["dialog", "dropdown"],
      control: {
        type: "select"
      }
    },
    weekdayFormat: {
      type: {
        name: "text",
        required: false
      },
      table: {
        defaultValue: { summary: '"short","narrow"' }
      },
      options: ["short", "narrow"],
      control: {
        type: "select"
      }
    },
    inputKind: {
      type: {
        name: "text",
        required: false
      },
      table: {
        defaultValue: { summary: '"text","button"' }
      },
      options: ["text", "button"],
      control: {
        type: "select"
      }
    }
  }
};

interface Properties {
  showCurrentYear?: boolean;
  showPrice?: boolean;
  locale?: string;
  weekdayFormat?: string;
  kind?: string;
  singleDaySelection?: boolean;
  manualSelection?: boolean;
  inputKind?: string;
  firstSelectionText?: string;
  secondSelectionText?: string;
  showMultipleMonths?: boolean;
  enablePastSelection?: boolean;
  disabled?: boolean;
  required?: boolean;
}

const Template = ({
  showCurrentYear,
  locale,
  showPrice,
  weekdayFormat,
  kind,
  singleDaySelection,
  manualSelection,
  firstSelectionText,
  secondSelectionText,
  inputKind,
  enablePastSelection,
  disabled,
  required
}: Properties = {}): TemplateResult => {
  return html`
    <div style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
    </div>
    <div
      style="width: 100%; display: flex; justify-content: space-between; align-items: space-between;"
    >
      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
      <adc-date-picker
        locale=${ifDefined(locale)}
        weekday-format=${ifDefined(weekdayFormat)}
        ?show-current-year=${showCurrentYear}
        ?show-price=${showPrice}
        kind=${ifDefined(kind)}
        ?single-day-selection=${singleDaySelection}
        ?manual-selection=${manualSelection}
        input-kind=${ifDefined(inputKind)}
        ?enable-past-selection=${enablePastSelection}
        ?disabled=${disabled}
        ?required=${required}
        first-selection-text=${ifDefined(firstSelectionText)}
        second-selection-text=${ifDefined(secondSelectionText)}
      ></adc-date-picker>
      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
    </div>

    <div
      style="background-image: url(https://images.unsplash.com/photo-1501785888041-af3ef285b470?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1770&q=80); width: 100%; background-position: center; height: 600px;"
    ></div>
    <div
      style="width: 100%; display: flex; justify-content: space-between; align-items: space-between;"
    >
      <adc-date-picker
        locale=${ifDefined(locale)}
        weekday-format=${ifDefined(weekdayFormat)}
        ?show-current-year=${showCurrentYear}
        ?show-price=${showPrice}
        kind=${ifDefined(kind)}
        ?single-day-selection=${singleDaySelection}
        ?manual-selection=${manualSelection}
        input-kind=${ifDefined(inputKind)}
        ?enable-past-selection=${enablePastSelection}
        ?disabled=${disabled}
        ?required=${required}
        first-selection-text=${ifDefined(firstSelectionText)}
        second-selection-text=${ifDefined(secondSelectionText)}
      ></adc-date-picker>

      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
      <adc-text-input style="width: 400px; margin: 0 10px;"></adc-text-input>
    </div>
  `;
};

export const DialogCalendar = (args?: Properties): TemplateResult => Template(args);
DialogCalendar.args = {
  showCurrentYear: true,
  locale: "en-US",
  showPrice: false,
  weekdayFormat: "narrow",
  kind: "dialog",
  singleDaySelection: false,
  manualSelection: false,
  firstSelectionText: "Departure",
  secondSelectionText: "Arrival",
  inputKind: "text",
  enablePastSelection: false,
  disabled: false,
  required: false
};

DialogCalendar.play = async ({ canvasElement, args }) => {
  const {
    singleDaySelection,
    locale,
    firstSelectionText,
    secondSelectionText,
    inputKind,
    disabled
  } = args;
  const calendarComponent = await canvasElement.querySelector("adc-date-picker");
  const calendarGridComponent = await calendarComponent.shadowRoot.querySelector("adc-calendar");

  if (!singleDaySelection && locale === "en-US" && inputKind !== "button" && !disabled) {
    const firstTextInputComponent = await calendarComponent.shadowRoot
      .querySelector(`adc-text-input[name="${firstSelectionText}"`)
      .shadowRoot.querySelector("input");

    const firstCalendarButton = await calendarComponent.shadowRoot
      .querySelector(`adc-text-input[name="${firstSelectionText}"`)
      .querySelector("adc-button-icon");
    const secondTextInputComponent = await calendarComponent.shadowRoot
      .querySelector(`adc-text-input[name="${secondSelectionText}"`)
      .shadowRoot.querySelector("input");

    const typeIntoFirstInput = async () => {
      // 🔧  Assert - First text field is in the document
      await expect(firstTextInputComponent).toBeInTheDocument();

      // 👇 Simulate - Type into first text field
      await userEvent.clear(firstTextInputComponent);
      await userEvent.type(firstTextInputComponent, "july 5, 24");

      // 👇 Simulate - lose focus of first input
      await userEvent.click(secondTextInputComponent);
      await userEvent.click(secondTextInputComponent);

      // 🔧  Assert - First text field is in the document
      await expect(firstTextInputComponent).toHaveValue("7/5/2024");
    };

    const typeIntoSecondInput = async () => {
      // 🔧  Assert - First text field is in the document
      await expect(secondTextInputComponent).toBeInTheDocument();

      // 👇 Simulate - Type into first text field
      await userEvent.clear(secondTextInputComponent);
      await userEvent.type(secondTextInputComponent, "aug 12, 24");

      // 👇 Simulate - lose focus of first input
      await userEvent.click(firstTextInputComponent);
      await userEvent.click(firstTextInputComponent);

      // 🔧  Assert - First text field is in the document
      await expect(secondTextInputComponent).toHaveValue("8/12/2024");
    };

    // ⏳ Test - Type valid date into first input
    await typeIntoFirstInput();

    // ⏳ Test - Type into second input

    await typeIntoSecondInput();

    // ⏳ Test - Type invalid date into first text field

    // 👇 Simulate - Type into first text field
    await userEvent.clear(firstTextInputComponent);
    await userEvent.type(firstTextInputComponent, "foo");

    // 👇 Simulate - lose focus of first input
    await userEvent.click(secondTextInputComponent);
    await userEvent.click(secondTextInputComponent);

    // 🔧  Assert - First Date is invalid
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-text-input[name="${firstSelectionText}"`)
        .shadowRoot.querySelector(".adc-text-input--form-requirement")
    ).toHaveTextContent("Please check the date you entered");

    // ⏳ Test -  Type invalid date into second text field

    // 👇 Simulate - Type into second text field
    await userEvent.clear(secondTextInputComponent);
    await userEvent.type(secondTextInputComponent, "foo");

    // 👇 Simulate - lose focus of first input
    await userEvent.click(firstTextInputComponent);
    await userEvent.click(firstTextInputComponent);

    // 🔧  Assert - Second Date is invalid
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-text-input[name="${secondSelectionText}"`)
        .shadowRoot.querySelector(".adc-text-input--form-requirement")
    ).toHaveTextContent("Please check the date you entered");

    // ⏳ Test -  Type valid date into first input
    await typeIntoFirstInput();

    // 🔧  Assert - First Date is valid
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-text-input[name="${firstSelectionText}"`)
        .shadowRoot.querySelector(".adc-text-input--form-requirement")
    ).not.toBeInTheDocument();

    // ⏳ Test -  Type valid date into second input
    await typeIntoSecondInput();

    // 🔧  Assert - Second date is valid
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-text-input[name="${secondSelectionText}"`)
        .shadowRoot.querySelector(".adc-text-input--form-requirement")
    ).not.toBeInTheDocument();

    // ⏳ Test - Test dates are visible in calendar

    // 👇 Simulate - Click first calendar icon
    await userEvent.click(firstCalendarButton);

    // 🔧  Assert - Correct dates are selected on calendar
    await expect(
      await calendarGridComponent.shadowRoot.querySelector(".calendar__day--departure")
    ).toHaveAttribute("icon", "numerical:five");
    await expect(
      await calendarGridComponent.shadowRoot.querySelector(".calendar__day--arrival")
    ).toHaveAttribute("icon", "numerical:twelve");
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-tab[value='${firstSelectionText}'`)
        .shadowRoot.querySelector(".adc-tab__sub-label ")
    ).toHaveTextContent("Fri, Jul 5, 2024");
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-tab[value='${secondSelectionText}'`)
        .shadowRoot.querySelector(".adc-tab__sub-label ")
    ).toHaveTextContent("Mon, Aug 12, 2024");

    // ⏳ Test - Clear Dates
    // 👇 Simulate - Click clear dates button
    await userEvent.click(
      await calendarComponent.shadowRoot.querySelector('adc-button[kind="ghost"]')
    );

    // 🔧  Assert - Dates have been cleared
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-tab[value='${firstSelectionText}'`)
        .shadowRoot.querySelector(".adc-tab__sub-label ")
    ).toHaveTextContent("Select date");
    await expect(
      await calendarComponent.shadowRoot
        .querySelector(`adc-tab[value='${secondSelectionText}'`)
        .shadowRoot.querySelector(".adc-tab__sub-label ")
    ).toHaveTextContent("--");

    // ⏳ Test - Close Dialog
    // 👇 Simulate - click close dropdown button
    await userEvent.click(
      await calendarComponent.shadowRoot.querySelector('adc-button[kind="primary"')
    );

    // 🔧  Assert - assure dropdown is closed
    await expect(
      await calendarComponent.shadowRoot
        .querySelector("adc-dialog")
        .shadowRoot.querySelector("#dialog")
    ).toHaveProperty("hidden");
  }
};

const TooltipCalendar = ({
  showCurrentYear,
  locale,
  showPrice,
  weekdayFormat,
  kind,
  singleDaySelection,
  manualSelection,
  firstSelectionText,
  secondSelectionText,
  inputKind,
  enablePastSelection,
  disabled,
  required
}: Properties = {}): TemplateResult => {
  return html`
    <adc-date-picker
      locale=${ifDefined(locale)}
      weekday-format=${ifDefined(weekdayFormat)}
      ?show-current-year=${showCurrentYear}
      ?show-price=${showPrice}
      kind=${ifDefined(kind)}
      ?single-day-selection=${singleDaySelection}
      ?manual-selection=${manualSelection}
      input-kind=${ifDefined(inputKind)}
      ?enable-past-selection=${enablePastSelection}
      first-selection-text=${ifDefined(firstSelectionText)}
      second-selection-text=${ifDefined(secondSelectionText)}
      ?disabled=${disabled}
      ?required=${required}
    ></adc-date-picker>
  `;
};

export const CalendarInTooltip = (args?: Properties): TemplateResult => TooltipCalendar(args);
CalendarInTooltip.args = {
  showCurrentYear: false,
  locale: "en-US",
  showPrice: false,
  weekdayFormat: "narrow",
  kind: "dropdown",
  singleDaySelection: false,
  manualSelection: false,
  firstSelectionText: "Departure",
  secondSelectionText: "Arrival",
  inputKind: "text",
  enablePastSelection: false,
  disabled: false,
  required: false
};

const CalendarGrid = ({
  showCurrentYear,
  locale,
  showPrice,
  weekdayFormat,
  singleDaySelection,
  manualSelection,
  firstSelectionText,
  secondSelectionText,
  inputKind,
  enablePastSelection,
  disabled,
  required,
  showMultipleMonths
}: Properties = {}): TemplateResult => {
  return html`
    <adc-calendar
      locale=${ifDefined(locale)}
      weekday-format=${ifDefined(weekdayFormat)}
      ?show-current-year=${showCurrentYear}
      ?show-price=${showPrice}
      ?single-day-selection=${singleDaySelection}
      ?manual-selection=${manualSelection}
      input-kind=${ifDefined(inputKind)}
      ?enable-past-selection=${enablePastSelection}
      ?show-multiple-months=${showMultipleMonths}
      first-selection-text=${ifDefined(firstSelectionText)}
      second-selection-text=${ifDefined(secondSelectionText)}
      ?disabled=${disabled}
      ?required=${required}
      ?show-multiple-months=${showMultipleMonths}
    ></adc-calendar>
  `;
};

export const CalendarGridComponent = (args?: Properties): TemplateResult => CalendarGrid(args);
CalendarGridComponent.args = {
  showCurrentYear: false,
  locale: "en-US",
  showPrice: false,
  kind: "dropdown",
  weekdayFormat: "short",
  singleDaySelection: false,
  manualSelection: false,
  firstSelectionText: "Departure",
  secondSelectionText: "Arrival",
  inputKind: "text",
  enablePastSelection: false,
  disabled: false,
  required: false,
  showMultipleMonths: false
};
