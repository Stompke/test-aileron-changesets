import { Dropdown } from '@aileron/shared/dropdown';
import { emit } from '@aileron/shared/event';
import '@aileron/button';
import '@aileron/button-icon';
import '@aileron/dialog';
import '@aileron/icon';
import '@aileron/tabs';
import '@aileron/text-input';
import { configureStore } from '@reduxjs/toolkit';
import { parseISO, isBefore, isAfter, startOfDay, add } from 'date-fns';
import { html, PropertyValues } from 'lit';
import { property, state, query, queryAsync } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import './calendar.component';
import calendarSlice, {
  jumpToDate,
  clearDates,
  setState,
  setFirstSelectionOnly,
  setSecondSelectionOnly,
} from './calendar.slice';
import styles from './styles.css';
import type { ReduxState } from './calendar.slice';
import type { Calendar } from './calendar.component';
import type { Dialog } from '@aileron/dialog';
import type { Unsubscribe, Store } from 'redux';
import { TextInput } from '@aileron/text-input';
import { Button } from '@aileron/button';
import { AileronElement } from '@aileron/shared/aileron-element';

export type WeekdayFormat = 'short' | 'narrow';

/**
 * @ignore
 */
export class CalendarConfig {
  locale = 'en-US';
  weekdayFormat: WeekdayFormat = 'narrow';
  showCurrentYear = true;
  showPrice = false;
}

const underscoreToHyphen = (value: string) => {
  if (value?.includes('_')) {
    return value.replace('_', '-');
  }
  return value;
};

const getCookie = (name: string) => {
  const cookies = document.cookie.split('; ');
  for (const cookie of cookies) {
    const singleCookie = cookie.split('=');
    if (singleCookie[0] === name) {
      return singleCookie[1];
    }
  }
  return null;
};

const getDefaultLocale = () => {
  const urlLocale = new URLSearchParams(location.search).get('locale');
  if (urlLocale) return underscoreToHyphen(urlLocale);

  const cookieLocale = getCookie('sessionLocale');

  if (cookieLocale) return underscoreToHyphen(cookieLocale);

  return 'en-US';
};

const createDateArray = (str: string) => {
  const array: string[] = [];
  let currentStr = '';
  str.split('').forEach((character, index) => {
    if (!character.match('[A-Za-z0-9]')) {
      if (currentStr.length > 0) array.push(currentStr);
      currentStr = '';
    } else {
      currentStr += character;
    }

    if (index === str.split('').length - 1) {
      if (currentStr.length > 0) array.push(currentStr);
    }
  });
  array.join('-');
  return array;
};

function getLocalizedMonths(locale: string) {
  const months: string[] = [];
  const options: Intl.DateTimeFormatOptions = { month: 'long' };
  const formatter = new Intl.DateTimeFormat(locale, options);
  for (let i = 0; i < 12; i++) {
    const monthName = formatter.format(new Date(Date.UTC(2000, i + 1, 1)));
    months.push(monthName);
  }
  return months;
}

const checkMonthString = (string: string, locale: string) => {
  const months = getLocalizedMonths(locale);
  let foundMonth;
  months.forEach((month, index) => {
    if (month.toLowerCase().includes(string.toLowerCase())) {
      foundMonth = index + 1;
    }
  });
  return foundMonth || string;
};

const decipherDate = (value: string, locale: string) => {
  const currentYear = new Date().getFullYear();
  const array = createDateArray(value);
  if (array.length === 3 || array.length > 3) {
    const day = array[1];
    const month: any = parseInt(array[0], 10)
      ? array[0]
      : checkMonthString(array[0], locale);
    let year: string = array[2];

    if (year.length > 4 || year.length === 3 || year.length === 1) {
      year = currentYear.toString();
    } else if (year.length === 2) {
      year = `20${array[2]}`;
    }
    const guessedDate = new Date(
      parseInt(year, 10),
      month - 1,
      parseInt(day, 10),
      6
    );
    return guessedDate;
  } else if (array.length === 2) {
    const day = array[1];
    const month: any = parseInt(array[0], 10)
      ? array[0]
      : checkMonthString(array[0], locale);
    const guessedDate = new Date(currentYear, month - 1, parseInt(day, 10), 6);
    return guessedDate;
  }

  const month: any = parseInt(array[0], 10)
    ? array[0]
    : checkMonthString(array[0], locale);
  const guessedDate = new Date(currentYear, month - 1, 1, 6);
  return guessedDate;
};

/**
 * DatePicker
 * @element adc-date-picker
 * @attr {string} [kind="dialog"] - Chooses how to display the calendar ex: "dialog", "dropdown"
 * @attr {string} [weekday-format="narrow"] - How the weekday names are represented. Options are "short" or "narrow". Defaults to "narrow"
 * @attr {string} [locale=Locale based on url/cookie] - Locale code. Examples are 'en-US', 'fr-FR'
 * @attr {string} [first-selection-text="Departure"] - The text for the firstSelection input & tab
 * @attr {string} [second-selection-text="Arrival"] - The text for the secondSelection input & tab
 * @attr {string} [min-date-string=undefined] - The minimum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
 * @attr {string} [max-date-string=undefined] - The maximum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
 * @attr {number} [max-days-out=undefined] - The maximum number of days out that can be selected.
 * @attr {boolean} [show-current-year=false] - Shows the current year next to month name.
 * @attr {boolean} [disabled=false] - Disables the Date Picker.
 * @attr {boolean} [required=false] - Required attribute for form fields
 * @attr {boolean} [single-day-selection=false] - Calendar only selects one day, not a range of days.
 * @attr {boolean} [manual-selection=false] - User must click the tab or input field to change which selection is being set.
 * @attr {string} [input-kind="text"] - Display date input as a button instead of a text field.
 * @attr {boolean} [enable-past-selection=false] - Allow past dates to be selected.
 * @fires adc-change-calendar-tab - listens for date picker tab change
 * @fires adc-clear-dates - listens for clear dates
 **/

// Add these back in when they are working
// @attr {boolean} [show-price=false] - Shows price next to date
// @attr  {string} [first-pre-selection] - Use pre selected date for firstSelection, only available when using buttons  ex: '2023-02-14T12:00:00.000Z'
// @attr  {string} [second-pre-selection] - Use pre selected dates for secondSelection, only available when using buttons  ex: '2023-02-19T12:00:00.000Z'

export class DatePicker extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  /**
   * @private
   */
  dropdown!: Dropdown;

  private storeUnsubscribe!: Unsubscribe;

  /**
   * @private
   * @ignore
   */
  @property({ type: Object })
  store!: Store;

  async connectedCallback() {
    super.connectedCallback();

    this.store = configureStore({
      devTools: {
        name: '@aileron/calendar',
        trace: true,
      },
      middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
      reducer: {
        calendar: calendarSlice,
      },
    });
    this.storeUnsubscribe = this.store.subscribe(() =>
      this.stateChanged(this.store.getState())
    );
    this.stateChanged(this.store.getState());

    window.addEventListener('resize', this.checkWidth);
    const calendar = await this.calendarDropdown;
    const calendarAnchor = await this.calendarAnchor;

    this.dropdown = new Dropdown(calendarAnchor, calendar);

    this.dropdown.initialize();
    this.dropdown.handleBlur();

    window.addEventListener('click', this.clickOutsideCalendar);
  }

  /**
   * @private
   */
  clickOutsideCalendar = (e: Event) => {
    if (!e.composedPath().includes(this)) this.closeCalendar();
  };

  disconnectedCallback() {
    super.disconnectedCallback();
    this.storeUnsubscribe();
    window.removeEventListener('click', this.clickOutsideCalendar);
    window.removeEventListener('resize', this.checkWidth);
  }

  /**
   * @private
   */
  @state() firstSelection!: string;
  /**
   * @private
   */
  @state() secondSelection!: string;
  /**
   * @private
   */
  @state() modifyFirstSelection!: boolean;
  /**
   * @private
   */
  @state() mobileView = false;
  /**
   * @private
   */
  @state() isCalendarOpen = false;
  /**
   * @private
   */
  @state() currentDate = '';
  /**
   * @private
   */
  @state() firstSelectionTextField = '';
  /**
   * @private
   */
  @state() secondSelectionTextField = '';
  /**
   * @private
   */
  @state() firstInvalidText = '';
  /**
   * @private
   */
  @state() secondInvalidText = '';

  /**
   * @private
   */
  @query('#calendar')
  calendar!: Calendar;

  /**
   * @private
   */
  @queryAsync('#calendarDropdown')
  calendarDropdown!: HTMLElement;

  /**
   * @private
   */
  @queryAsync('#calendar-anchor')
  calendarAnchor!: HTMLElement;

  /**
   * @private
   */
  @query('#dialog')
  dialog!: Dialog;

  /**
   * Chooses how to display the calendar ex: "dialog", "dropdown"
   * @attr {string} [kind]
   * @type {string}
   */
  @property({ reflect: true }) kind = 'dialog';

  /**
   * The minimum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
   * @attr {string} [min-date-string]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'min-date-string' })
  minDateString!: string;

  /**
   * The maximum date that can be selected. Must be in ISO 8601 format. ex: 2023-04-15 or 2023-04-15T05:00:00.000Z
   * @attr {string} [max-date-string]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'max-date-string' })
  maxDateString!: string;

  /**
   * The maximum number of days out that can be selected.
   * @attr {number} [max-days-out]
   * @type {number}
   */
  @property({ reflect: true, attribute: 'max-days-out' }) maxDaysOut!: number;

  /**
   * How the weekday names are represented. Options are "short" or "narrow". Defaults to "narrow"
   * @attr {string} [weekday-format]
   * @type {string}
   */
  @property({
    reflect: true,
    attribute: 'weekday-format',
    converter: (value) => {
      if (value === 'short' || value === 'narrow') {
        return value;
      }
      return 'narrow';
    },
  })
  weekdayFormat = 'narrow';

  private _locale = 'en-US';

  set locale(val: string) {
    const oldVal = this._locale;
    if (val === '') {
      this._locale = getDefaultLocale();
    } else {
      this._locale = underscoreToHyphen(val);
    }
    this.requestUpdate('locale', oldVal);
  }

  /**
   * Locale code. Examples are 'en-US', 'fr-FR',
   * @attr {string} [locale]
   * @type {string}
   */
  @property({ reflect: true })
  get locale() {
    return this._locale;
  }

  /**
   * The text for the firstSelection input & tab
   * @attr {string} [first-selection-text]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'first-selection-text' })
  firstSelectionText = 'Departure';

  /**
   * The text for the secondSelection input & tab
   * @attr {string} [second-selection-text]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'second-selection-text' })
  secondSelectionText = 'Arrival';

  /**
   * Shows the current year next to month name
   * @attr {boolean} [show-current-year]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'show-current-year' })
  showCurrentYear = false;

  /**
   * Disables the Date Picker.
   * @attr {boolean} [disabed]
   * @type {boolean}
   * @ignore because it is duplicating `disabled` on the custom-elements-manifest
   */
  @property({ reflect: true, type: Boolean }) disabled = false;

  /**
   * Required attribute for form fields
   * @attr {boolean} [required]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean }) required = false;

  /**
   * Shows price next to date
   * @attr {boolean} [show-price]
   * @type {boolean}
   * @ignore remove this when this is working
   */
  @property({ reflect: true, type: Boolean, attribute: 'show-price' })
  showPrice = false;

  /**
   * Calendar only selects one day, not a range of days.
   * @attr {boolean} [single-day-selection]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'single-day-selection' })
  singleDaySelection = false;

  /**
   * User must click the tab or input field to change which selection is being set.
   * @attr {boolean} [manual-selection]
   * @type {boolean}
   */
  @property({ reflect: true, type: Boolean, attribute: 'manual-selection' })
  manualSelection = false;

  /**
   * Display date input as a button instead of a text field.
   * @attr {string} [input-kind]
   * @type {string}
   */
  @property({ reflect: true, attribute: 'input-kind' }) inputKind = 'text';

  /**
   * Allow past dates to be selected.
   * @attr {boolean} [enable-past-selection]
   * @type {boolean}
   */
  @property({ type: Boolean, attribute: 'enable-past-selection' })
  enablePastSelection = false;

  /**
   * Use pre selected date for firstSelection, only available when using buttons. Need to be in ISO date format.  ex: '2023-02-14T12:00:00.000Z'
   * @attr {string} [first-pre-selection]
   * @type string}
   * @ignore remove this when this is working
   */
  @property({ reflect: true, attribute: 'first-pre-selection' })
  firstPreSelection = '';

  /**
   * Use pre selected dates for secondSelection, only available when using buttons. Need to be in ISO date format.  ex: '2023-02-19T12:00:00.000Z'
   * @attr {string} [second-pre-selection]
   * @type string}
   * @ignore remove this when this is working
   */
  @property({ reflect: true, attribute: 'second-pre-selection' })
  secondPreSelection = '';

  /**
   * @private
   */
  checkWidth = () => {
    const width = window.innerWidth - 64; // 32 is the horizontal padding of dropdown

    if (width >= 704) {
      this.mobileView = false;
    } else {
      this.mobileView = true;
    }
  };

  /**
   * @private
   */
  setCalendarOpen(open: boolean) {
    this.isCalendarOpen = open;
  }

  /**
   * @private
   */
  async updated(changedProperties: PropertyValues) {
    if (this.inputKind === 'button') {
      if (changedProperties.has('secondPreSelection')) {
        this.store.dispatch(
          setState({ name: 'secondSelection', value: this.secondPreSelection })
        );
      }
      if (changedProperties.has('firstPreSelection')) {
        this.store.dispatch(
          setState({ name: 'firstSelection', value: this.firstPreSelection })
        );
      }
    }

    if (changedProperties.has('manualSelection')) {
      this.store.dispatch(
        setState({ name: 'manualSelection', value: this.manualSelection })
      );
    }

    if (
      changedProperties.has('mobileView') &&
      changedProperties.get('mobileView') !== undefined
    ) {
      if (changedProperties.get('mobileView')) {
        if (this.kind === 'dropdown' && this.inputKind !== 'button') {
          this.dialog.hide();

          await setTimeout(() => {
            this.calendar.showMultipleMonths = true;
            if (this.isCalendarOpen) this.dropdown.handleClick();
          }, 400);
        } else {
          this.calendar.showMultipleMonths = true;
        }
      } else {
        if (this.kind === 'dropdown' && this.inputKind !== 'button') {
          if (this.dropdown) {
            this.dropdown.handleBlur();
          }

          await setTimeout(() => {
            this.calendar.showMultipleMonths = false;
            if (this.isCalendarOpen) this.showCalendar();
          }, 400);
        } else {
          this.calendar.showMultipleMonths = false;
        }
      }
    }
    if (this.dropdown) {
      setTimeout(() => {
        this.dropdown.initialize();
      }, 10);
    }
  }

  /**
   * @private
   */
  protected firstUpdated() {
    this.dialog.addEventListener('adc-show', () =>
      setTimeout(() => {
        this.calendar.setSizes();
      }, 10)
    );
    this.checkWidth();
  }

  /**
   * @private
   */
  stateChanged(calendarState: ReduxState) {
    this.firstSelection = calendarState.calendar.firstSelection;
    if (calendarState.calendar.firstSelection) {
      this.firstSelectionTextField = calendarState.calendar.firstSelection;
      this.firstInvalidText = '';
    }
    this.secondSelection = calendarState.calendar.secondSelection;
    if (calendarState.calendar.secondSelection) {
      this.secondSelectionTextField = calendarState.calendar.secondSelection;
      this.secondInvalidText = '';
    }
    this.modifyFirstSelection = calendarState.calendar.modifyFirstSelection;
    this.currentDate = calendarState.calendar.currentDate;
    this.requestUpdate();
  }

  /**
   * @private
   */
  formatDate = (dateISO: string) => {
    const date = parseISO(dateISO);
    const weekday = date.toLocaleString(this.locale, { weekday: 'short' });
    const month = date.toLocaleString(this.locale, { month: 'short' });
    const day = date.toLocaleString(this.locale, { day: 'numeric' });
    const year = date.toLocaleString(this.locale, { year: 'numeric' });
    const string = `${weekday}, ${month} ${day}, ${year}`;
    return string;
  };

  /**
   * @private
   */
  formatTextInputDate = (dateISO: string) => {
    return parseISO(dateISO).toLocaleString(this.locale, {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    });
  };

  /**
   * @private
   */
  showCalendar = () => {
    this.isCalendarOpen = true;

    if (this.kind === 'dialog' || this.inputKind === 'button') {
      // Dialog
      this.dialog.show();
    } else if (this.mobileView) {
      // Tooltip
      this.dialog.show();
    } else {
      this.dropdown.handleClick();
    }
  };
  /**
   * @private
   */
  hideDialog = () => {
    this.isCalendarOpen = false;
  };
  /**
   * @private
   */
  closeCalendar = () => {
    this.isCalendarOpen = false;
    this.dialog.hide();
    this.dropdown.handleBlur();
  };
  /**
   * @private
   */
  handleIconClick = (isFirstInput: boolean) => {
    this.store.dispatch(jumpToDate({ modifyFirstSelection: isFirstInput }));
    this.showCalendar();
  };
  /**
   * @private
   */
  handleInputClick = (e: Event) => {
    const target = e.target as unknown as Button | TextInput;

    const { name } = target as TextInput;

    if (target && target.type === 'button') {
      this.store.dispatch(
        jumpToDate({
          modifyFirstSelection:
            name.toLowerCase() === this.firstSelectionText.toLowerCase(),
        })
      );
      this.showCalendar();
    }

    if (target && target.type === 'text') {
      if (this.isCalendarOpen) {
        if (this.manualSelection)
          this.store.dispatch(
            setState({
              name: 'modifyFirstSelection',
              value:
                name.toLowerCase() === this.firstSelectionText.toLowerCase(),
            })
          );
      }
    }
  };
  /**
   * @private
   */
  changeTab = (e: Event) => {
    const target = e.target as any;

    const { selected } = target;
    this.store.dispatch(
      setState({
        name: 'modifyFirstSelection',
        value: selected.toLowerCase() === this.firstSelectionText.toLowerCase(),
      })
    );
    emit(this, 'adc-change-calendar-tab');
  };
  /**
   * @private
   */
  clearDatesHandler = () => {
    this.store.dispatch(clearDates());
    this.firstSelectionTextField = '';
    this.secondSelectionTextField = '';
    this.firstInvalidText = '';
    this.secondInvalidText = '';
    emit(this, 'adc-clear-dates');
  };
  /**
   * @private
   */
  inputBlurHandler = (e: Event, isFirstInput: boolean) => {
    const target = e.target as unknown as TextInput;

    if (e && target && target.type === 'text') {
      const { value } = target;
      if (value.trim() === '') {
        if (isFirstInput) {
          target.value = '';
          this.store.dispatch(setFirstSelectionOnly(''));
        } else {
          target.value = '';
          this.store.dispatch(setSecondSelectionOnly(''));
        }
        return;
      }

      const date = decipherDate(value, this.locale);

      if (!(date instanceof Date) || isNaN(date.getTime())) {
        target.setCustomValidity('Please check the date you entered');
        if (isFirstInput) {
          this.firstInvalidText = value;
          this.store.dispatch(setFirstSelectionOnly(''));
        } else {
          this.secondInvalidText = value;
          this.store.dispatch(setSecondSelectionOnly(''));
        }

        return;
      }

      const isoString = date.toISOString();

      if (isFirstInput) {
        if (this.firstSelection === isoString) {
          target.value = this.formatTextInputDate(isoString);
          return;
        }
      } else {
        if (this.secondSelection === isoString) {
          target.value = this.formatTextInputDate(isoString);
          return;
        }
      }

      if (
        !this.enablePastSelection &&
        isBefore(date, parseISO(this.currentDate))
      ) {
        target.setCustomValidity('Date must be after today');
        isFirstInput
          ? (this.firstInvalidText = value)
          : (this.secondInvalidText = value);
        isFirstInput
          ? this.store.dispatch(setFirstSelectionOnly(''))
          : this.store.dispatch(setSecondSelectionOnly(''));
        return;
      }
      if (
        !isFirstInput &&
        this.firstSelection &&
        isBefore(date, parseISO(this.firstSelection))
      ) {
        isFirstInput
          ? (this.firstInvalidText = value)
          : (this.secondInvalidText = value);
        target.setCustomValidity(
          `${
            this.secondSelectionText
          } date must be after the ${this.firstSelectionText.toLowerCase()} date`
        );
        isFirstInput
          ? this.store.dispatch(setFirstSelectionOnly(''))
          : this.store.dispatch(setSecondSelectionOnly(''));
        return;
      }
      if (
        isFirstInput &&
        this.secondSelection &&
        isBefore(parseISO(this.secondSelection), date)
      ) {
        isFirstInput
          ? (this.firstInvalidText = value)
          : (this.secondInvalidText = value);
        target.setCustomValidity(
          `${
            this.firstSelectionText
          } date must be before the ${this.secondSelectionText.toLowerCase()} date`
        );
        isFirstInput
          ? this.store.dispatch(setFirstSelectionOnly(''))
          : this.store.dispatch(setSecondSelectionOnly(''));
        return;
      }
      if (
        isBefore(startOfDay(date), startOfDay(parseISO(this.minDateString)))
      ) {
        isFirstInput
          ? (this.firstInvalidText = value)
          : (this.secondInvalidText = value);
        target.setCustomValidity(
          `${
            isFirstInput ? this.firstSelectionText : this.secondSelectionText
          } date must be after the minimum date`
        );
        isFirstInput
          ? this.store.dispatch(setFirstSelectionOnly(''))
          : this.store.dispatch(setSecondSelectionOnly(''));
        return;
      }
      const createMaxDaysOutDate = () => {
        if (this.maxDaysOut)
          return add(new Date(), { days: this.maxDaysOut }).toISOString();
        return '';
      };
      if (
        isAfter(
          startOfDay(date),
          startOfDay(parseISO(this.maxDateString) || createMaxDaysOutDate())
        )
      ) {
        isFirstInput
          ? (this.firstInvalidText = value)
          : (this.secondInvalidText = value);
        target.setCustomValidity(
          `${
            isFirstInput ? this.firstSelectionText : this.secondSelectionText
          } date must be before the maximum date`
        );
        isFirstInput
          ? this.store.dispatch(setFirstSelectionOnly(''))
          : this.store.dispatch(setSecondSelectionOnly(''));
        return;
      }

      if (isFirstInput) {
        this.firstInvalidText = '';
        this.store.dispatch(setFirstSelectionOnly(isoString));
      } else {
        this.secondInvalidText = '';
        this.store.dispatch(setSecondSelectionOnly(isoString));
      }
    }
  };
  /**
   * @private
   */
  textInputKeydown = (e: KeyboardEvent) => {
    const target = e.target as unknown as TextInput;

    setTimeout(() => {
      this.dropdown.initialize();
    }, 10);
    const { code } = e;
    const { name } = target;
    if (code === 'Enter') {
      this.inputBlurHandler(
        e,
        name.toLowerCase() === this.firstSelectionText.toLowerCase()
      );
    }
  };
  /**
   * @private
   */
  escapeKeyHandler = (e: KeyboardEvent) => {
    const { code } = e;
    if (code === 'Escape') {
      this.closeCalendar();
    }
  };

  render() {
    return html`
      <div
        id="calendar-anchor"
        class="grid grid-flow-col gap-24"
        @keydown=${this.escapeKeyHandler}
      >
        <adc-dialog
          id="dialog"
          variant=${this.mobileView ? 'fullscreen' : 'message'}
          ?no-close-button=${true}
          class="dialog-container"
          ?open=${false}
          @adc-request-close=${() => this.hideDialog()}
        >
          <div
            class="
        calendar
        grid
        gap-8
        "
          >
            ${!this.singleDaySelection
              ? html`
                  <adc-tabs
                    @change=${this.changeTab}
                    ?disabled="${false}"
                    ?underline=${true}
                    ?auto="${false}"
                    ?shouldAnimate="${false}"
                    selected=${this.modifyFirstSelection
                      ? this.firstSelectionText
                      : this.secondSelectionText}
                    class="min-w-[296px] ${classMap({
                      'pointer-events-none': !this.manualSelection,
                    })}"
                  >
                    <adc-tab
                      ?read-only=${!this.manualSelection &&
                      this.modifyFirstSelection}
                      sub-label=${this.firstSelection
                        ? this.formatDate(this.firstSelection)
                        : this.modifyFirstSelection
                        ? 'Select date'
                        : '--'}
                      value=${this.firstSelectionText}
                      icon-outlined
                    >
                      <label>${this.firstSelectionText}</label>
                    </adc-tab>
                    <adc-tab
                      ?read-only=${!this.manualSelection &&
                      !this.modifyFirstSelection}
                      sub-label=${this.secondSelection
                        ? this.formatDate(this.secondSelection)
                        : !this.modifyFirstSelection
                        ? 'Select date'
                        : '--'}
                      icon-outlined
                      label=${this.secondSelectionText}
                      value=${this.secondSelectionText}
                    >
                      <label>${this.secondSelectionText}</label>
                    </adc-tab>
                  </adc-tabs>
                `
              : undefined}

            <adc-calendar
              .store=${this.store}
              id="calendar"
              class="flex justify-center min-w-[296px]"
              locale=${this.locale}
              weekday-format=${this.weekdayFormat}
              min-date-string=${this.minDateString}
              max-date-string=${this.maxDateString}
              max-days-out=${this.maxDaysOut}
              ?show-current-year=${this.showCurrentYear}
              ?show-price=${this.showPrice}
              ?single-day-selection=${this.singleDaySelection}
              ?manual-selection=${this.manualSelection}
              ?enable-past-selection=${this.enablePastSelection}
            ></adc-calendar>
          </div>
          <div class="flex justify-between w-full mx-4" slot="footer">
            <adc-button kind="ghost" @click=${this.clearDatesHandler}
              >Clear dates</adc-button
            >
            <adc-button @click=${this.closeCalendar}>Done</adc-button>
          </div>
        </adc-dialog>

        ${this.inputKind === 'button'
          ? html`
              <adc-text-input
                ?disabled=${this.disabled}
                label-text=${this.firstSelectionText}
                name=${this.firstSelectionText}
                placeholder="mm/dd/yy"
                ?required=${this.required}
                ?live-validation=${true}
                @click=${this.handleInputClick}
                hide-clear-button
                leading-icon="operation:calendar-alt"
                type="button"
                value="${this.firstSelectionTextField
                  ? this.formatTextInputDate(this.firstSelectionTextField)
                  : 'Select date'}"
              >
              </adc-text-input>

              ${!this.singleDaySelection
                ? html`
                    <adc-text-input
                      ?disabled=${this.disabled}
                      label-text=${this.secondSelectionText}
                      name=${this.secondSelectionText}
                      placeholder="mm/dd/yy"
                      ?required=${this.required}
                      ?live-validation=${true}
                      @click=${this.handleInputClick}
                      hide-clear-button
                      leading-icon="operation:calendar-alt"
                      type="button"
                      value="${this.secondSelectionTextField
                        ? this.formatTextInputDate(
                            this.secondSelectionTextField
                          )
                        : 'Select date'}"
                    >
                    </adc-text-input>
                  `
                : undefined}
            `
          : html`
              <adc-text-input
                class="${classMap({
                  'modify-selection-highlight':
                    this.modifyFirstSelection &&
                    this.isCalendarOpen &&
                    !this.singleDaySelection &&
                    this.manualSelection,
                })}"
                ?disabled=${this.disabled}
                label-text=${this.firstSelectionText}
                name=${this.firstSelectionText}
                placeholder="mm/dd/yy"
                ?required=${this.required}
                ?live-validation=${false}
                @blur="${(e: Event) => this.inputBlurHandler(e, true)}"
                @click=${this.handleInputClick}
                @keydown=${this.textInputKeydown}
                hide-clear-button
                value="${this.firstInvalidText
                  ? this.firstInvalidText
                  : this.firstSelectionTextField
                  ? this.formatTextInputDate(this.firstSelectionTextField)
                  : ''}"
              >
                <adc-button-icon
                  name=${this.firstSelectionText}
                  @click=${this.handleInputClick}
                  slot="button-icon"
                  icon="operation:calendar-alt"
                  >${`open calendar ${this.firstSelectionText}`}</adc-button-icon
                >
              </adc-text-input>

              ${!this.singleDaySelection
                ? html`
                    <adc-text-input
                      class=" ${classMap({
                        'modify-selection-highlight':
                          !this.modifyFirstSelection &&
                          this.isCalendarOpen &&
                          !this.singleDaySelection &&
                          this.manualSelection,
                      })}"
                      ?disabled=${this.disabled}
                      label-text=${this.secondSelectionText}
                      name=${this.secondSelectionText}
                      placeholder="mm/dd/yy"
                      ?required=${this.required}
                      value="${this.secondInvalidText
                        ? this.secondInvalidText
                        : this.secondSelectionTextField
                        ? this.formatTextInputDate(
                            this.secondSelectionTextField
                          )
                        : ''}"
                      @blur="${(e: Event) => this.inputBlurHandler(e, false)}"
                      @click=${this.handleInputClick}
                      @keydown=${this.textInputKeydown}
                      hide-clear-button
                    >
                      <adc-button-icon
                        name=${this.secondSelectionText}
                        @click=${this.handleInputClick}
                        slot="button-icon"
                        icon="operation:calendar-alt"
                        >${`open calendar ${this.secondSelectionText}`}</adc-button-icon
                      >
                    </adc-text-input>
                  `
                : undefined}
            `}
      </div>

      <div
        @keydown=${this.escapeKeyHandler}
        id="calendarDropdown"
        class="
        calendar
        grid
        gap-[20px]
        bg-neutral-140
        py-24
        px-[20px]
        rounded-lg
        "
      >
        <adc-calendar
          .store=${this.store}
          class="flex justify-center min-w-[296px] w-[704px]"
          locale=${this.locale}
          weekday-format=${this.weekdayFormat}
          min-date-string=${this.minDateString}
          max-date-string=${this.maxDateString}
          max-days-out=${this.maxDaysOut}
          ?show-current-year=${this.showCurrentYear}
          ?show-price=${this.showPrice}
          ?single-day-selection=${this.singleDaySelection}
          ?manual-selection=${this.manualSelection}
          ?enable-past-selection=${this.enablePastSelection}
        ></adc-calendar>
        <div class="flex justify-between mx-4">
          <adc-button kind="ghost" @click=${this.clearDatesHandler}
            >Clear dates</adc-button
          >
          <adc-button @click=${this.closeCalendar}>Done</adc-button>
        </div>
      </div>
    `;
  }
}

try {
  customElements.define('adc-date-picker', DatePicker);
} catch (e) {
  // do nothing
}

declare global {
  interface HTMLElementTagNameMap {
    'adc-date-picker': DatePicker;
  }
}
