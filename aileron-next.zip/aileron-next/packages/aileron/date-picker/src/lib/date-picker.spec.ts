import '@aileron/dialog';
import '../index';
import { parseISO, isSameDay } from 'date-fns';
import {
  clearCalendar,
  jumpToDate,
  setFirstSelection,
  setSecondSelectionOnly,
  setState,
  setShowMultipleMonths,
  setFirstSelectionOnly,
} from './calendar.slice';
import { DatePicker } from './date-picker';
import { TextInput } from '@aileron/text-input';
import { ButtonIcon } from '@aileron/button-icon';
import { Dialog } from '@aileron/dialog';
import { Calendar } from './calendar.component';
import { Tab } from '@aileron/tabs';
import { CalendarNavigation } from './calendar-navigation.component';

// adc-date-picker tests
describe('<adc-date-picker>', () => {
  describe('when no properties are written', () => {
    let datePicker: DatePicker;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-date-picker locale="en-US">
      </adc-date-picker>
      `;
      datePicker = document.querySelector(
        'adc-date-picker'
      ) as DatePicker as DatePicker;
    });

    it('should be accessible', () => {
      document.body.innerHTML = `<h1>Custom element test</h1><adc-date-picker></adc-date-picker>`;
      expect(datePicker?.nodeType).toBe(1);
    });

    it('checks for correct default state ', () => {
      expect(datePicker.isCalendarOpen).toBe(false);
      expect(datePicker.kind).toMatch('dialog');
      expect(datePicker.weekdayFormat).toMatch('narrow');
      expect(datePicker.locale).toMatch('en-US');
      expect(datePicker.firstSelectionText).toMatch('Departure');
      expect(datePicker.secondSelectionText).toMatch('Arrival');
      expect(datePicker.showCurrentYear).toBe(false);
      expect(datePicker.disabled).toBe(false);
      expect(datePicker.required).toBe(false);
      expect(datePicker.showPrice).toBe(false);
      expect(datePicker.singleDaySelection).toBe(false);
      expect(datePicker.manualSelection).toBe(false);
      expect(datePicker.inputKind).toMatch('text');
      expect(datePicker.enablePastSelection).toBe(false);
      expect(datePicker.secondSelectionTextField).toMatch('');
      expect(datePicker.firstInvalidText).toMatch('');
    });

    it('changes the isCalendarOpen state', () => {
      expect(datePicker.isCalendarOpen).toBe(false);

      datePicker.setCalendarOpen(true);

      expect(datePicker.isCalendarOpen).toBe(true);

      datePicker.setCalendarOpen(false);

      expect(datePicker.isCalendarOpen).toBe(false);
    });

    describe('testing first text input', () => {
      it('types july 4 2100 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: 'july 4 2100', type: 'text' } };
        datePicker.locale = 'en-US';
        datePicker.requestUpdate();
        await datePicker.updateComplete;
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/2100');
      });
      it('types December 31 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: 'December 31', type: 'text' } };
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('12/31/');
      });
      it('types 12 31 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: '12 31', type: 'text' } };
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('12/31/');
      });

      it('types july 4 91 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: 'july 4 91', type: 'text' } };
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/2091');
      });

      it('types july 4 991 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: 'july 4 991', type: 'text' } };
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/');
      });

      it('types july 4 91 91 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: 'july 4 91 91', type: 'text' } };
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/2091');
      });

      it('types December and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelector(
          'adc-text-input'
        ) as TextInput;
        const e: any = { target: { value: 'december', type: 'text' } };
        datePicker.inputBlurHandler(e, true);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('12/1/');
      });
    });
    describe('testing second text input', () => {
      it('types july 4 2100 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: 'july 4 2100', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/2100');
      });
      it('types December 31 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: 'December 31', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('12/31/');
      });
      it('types 12 31 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: '12 31', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('12/31/');
      });

      it('types july 4 91 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: 'july 4 91', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/2091');
      });

      it('types july 4 991 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: 'july 4 991', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/');
      });

      it('types july 4 91 91 and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: 'july 4 91 91', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('7/4/2091');
      });

      it('types December and gets correct date', async () => {
        const textInput = datePicker.shadowRoot?.querySelectorAll(
          'adc-text-input'
        )[1] as TextInput;
        const e: any = { target: { value: 'december', type: 'text' } };
        datePicker.inputBlurHandler(e, false);
        await datePicker.updateComplete;
        expect(textInput.value).toMatch('12/1/');
      });
    });

    it('only shows two inputs', () => {
      const textInputs = datePicker.shadowRoot?.querySelectorAll(
        'adc-text-input'
      ) as unknown as TextInput[];
      expect(textInputs.length).toBe(2);
    });

    it('opens the dialog when clicking the calendar icon and closes when clicking outside', () => {
      expect(datePicker.dialog.open).toBe(false);
      (
        datePicker.shadowRoot?.querySelector('adc-button-icon') as ButtonIcon
      )?.click();
      expect(datePicker.dialog.open).toBe(true);
      const Dialog = datePicker.shadowRoot?.querySelector(
        'adc-dialog'
      ) as Dialog;
      (
        Dialog.shadowRoot?.querySelector('#dialogOverlay') as HTMLElement
      ).click();
      expect(datePicker.dialog.open).toBe(false);
    });

    it('adds correct classes to selected days', async () => {
      const calendar = datePicker.shadowRoot?.querySelector(
        'adc-calendar'
      ) as Calendar as Calendar;
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement> as unknown as Element[];

      expect(
        enabledDayButtons[0].classList.contains('active:bg-neutral-120')
      ).toBe(true);
      expect(
        enabledDayButtons[0].classList.contains('hover:bg-neutral-130')
      ).toBe(true);
      expect(enabledDayButtons[0].classList.contains('border-[#637E9C]')).toBe(
        true
      );
      expect(enabledDayButtons[0].classList.contains('border-solid')).toBe(
        true
      );
      expect(enabledDayButtons[0].classList.contains('border')).toBe(true);

      expect(
        enabledDayButtons[0].classList.contains('calendar__day--departure')
      ).toBe(false);
      expect(enabledDayButtons[0].classList.contains('bg-blue-060')).toBe(
        false
      );
      expect(enabledDayButtons[0].classList.contains('hover:bg-blue-070')).toBe(
        false
      );
      expect(
        enabledDayButtons[0].classList.contains('active:bg-blue-080')
      ).toBe(false);
      expect(enabledDayButtons[0].classList.contains('text-neutral-140')).toBe(
        false
      );

      expect(
        enabledDayButtons[0].classList.contains('calendar__day--arrival')
      ).toBe(false);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await datePicker.updateComplete;

      expect(
        enabledDayButtons[0].classList.contains('active:bg-neutral-120')
      ).toBe(false);
      expect(
        enabledDayButtons[0].classList.contains('hover:bg-neutral-130')
      ).toBe(false);
      expect(enabledDayButtons[0].classList.contains('border-[#637E9C]')).toBe(
        false
      );
      expect(enabledDayButtons[0].classList.contains('border-solid')).toBe(
        false
      );
      expect(enabledDayButtons[0].classList.contains('border')).toBe(false);

      expect(
        enabledDayButtons[0].classList.contains('calendar__day--departure')
      ).toBe(true);
      expect(enabledDayButtons[0].classList.contains('bg-blue-060')).toBe(true);
      expect(enabledDayButtons[0].classList.contains('hover:bg-blue-070')).toBe(
        true
      );
      expect(
        enabledDayButtons[0].classList.contains('active:bg-blue-080')
      ).toBe(true);
      expect(enabledDayButtons[0].classList.contains('text-neutral-140')).toBe(
        true
      );

      expect(
        enabledDayButtons[0].classList.contains('calendar__day--arrival')
      ).toBe(false);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await datePicker.updateComplete;

      expect(
        enabledDayButtons[0].classList.contains('active:bg-neutral-120')
      ).toBe(false);
      expect(
        enabledDayButtons[0].classList.contains('hover:bg-neutral-130')
      ).toBe(false);
      expect(enabledDayButtons[0].classList.contains('border-[#637E9C]')).toBe(
        false
      );
      expect(enabledDayButtons[0].classList.contains('border-solid')).toBe(
        false
      );
      expect(enabledDayButtons[0].classList.contains('border')).toBe(false);

      expect(
        enabledDayButtons[0].classList.contains('calendar__day--departure')
      ).toBe(true);
      expect(enabledDayButtons[0].classList.contains('bg-blue-060')).toBe(true);
      expect(enabledDayButtons[0].classList.contains('hover:bg-blue-070')).toBe(
        true
      );
      expect(
        enabledDayButtons[0].classList.contains('active:bg-blue-080')
      ).toBe(true);
      expect(enabledDayButtons[0].classList.contains('text-neutral-140')).toBe(
        true
      );

      expect(
        enabledDayButtons[0].classList.contains('calendar__day--arrival')
      ).toBe(true);
    });
  });

  describe('calendar with NON default values', () => {
    let datePicker: DatePicker;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-date-picker
      kind="dropdown"
      weekday-format="short"
      locale="fr-FR"
      first-selection-text="First Date"
      second-selection-text="Second Date"
      input-kind="button"
      first-pre-selection="2098-09-03T05:00:00.000Z"
      second-pre-selection="2098-09-09sT05:00:00.000Z"
      show-current-year
      disabled
      required
      show-price
      single-day-selection
      manual-selection
      enable-past-selection
      >
      </adc-date-picker>
      `;
      datePicker = document.querySelector(
        'adc-date-picker'
      ) as DatePicker as DatePicker;
    });

    it('checks for correct NON default state ', () => {
      expect(datePicker.isCalendarOpen).toBe(false);
      expect(datePicker.kind).toMatch('dropdown');
      expect(datePicker.weekdayFormat).toMatch('short');
      expect(datePicker.locale).toMatch('fr-FR');
      expect(datePicker.firstSelectionText).toMatch('First Date');
      expect(datePicker.secondSelectionText).toMatch('Second Date');
      expect(datePicker.showCurrentYear).toBe(true);
      expect(datePicker.disabled).toBe(true);
      expect(datePicker.required).toBe(true);
      expect(datePicker.showPrice).toBe(true);
      expect(datePicker.singleDaySelection).toBe(true);
      expect(datePicker.manualSelection).toBe(true);
      expect(datePicker.inputKind).toMatch('button');
      expect(datePicker.enablePastSelection).toBe(true);
      expect(datePicker.secondSelectionTextField).toMatch('');
      expect(datePicker.firstInvalidText).toMatch('');
    });
  });

  describe('calendar with single day selection', () => {
    let datePicker: DatePicker;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-date-picker
      single-day-selection
      >
      </adc-date-picker>
      `;
      datePicker = document.querySelector('adc-date-picker') as DatePicker;
    });
    it('only shows one input', () => {
      const textInputs = datePicker.shadowRoot?.querySelectorAll(
        'adc-text-input'
      ) as NodeListOf<TextInput>;
      expect(textInputs.length).toBe(1);
    });
  });

  describe('adc-date-picker with manual selection', () => {
    let datePicker: DatePicker;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-date-picker
      manual-selection=true
      >
      </adc-date-picker>
      `;
      datePicker = document.querySelector('adc-date-picker') as DatePicker;
    });

    it('should add class calendar__grid-range-enabled when first date is selected', async () => {
      const calendar = datePicker.shadowRoot?.querySelector(
        'adc-calendar'
      ) as Calendar;
      let calendarGrids = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) .calendar__grid'
      ) as NodeListOf<HTMLDivElement>;
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement> as NodeListOf<HTMLButtonElement>;

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-enabled')
      ).toBe(false);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      calendar.store.dispatch(
        setState({ name: 'modifyFirstSelection', value: false })
      );
      await calendar.updateComplete;
      calendarGrids = (await calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) .calendar__grid'
      )) as NodeListOf<HTMLDivElement>;

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-enabled')
      ).toBe(true);
      enabledDayButtons[1].click();
      await calendar.updateComplete;

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-enabled')
      ).toBe(false);
    });

    it('only selects firstSelection date on clicks', async () => {
      const calendar = datePicker.shadowRoot?.querySelector(
        'adc-calendar'
      ) as Calendar;
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement>;

      expect(calendar.firstSelection.length).toBe(0);
      expect(calendar.secondSelection.length).toBe(0);
      expect(datePicker.firstSelection.length).toBe(0);
      expect(datePicker.secondSelection.length).toBe(0);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await calendar.updateComplete;

      expect(calendar.firstSelection.length).toBeGreaterThan(0);
      expect(calendar.secondSelection.length).toBe(0);
      expect(datePicker.firstSelection.length).toBeGreaterThan(0);
      expect(datePicker.secondSelection.length).toBe(0);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await calendar.updateComplete;

      expect(calendar.firstSelection.length).toBeGreaterThan(0);
      expect(calendar.secondSelection.length).toBe(0);
      expect(datePicker.firstSelection.length).toBeGreaterThan(0);
      expect(datePicker.secondSelection.length).toBe(0);
    });

    it('only selects secondSelection date on clicks', async () => {
      const calendar = datePicker.shadowRoot?.querySelector(
        'adc-calendar'
      ) as Calendar;
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement>;

      calendar.store.dispatch(
        setState({ name: 'modifyFirstSelection', value: false })
      );
      await calendar.updateComplete;

      expect(calendar.firstSelection.length).toBe(0);
      expect(calendar.secondSelection.length).toBe(0);
      expect(datePicker.firstSelection.length).toBe(0);
      expect(datePicker.secondSelection.length).toBe(0);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await calendar.updateComplete;

      expect(calendar.firstSelection.length).toBe(0);
      expect(calendar.secondSelection.length).toBeGreaterThan(0);
      expect(datePicker.firstSelection.length).toBe(0);
      expect(datePicker.secondSelection.length).toBeGreaterThan(0);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await calendar.updateComplete;
      expect(calendar.firstSelection.length).toBe(0);
      expect(calendar.secondSelection.length).toBeGreaterThan(0);
      expect(datePicker.firstSelection.length).toBe(0);
      expect(datePicker.secondSelection.length).toBeGreaterThan(0);
    });

    it('toggles modifyFirstSelection on tab click', async () => {
      const tabs = datePicker.shadowRoot?.querySelectorAll(
        'adc-tab'
      ) as NodeListOf<Tab>;

      expect(datePicker.modifyFirstSelection).toBe(true);

      tabs[1].click();
      await datePicker.updateComplete;

      expect(datePicker.modifyFirstSelection).toBe(false);

      tabs[0].click();
      await datePicker.updateComplete;

      expect(datePicker.modifyFirstSelection).toBe(true);
    });
  });

  describe('adc-date-picker with manual selection', () => {
    let datePicker: DatePicker;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-date-picker
      manual-selection=true
      kind="dropdown"
      >
      </adc-date-picker>
      `;
      datePicker = document.querySelector('adc-date-picker') as DatePicker;
    });

    it.skip('opens the dropdown when clicking the calendar icon and closes when clicking outside', () => {
      expect(datePicker.dropdown.source.style.display).toMatch('none');
      (
        datePicker.shadowRoot?.querySelector('adc-button-icon') as ButtonIcon
      ).click();
      expect(datePicker.dropdown.source.style.display).toMatch('block');
      document.querySelector('body')?.click();
      expect(datePicker.dropdown.source.style.display).toMatch('none');
    });

    it.skip('toggles modifyFirstSelection on text input icon click', async () => {
      const textInputIcons = datePicker.shadowRoot?.querySelectorAll(
        'adc-button-icon[slot="button-icon"]'
      ) as NodeListOf<TextInput>;

      expect(datePicker.modifyFirstSelection).toBe(true);

      textInputIcons[1].click();
      await datePicker.updateComplete;

      expect(datePicker.modifyFirstSelection).toBe(false);

      textInputIcons[0].click();
      await datePicker.updateComplete;

      expect(datePicker.modifyFirstSelection).toBe(true);
    });

    it.skip('toggles modifyFirstSelection on text input click', async () => {
      const textInputs = datePicker.shadowRoot?.querySelectorAll(
        'adc-text-input'
      ) as NodeListOf<TextInput>;
      const textInputIcons = datePicker.shadowRoot?.querySelectorAll(
        'adc-button-icon[slot="button-icon"]'
      ) as NodeListOf<TextInput>;

      // Open the dropdown
      textInputIcons[0].click();

      expect(datePicker.modifyFirstSelection).toBe(true);

      textInputs[1].click();
      await datePicker.updateComplete;

      expect(datePicker.modifyFirstSelection).toBe(false);

      textInputs[0].click();
      await datePicker.updateComplete;

      expect(datePicker.modifyFirstSelection).toBe(true);
    });

    it.skip('does not change current calendar month view on text input ', async () => {
      const calendar = datePicker.shadowRoot?.querySelector(
        'adc-calendar'
      ) as Calendar;
      const textInputs = datePicker.shadowRoot?.querySelectorAll(
        'adc-text-input'
      ) as NodeListOf<TextInput>;
      const textInputIcons = datePicker.shadowRoot?.querySelectorAll(
        'adc-button-icon[slot="button-icon"]'
      ) as NodeListOf<TextInput>;
      const currentDate = new Date();
      const aheadThreeMonths = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 3,
        1
      );
      textInputIcons[0].click();

      const calendars = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible)'
      ) as NodeListOf<Calendar>;
      const initialValue = (
        calendars[1].querySelector('.calendar__month') as HTMLElement
      ).textContent;

      datePicker.store.dispatch(
        setSecondSelectionOnly(aheadThreeMonths.toISOString())
      );

      expect(
        (calendars[1].querySelector('.calendar__month') as HTMLElement)
          .textContent
      ).toMatch(initialValue as string);

      textInputs[1].click();
      await datePicker.updateComplete;

      expect(
        (calendars[1].querySelector('.calendar__month') as HTMLElement)
          .textContent
      ).toMatch(initialValue as string);
    });

    it.skip('changes current calendar month view on text input icon click ', async () => {
      const formatter = new Intl.DateTimeFormat('en-US', { month: 'long' });
      const calendar = datePicker.shadowRoot?.querySelector(
        'adc-calendar'
      ) as Calendar;
      const textInputIcons = datePicker.shadowRoot?.querySelectorAll(
        'adc-button-icon[slot="button-icon"]'
      ) as NodeListOf<TextInput>;
      const currentDate = new Date();
      const aheadThreeMonths = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 3,
        1
      );
      textInputIcons[0].click();

      const calendars = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible)'
      ) as NodeListOf<HTMLElement>;
      const initialValue = (
        calendars[1].querySelector('.calendar__month') as HTMLElement
      ).textContent;

      datePicker.store.dispatch(
        setSecondSelectionOnly(aheadThreeMonths.toISOString())
      );

      expect(
        (calendars[1].querySelector('.calendar__month') as HTMLElement)
          .textContent
      ).toMatch(initialValue as string);

      textInputIcons[1].click();
      await datePicker.updateComplete;

      expect(
        (calendars[1].querySelector('.calendar__month') as HTMLElement)
          .textContent
      ).toMatch(formatter.format(aheadThreeMonths));
    });
  });
});

// adc-calendar tests

describe('<adc-calendar>', () => {
  describe('when no properties are written', () => {
    let calendar: Calendar;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-calendar
      >
      </adc-calendar>
      `;
      calendar = document.querySelector('adc-calendar') as Calendar;
    });

    it('should be accessible', () => {
      document.body.innerHTML = `<h1>Custom element test</h1><adc-calendar></adc-calendar>`;
      expect(calendar?.nodeType).toBe(1);
    });

    it('should have the correct default values', () => {
      expect(calendar?.locale).toBe('en-US');
      expect(calendar?.weekdayFormat).toBe('narrow');
      expect(calendar?.showCurrentYear).toBe(false);
      expect(calendar?.showPrice).toBe(false);
      expect(calendar?.singleDaySelection).toBe(false);
      expect(calendar?.manualSelection).toBe(false);
      expect(calendar?.enablePastSelection).toBe(false);
      expect(calendar?.showMultipleMonths).toBe(true);
      expect(calendar?.modifyFirstSelection).toBe(true);
      expect(calendar?.month.length).toBe(4);
    });

    it('should have correct firstSelection state', () => {
      expect(calendar?.firstSelection).toBe('');
    });

    it('should create month name correctly', () => {
      const currentYear = new Date().getFullYear();
      const julyCurrentYear = new Date(currentYear, 6, 1);
      const julyNotCurrentYear = new Date(2011, 6, 1);
      expect(calendar?.createMonthName(julyCurrentYear.toISOString())).toBe(
        'July'
      );
      expect(calendar?.createMonthName(julyNotCurrentYear.toISOString())).toBe(
        'July 2011'
      );
    });

    it('should clear the calendar', () => {
      expect(calendar.month.length).toBe(4);
      calendar.store.dispatch(clearCalendar());
      expect(calendar.month.length).toBe(0);
    });

    it('should select dates correctly', async () => {
      const currentDate = new Date();
      const secondDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth(),
        currentDate.getDate() + 1
      );
      const thirdDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth(),
        currentDate.getDate() + 2
      );
      const fourthDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth(),
        currentDate.getDate() + 7
      );
      const dayButton = calendar.shadowRoot?.querySelector(
        'adc-button-icon.calendar__day:not(.calendar__day--disabled)'
      ) as ButtonIcon;
      const dayButtons = (await calendar.shadowRoot?.querySelectorAll(
        'adc-button-icon.calendar__day:not(.calendar__day--disabled)'
      )) as NodeListOf<ButtonIcon>;

      // First Date click ( sets firstSelection )
      expect(calendar?.modifyFirstSelection).toBe(true);
      dayButton.click();
      expect(calendar?.modifyFirstSelection).toBe(false);
      expect(isSameDay(parseISO(calendar.firstSelection), currentDate)).toBe(
        true
      );
      expect(calendar.secondSelection).toBe('');

      // Second Date click ( sets secondSelection )
      dayButtons[1].click();
      expect(isSameDay(parseISO(calendar.secondSelection), secondDate)).toBe(
        true
      );
      expect(calendar?.modifyFirstSelection).toBe(true);

      // Third date selection (should be resetting firstSelection, and clearing second selection)
      dayButtons[2].click();
      expect(isSameDay(parseISO(calendar.firstSelection), thirdDate)).toBe(
        true
      );
      expect(calendar.secondSelection).toBe('');
      expect(calendar?.modifyFirstSelection).toBe(false);
      dayButtons[7].click();
      expect(isSameDay(parseISO(calendar.secondSelection), fourthDate)).toBe(
        true
      );
      expect(calendar?.modifyFirstSelection).toBe(true);
    });

    it('should overwrite the firstSelection if it is before the current first selection date', async () => {
      const currentDate = new Date();
      const firstDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth(),
        currentDate.getDate() + 3
      );
      const secondDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth(),
        currentDate.getDate() + 2
      );
      const dayButtons = (await calendar.shadowRoot?.querySelectorAll(
        'adc-button-icon.calendar__day:not(.calendar__day--disabled)'
      )) as NodeListOf<ButtonIcon>;

      // First Date click ( sets firstSelection )
      expect(calendar?.modifyFirstSelection).toBe(true);
      dayButtons[3].click();
      await calendar.updateComplete;
      expect(calendar?.modifyFirstSelection).toBe(false);
      expect(isSameDay(parseISO(calendar.firstSelection), firstDate)).toBe(
        true
      );
      expect(calendar.secondSelection).toBe('');

      // Second Date click before first date selection ( sets firstSelection again )
      dayButtons[2].click();
      await calendar.updateComplete;
      expect(isSameDay(parseISO(calendar.firstSelection), secondDate)).toBe(
        true
      );
      expect(calendar.secondSelection).toBe('');
      expect(calendar?.modifyFirstSelection).toBe(false);
    });

    it('should have narrow weekday names', async () => {
      const weekday = await calendar.shadowRoot?.querySelector(
        '.calendar__weekday'
      );
      expect(weekday?.textContent).toMatch('S');
    });

    it('has disabled previous month button if on current month only', async () => {
      const currentDate = new Date();
      const nextMonthDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 1,
        1
      );

      await calendar.updateComplete;
      const navigation = calendar.shadowRoot?.querySelector(
        'adc-calendar-navigation'
      ) as CalendarNavigation;
      const prevMonthButton = navigation.shadowRoot?.querySelector(
        'adc-button-icon'
      ) as ButtonIcon;

      expect(prevMonthButton.hasAttribute('disabled')).toBe(true);

      calendar.store.dispatch(
        setFirstSelection({
          firstSelection: nextMonthDate.toISOString(),
          manualSelection: true,
        })
      );
      calendar.store.dispatch(jumpToDate({ modifyFirstSelection: true }));
      await calendar.updateComplete;

      expect(prevMonthButton.hasAttribute('disabled')).toBe(false);
    });

    it('should add and remove class calendar__grid-range-hover to only first calendar grid', () => {
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement>;
      const calendarGrids = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) .calendar__grid'
      ) as NodeListOf<HTMLDivElement>;
      const mockEvent: any = { target: enabledDayButtons[0] };
      calendar.handleGridRangeOver(mockEvent, 1);
      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-hover')
      ).toBe(true);
      expect(
        calendarGrids[1].classList.contains('calendar__grid-range-hover')
      ).toBe(false);

      calendar.handleGridRangeOut(mockEvent);

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-hover')
      ).toBe(false);
      expect(
        calendarGrids[1].classList.contains('calendar__grid-range-hover')
      ).toBe(false);
    });

    it('should add and remove class calendar__grid-range-hover to first and second calendar grid', () => {
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement>;
      const calendarGrids = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) .calendar__grid'
      ) as NodeListOf<HTMLDivElement>;
      const mockEvent: any = { target: enabledDayButtons[0] };
      calendar.handleGridRangeOver(mockEvent, 2);
      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-hover')
      ).toBe(true);
      expect(
        calendarGrids[1].classList.contains('calendar__grid-range-hover')
      ).toBe(true);

      calendar.handleGridRangeOut(mockEvent);

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-hover')
      ).toBe(false);
      expect(
        calendarGrids[1].classList.contains('calendar__grid-range-hover')
      ).toBe(false);
    });

    it('should add and remove class hovered-day to the day that is hovered over', () => {
      // Hovered over first calendar
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement>;
      // const calendarGrids = calendar.shadowRoot?.querySelectorAll('.calendar:not(.invisible) .calendar__grid')
      const mockEvent: any = { target: enabledDayButtons[0] };
      calendar.handleGridRangeOver(mockEvent, 2);
      expect(
        (enabledDayButtons[0].parentElement as HTMLElement).classList.contains(
          'hovered-day'
        )
      ).toBe(true);

      calendar.handleGridRangeOut(mockEvent);

      expect(
        (enabledDayButtons[0].parentElement as HTMLElement).classList.contains(
          'hovered-day'
        )
      ).toBe(false);
    });

    it('should add class calendar__grid-range-enabled when first date is selected', async () => {
      const calendarGrids = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) .calendar__grid'
      ) as NodeListOf<HTMLDivElement>;
      const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
      ) as NodeListOf<HTMLButtonElement>;

      expect(calendarGrids.length).toBe(2);

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-enabled')
      ).toBe(true);

      (enabledDayButtons[0] as HTMLButtonElement).click();
      await calendar.updateComplete;
      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-enabled')
      ).toBe(true);
      enabledDayButtons[1].click();
      await calendar.updateComplete;

      expect(
        calendarGrids[0].classList.contains('calendar__grid-range-enabled')
      ).toBe(false);
    });
  });

  describe('with properties written', () => {
    let calendar: Calendar;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-calendar
      weekday-format="short"
      show-current-year=true
      show-price=true
      single-day-selection=true
      manual-selection=true
      enable-past-selection=true
      >
      </adc-calendar>
      `;
      calendar = document.querySelector('adc-calendar') as Calendar;
    });

    it('should be accessible', () => {
      document.body.innerHTML = `<h1>Custom element test</h1><adc-calendar></adc-calendar>`;
      expect(calendar?.nodeType).toBe(1);
    });

    it('should have the correct default values', () => {
      expect(calendar?.locale).toBe('en-US');
      expect(calendar?.weekdayFormat).toBe('short');
      expect(calendar?.showCurrentYear).toBe(true);
      expect(calendar?.showPrice).toBe(true);
      expect(calendar?.singleDaySelection).toBe(true);
      expect(calendar?.manualSelection).toBe(true);
      expect(calendar?.enablePastSelection).toBe(true);
      expect(calendar?.modifyFirstSelection).toBe(true);
      expect(calendar?.month.length).toBe(4);
    });

    it('should create month name correctly w/ showCurrentYear=true', () => {
      const currentYear = new Date().getFullYear();
      const julyCurrentYear = new Date(currentYear, 6, 1);
      const julyNotCurrentYear = new Date(2011, 6, 1);
      expect(calendar?.createMonthName(julyCurrentYear.toISOString())).toBe(
        `July ${currentYear}`
      );
      expect(calendar?.createMonthName(julyNotCurrentYear.toISOString())).toBe(
        'July 2011'
      );
    });

    it('should should show price (alternate text) w/ showPrice=true', async () => {
      const dayButtons = (await calendar.shadowRoot?.querySelectorAll(
        '.calendar__day--wrapper .calendar__day--price'
      )) as NodeListOf<HTMLButtonElement>;

      expect(dayButtons[0].textContent).toMatch('$9,999');
    });

    it('should have short weekday names', async () => {
      const weekday = await calendar.shadowRoot?.querySelector(
        '.calendar__weekday'
      );
      expect(weekday?.textContent).toMatch('Sun');
    });

    it('has an enabled previous month button if on the current month w/ enablePastSelection set to true', () => {
      const navigation = calendar.shadowRoot?.querySelector(
        'adc-calendar-navigation'
      ) as CalendarNavigation;
      const prevMonthButton = navigation.shadowRoot?.querySelector(
        'adc-button-icon'
      ) as ButtonIcon;
      expect(prevMonthButton.hasAttribute('disabled')).toBe(false);
    });
  });

  describe('Using es-MX as locale', () => {
    let calendar: Calendar;

    beforeEach(() => {
      document.body.innerHTML = `
      <adc-calendar
      locale="es-MX"
      >
      </adc-calendar>
      `;
      calendar = document.querySelector('adc-calendar') as Calendar;
    });
    it('shows correct month name in spanish', () => {
      const currentDate = new Date();
      const monthName = currentDate.toLocaleString('es-MX', { month: 'long' });
      const month = (
        calendar.shadowRoot?.querySelector(
          '.calendar:not(.invisible)'
        ) as HTMLDivElement
      ).querySelector('.calendar__month') as HTMLDivElement;
      expect(month.textContent?.toLowerCase()).toMatch(monthName.toLowerCase());
    });
  });

  describe('Calendar w/ showMultipleMonths = true', () => {
    let calendar: Calendar;
    beforeEach(() => {
      document.body.innerHTML = `
      <adc-calendar
      show-mulitple-months="true"
      >
      </adc-calendar>
      `;
      calendar = document.querySelector('adc-calendar') as Calendar;
    });
    it('shows two visible months when showMultipleMonths set to true', () => {
      const visibleMonths = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible)'
      );
      expect(visibleMonths?.length).toBe(2);
    });
  });

  describe('Calendar w/ showMultipleMonths = false', () => {
    let calendar: Calendar;
    beforeEach(() => {
      document.body.innerHTML = `
      <adc-calendar
      showMulitpleMonths="false"
      >
      </adc-calendar>
      `;
      calendar = document.querySelector('adc-calendar') as Calendar;
    });
    it('shows one visible month when showMulitpleMonths set to false', async () => {
      calendar.showMultipleMonths = false;
      await calendar.updateComplete;
      const visibleMonths = calendar.shadowRoot?.querySelectorAll(
        '.calendar:not(.invisible)'
      );
      expect(visibleMonths?.length).toBe(1);
    });
  });
});

// calendar slice tests

describe('calendar.slice testing', () => {
  let datePicker: DatePicker;

  beforeEach(() => {
    document.body.innerHTML = `
    <adc-date-picker
    >
    </adc-date-picker>
    `;
    datePicker = document.querySelector('adc-date-picker') as DatePicker;
  });
  it('sets the state', () => {
    const initialValue = datePicker.firstSelection;
    const currentDate = new Date();

    datePicker.store.dispatch(
      setState({ name: 'firstSelection', value: currentDate.toISOString() })
    );
    datePicker.updateComplete;
    const newValue = datePicker.firstSelection;
    expect(initialValue).not.toMatch(newValue);
  });

  it('changes the showMulitpleMonths state', () => {
    // const initialValue = datePicker.showMultipleMonths;

    expect(datePicker.store.getState().calendar.showMultipleMonths).toBe(true);

    datePicker.store.dispatch(setShowMultipleMonths(false));

    expect(datePicker.store.getState().calendar.showMultipleMonths).toBe(false);
  });

  it('clears the month state', () => {
    expect(datePicker.store.getState().calendar.month.length).toBeGreaterThan(
      0
    );

    datePicker.store.dispatch(clearCalendar());

    expect(datePicker.store.getState().calendar.month.length).toBe(0);
  });
  it('sets the first selection only', () => {
    const currentDate = new Date();
    const futureDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + 3,
      1
    );

    expect(datePicker.store.getState().calendar.firstSelection.length).toBe(0);

    datePicker.store.dispatch(setFirstSelectionOnly(futureDate.toISOString()));

    expect(
      datePicker.store.getState().calendar.firstSelection.length
    ).toBeGreaterThan(0);
  });
  it('sets the second selection only', () => {
    const currentDate = new Date();
    const futureDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + 3,
      1
    );

    expect(datePicker.store.getState().calendar.secondSelection.length).toBe(0);

    datePicker.store.dispatch(setSecondSelectionOnly(futureDate.toISOString()));

    expect(
      datePicker.store.getState().calendar.secondSelection.length
    ).toBeGreaterThan(0);
  });

  it('should clear secondSelection when setting firstSelection on auto selection', () => {
    const currentDate = new Date();
    const futureDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth() + 3,
      1
    );

    datePicker.store.dispatch(
      setState({ name: 'firstSelection', value: currentDate.toISOString() })
    );
    datePicker.store.dispatch(
      setState({ name: 'secondSelection', value: futureDate.toISOString() })
    );

    expect(
      datePicker.store.getState().calendar.firstSelection.length
    ).toBeGreaterThan(0);
    expect(
      datePicker.store.getState().calendar.secondSelection.length
    ).toBeGreaterThan(0);

    datePicker.store.dispatch(
      setFirstSelection({
        firstSelection: currentDate.toISOString(),
        manualSelection: false,
      })
    );

    expect(
      datePicker.store.getState().calendar.firstSelection.length
    ).toBeGreaterThan(0);
    expect(datePicker.store.getState().calendar.secondSelection.length).toBe(0);
  });

  describe('adc-date-picker manual selection', () => {
    beforeEach(() => {
      document.body.innerHTML = `
      <adc-date-picker
      manual-selection
      >
      </adc-date-picker>
      `;
      datePicker = document.querySelector('adc-date-picker') as DatePicker;
    });

    it('should clear secondSelection when setting firstSelection after secondSelection w/ manual selection mode', () => {
      const currentDate = new Date();
      const futureDate = new Date(
        currentDate.getFullYear(),
        currentDate.getMonth() + 3,
        1
      );

      datePicker.store.dispatch(
        setState({ name: 'firstSelection', value: currentDate.toISOString() })
      );
      datePicker.store.dispatch(
        setState({ name: 'secondSelection', value: currentDate.toISOString() })
      );

      expect(
        datePicker.store.getState().calendar.firstSelection.length
      ).toBeGreaterThan(0);
      expect(
        datePicker.store.getState().calendar.secondSelection.length
      ).toBeGreaterThan(0);

      datePicker.store.dispatch(
        setFirstSelection({
          firstSelection: futureDate.toISOString(),
          manualSelection: true,
        })
      );

      expect(
        datePicker.store.getState().calendar.firstSelection.length
      ).toBeGreaterThan(0);
      expect(datePicker.store.getState().calendar.secondSelection.length).toBe(
        0
      );
    });
  });
});

// adc-calendar-navigation tests

describe('adc-calendar-navigation', () => {
  it('is accessible', async () => {
    document.body.innerHTML = `<adc-calendar-navigation></adc-calendar-navigation>`;
    const calendarNavigation = document.querySelector(
      'adc-calendar-navigation'
    ) as CalendarNavigation;
    expect(calendarNavigation?.nodeType).toBe(1);
  });

  it('has adc-button-inside', async () => {
    const calendarNavigation = document.querySelector(
      'adc-calendar-navigation'
    ) as CalendarNavigation;
    document.body.innerHTML = `
    <adc-calendar-navigation

    >
    </adc-calendar-navigation>
    `;
    const buttonIcon =
      calendarNavigation.shadowRoot?.querySelector('adc-button-icon');
    expect(buttonIcon).toBeDefined();
  });

  it('has correct default values', async () => {
    const calendarNavigation = document.querySelector(
      'adc-calendar-navigation'
    ) as CalendarNavigation;
    document.body.innerHTML = `
    <adc-calendar-navigation
    icon="navigation:chevron-right"

    >
    </adc-calendar-navigation>
    `;
    await calendarNavigation.updateComplete;
    const buttonIcon = calendarNavigation.shadowRoot?.querySelector(
      'adc-button-icon'
    ) as ButtonIcon;

    expect(calendarNavigation.disabled).toBe(false);

    expect(buttonIcon.size).toMatch('md');
    expect(buttonIcon).toHaveProperty('outlined');
    expect(buttonIcon.classList.contains('calendar__button')).toBe(true);
    expect(buttonIcon.type).toMatch('button');
    expect(buttonIcon.kind).toMatch('ghost');
    expect(buttonIcon.disabled).toBe(false);
  });

  it('adds correct icon property', async () => {
    const calendarNavigation = document.querySelector(
      'adc-calendar-navigation'
    ) as CalendarNavigation;
    document.body.innerHTML = `
    <adc-calendar-navigation
    icon="navigation:chevron-right"

    >
    </adc-calendar-navigation>
    `;
    await calendarNavigation.updateComplete;
    const buttonIcon = calendarNavigation.shadowRoot?.querySelector(
      'adc-button-icon'
    ) as ButtonIcon;
    expect(calendarNavigation.icon).toMatch('navigation:chevron-right');
    expect(buttonIcon.icon).toMatch('navigation:chevron-right');
  });

  it('adds correct label property', async () => {
    document.body.innerHTML = `
    <adc-calendar-navigation
    label-text="Next Month"

    >
    </adc-calendar-navigation>
    `;
    const calendarNavigation = document.querySelector(
      'adc-calendar-navigation'
    ) as CalendarNavigation;
    await calendarNavigation.updateComplete;
    expect(calendarNavigation.labelText).toMatch('Next Month');
  });

  it('emmits adc-click when clicked', async () => {
    const calendarNavigation = document.querySelector(
      'adc-calendar-navigation'
    ) as CalendarNavigation;
    document.body.innerHTML = `
    <adc-calendar-navigation
    icon="navigation:chevron-right"

    >
    </adc-calendar-navigation>
    `;
    await calendarNavigation.updateComplete;
    const buttonIcon = calendarNavigation.shadowRoot?.querySelector(
      'adc-button-icon'
    ) as ButtonIcon;
    const dispatchEventStub = vi.fn();
    calendarNavigation.dispatchEvent = dispatchEventStub;
    buttonIcon.click();

    await calendarNavigation?.updateComplete;

    expect(dispatchEventStub.mock.calls[0][0].type).toBe('adc-click');
  });
});

describe('min and max dates set', () => {
  let datePicker: DatePicker;
  let minDateString: string;
  let maxDateString: string;
  beforeEach(() => {
    const currentDate = new Date();
    const minDate = new Date(currentDate.getTime());
    minDate.setFullYear(2099);
    minDate.setMonth(6);
    minDate.setDate(5);
    minDateString = minDate.toISOString();
    const maxDate = new Date(currentDate.getTime());
    maxDate.setFullYear(2099);
    maxDate.setMonth(6);
    maxDate.setDate(11);
    maxDateString = maxDate.toISOString();

    document.body.innerHTML = `
    <adc-date-picker
    locale="en-US"
    min-date-string="${minDateString}"
    max-date-string="${maxDateString}"
    >
    </adc-date-picker>
    `;
    datePicker = document.querySelector('adc-date-picker') as DatePicker;
  });
  it('should set min and max dates', async () => {
    await datePicker.updateComplete;
    expect(datePicker.getAttribute('min-date-string')).toMatch(minDateString);
    expect(datePicker.getAttribute('max-date-string')).toMatch(maxDateString);
  });
  it('min dates prohibit wrong dates typed in', async () => {
    let validityMessage;
    const setCustomValidity = (string: string) => {
      validityMessage = string;
    };
    const e: any = {
      target: {
        value: 'july 4 2099',
        type: 'text',
        setCustomValidity: setCustomValidity,
      },
    };
    datePicker.inputBlurHandler(e, true);
    await datePicker.updateComplete;
    expect(validityMessage).toMatch(
      'Departure date must be after the minimum date'
    );
  });
  it('min dates allows correct dates typed in', async () => {
    const textInput = datePicker.shadowRoot?.querySelector(
      'adc-text-input'
    ) as TextInput;
    const e: any = {
      target: {
        value: 'july 8 2099',
        type: 'text',
        setCustomValidity: vi.fn(),
      },
    };
    datePicker.inputBlurHandler(e, true);
    await datePicker.updateComplete;
    expect(textInput.value).toMatch('7/8/2099');
  });
  it('max dates prohibit wrong dates typed in', async () => {
    let validityMessage;
    const setCustomValidity = (string: string) => {
      validityMessage = string;
    };
    const e: any = {
      target: {
        value: 'july 24 2099',
        type: 'text',
        setCustomValidity: setCustomValidity,
      },
    };
    datePicker.inputBlurHandler(e, true);
    await datePicker.updateComplete;
    expect(validityMessage).toMatch(
      'Departure date must be before the maximum date'
    );
  });
  it('max dates allows correct dates typed in', async () => {
    const textInput = datePicker.shadowRoot?.querySelector(
      'adc-text-input'
    ) as TextInput;
    const e: any = {
      target: {
        value: 'july 8 2099',
        type: 'text',
        setCustomValidity: vi.fn(),
      },
    };
    datePicker.inputBlurHandler(e, true);
    await datePicker.updateComplete;
    expect(textInput.value).toMatch('7/8/2099');
  });
  it('only has dates between min and max dates', async () => {
    const calendar = datePicker.shadowRoot?.querySelector(
      'adc-calendar'
    ) as Calendar;
    const e: any = {
      target: {
        value: 'july 8 2099',
        type: 'text',
        setCustomValidity: vi.fn(),
      },
    };
    datePicker.inputBlurHandler(e, true);
    calendar.store.dispatch(jumpToDate({ modifyFirstSelection: true }));
    await datePicker.updateComplete;
    const enabledDayButtons = calendar.shadowRoot?.querySelectorAll(
      '.calendar:not(.invisible) adc-button-icon:not(.calendar__day--disabled)'
    ) as NodeListOf<ButtonIcon>;
    expect(enabledDayButtons.length).toBe(7);
  });
});

// describe("calendar with custom firstSelectionText and secondSelectionText", () => {
//   it("Uses firstSelectionText on text input", () => {});
//   it("Uses firstSelectionText on tabs", () => {});
//   it("Uses secondSelectionText on text input", () => {});
//   it("Uses secondSelectionText on tabs", () => {});
// });
