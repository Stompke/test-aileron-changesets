import { DataTable } from './table.component';
import { DataTableRow } from './table-row.component';
import { DataTableHeaderRow } from './table-header-row.component';
import { DataTableHeaderExpandRow } from './table-header-expanded-row.component';
import { DataTableHeaderCell } from './table-header-cell.component';
import { DataTableHead } from './table-head.component';
import { DataTableExpandedRow } from './table-expanded-row.component';
import { DataTableExpandRow } from './table-expand-row.component';
import { DataTableCell } from './table-cell.component';
import { DataTableBody } from './table-body.component';

declare global {
  interface HTMLElementTagNameMap {
    'adc-table': DataTable;
    'adc-table-row': DataTableRow;
    'adc-table-header-row': DataTableHeaderRow;
    'adc-table-header-expand-row': DataTableHeaderExpandRow;
    'adc-table-header-cell': DataTableHeaderCell;
    'adc-table-head': DataTableHead;
    'adc-table-expanded-row': DataTableExpandedRow;
    'adc-table-expand-row': DataTableExpandRow;
    'adc-table-cell': DataTableCell;
    'adc-table-body': DataTableBody;
  }
}
