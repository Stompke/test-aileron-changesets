import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * DataTableExpandedRow
 * @element adc-table-expanded-row
 * @summary Expanded row container for the data table.
 * @slot Default - Content area for the table expanded row.
 */
export class DataTableExpandedRow extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  /**
   * Sets the width based on the number of columns.
   */
  @property({ type: Number, attribute: 'colspan' }) colSpan = 1;

  /**
   * Sets the state of visibility for the expanded row.
   */
  @property({ type: Boolean, reflect: true }) expanded = false;

  /**
   * Sets the highlighted state for the expanded row.
   */
  @property({ type: Boolean, reflect: true }) highlighted = false;

  render(): TemplateResult {
    const { colSpan } = this;
    return html`
      <td colspan="${colSpan}">
        <div class="adc-expanded-row__wrapper">
          <slot></slot>
        </div>
      </td>
    `;
  }
}

try {
  customElements.define('adc-table-expanded-row', DataTableExpandedRow);
} catch (e) {
  // do nothing
}
