import { Focusable } from '@aileron/shared/focusable';
import { html, LitElement } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';
import { Tailwind } from '@aileron/shared/tailwind-element';

const TailwindLitElement = Tailwind(LitElement);

/**
 * Data table header.
 * @element adc-table-head
 * @summary Header container for the data table.
 * @slot Default - Content area for the table header.
 */
export class DataTableHead extends Focusable {
  static styles = [TailwindLitElement.styles || [], styles];

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'rowgroup');
    }
    super.connectedCallback();
  }

  render(): TemplateResult {
    return html`<div class="font-sans font-bold text-base line-height-6">
      <slot></slot>
    </div>`;
  }
}

try {
  customElements.define('adc-table-head', DataTableHead);
} catch (e) {
  // do nothing
}
