import {
  DataTable,
  DataTableExpandRow,
  DataTableHeaderExpandRow,
} from '../index';
import '../index';

describe('<adc-table>', () => {
  let table: DataTable;
  let tableExpandRow: DataTableExpandRow;
  let tableExpandedRow: DataTableHeaderExpandRow;
  beforeEach(() => {
    document.body.innerHTML = `
    <adc-table>
      <adc-table-head>
        <adc-table-header-expand-row>
          <adc-table-header-cell>Heading</adc-table-header-cell>
          <adc-table-header-cell>Heading</adc-table-header-cell>
          <adc-table-header-cell>Heading</adc-table-header-cell>
          <adc-table-header-cell>Heading</adc-table-header-cell>
          <adc-table-header-cell>Heading</adc-table-header-cell>
          <adc-table-header-cell>Heading</adc-table-header-cell>
        </adc-table-header-expand-row>
      </adc-table-head>
      <adc-table-body>
        <adc-table-expand-row
          data-row-id="1"
        >
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
        </adc-table-expand-row>
        <adc-table-expanded-row colspan="7">
          <p>
            onsequat amet fugiat in officia sit cillum cupidatat fugiat incididunt reprehenderit
            minim deserunt voluptate mollit. Incididunt non aute pariatur laboris laborum est.
            Cillum adipisicing duis in deserunt anim sit id occaecat in et nisi. Magna sit nostrud
            officia ipsum reprehenderit consequat nulla officia eu ut incididunt. Qui non laboris
            esse sit consectetur nostrud velit labore eu ipsum nisi quis id eu. Fugiat do aute
            tempor labore et laborum deserunt aliquip. Nisi elit id exercitation veniam ex eu
            proident voluptate ipsum.
          </p>
        </adc-table-expanded-row>
        <adc-table-expand-row
          data-row-id="2"
        >
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
        </adc-table-expand-row>
        <adc-table-expanded-row colspan="7">
          <p>
            onsequat amet fugiat in officia sit cillum cupidatat fugiat incididunt reprehenderit
            minim deserunt voluptate mollit. Incididunt non aute pariatur laboris laborum est.
            Cillum adipisicing duis in deserunt anim sit id occaecat in et nisi. Magna sit nostrud
            officia ipsum reprehenderit consequat nulla officia eu ut incididunt. Qui non laboris
            esse sit consectetur nostrud velit labore eu ipsum nisi quis id eu. Fugiat do aute
            tempor labore et laborum deserunt aliquip. Nisi elit id exercitation veniam ex eu
            proident voluptate ipsum.
          </p>
        </adc-table-expanded-row>
        <adc-table-expand-row
          data-row-id="3"
        >
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
          <adc-table-cell>Cell Text</adc-table-cell>
        </adc-table-expand-row>
        <adc-table-expanded-row colspan="7">
          <p>
            onsequat amet fugiat in officia sit cillum cupidatat fugiat incididunt reprehenderit
            minim deserunt voluptate mollit. Incididunt non aute pariatur laboris laborum est.
            Cillum adipisicing duis in deserunt anim sit id occaecat in et nisi. Magna sit nostrud
            officia ipsum reprehenderit consequat nulla officia eu ut incididunt. Qui non laboris
            esse sit consectetur nostrud velit labore eu ipsum nisi quis id eu. Fugiat do aute
            tempor labore et laborum deserunt aliquip. Nisi elit id exercitation veniam ex eu
            proident voluptate ipsum.
          </p>
        </adc-table-expanded-row>
      </adc-table-body>
    </adc-table>`;
    table = document.querySelector('adc-table');
    tableExpandRow = document.querySelector('adc-table-expand-row');
    tableExpandedRow = document.querySelector('adc-table-expanded-row');
  });

  describe('when no properties are written', () => {
    it('should be accessible', () => {
      expect(table?.nodeType).toBe(1);
    });

    it('should have correct default values', () => {
      expect(tableExpandRow?.iconPosition).toBe('left');
      expect(tableExpandRow?.divider).toBe(false);
      expect(tableExpandRow?.expanded).toBe(false);
      expect(tableExpandedRow?.expanded).toBe(false);
      expect(table?.size).toBe('');
    });
    it('should render expandable icon on left side', async () => {
      const firstElement = tableExpandRow.shadowRoot?.firstElementChild;
      expect(
        firstElement?.classList.contains('adc-table-expand-button--wrapper')
      ).toBe(true);
    });
  });

  describe('when properties has been settled', () => {
    it('should render expandable icon on right side', async () => {
      tableExpandRow.iconPosition = 'right';
      tableExpandRow.requestUpdate();
      await tableExpandRow.updateComplete;
      const firstElement = tableExpandRow.shadowRoot?.firstElementChild;
      expect(firstElement?.className).not.toBe(
        'adc-table-expand-button--wrapper'
      );
    });
  });
  describe('methods', () => {
    it('should expand when click on expand button', async () => {
      tableExpandRow.expanded = false;
      const button = tableExpandRow.shadowRoot?.querySelector('button');
      button?.click();
      await tableExpandRow.updateComplete;
      expect(tableExpandRow.expanded).toBe(true);
    });

    it('should unexpand when click on expand button and it was already expanded', async () => {
      tableExpandRow.expanded = true;
      const button = tableExpandRow.shadowRoot?.querySelector('button');
      button?.click();
      await tableExpandRow.updateComplete;
      expect(tableExpandRow.expanded).toBe(false);
    });
  });
});
