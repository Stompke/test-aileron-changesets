import '@aileron/icon';
import { HostListener, HostListenerMixin } from '@aileron/shared/host-listener';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { ICON_POSITION } from './table';
import { DataTableRow } from './table-row';
import type { DataTableExpandedRow } from './table-expanded-row';
import type { TemplateResult, PropertyValues } from 'lit';

type IconPosition = (typeof ICON_POSITION)[keyof typeof ICON_POSITION];

/**
 * DataTableExpandRow
 * @element adc-table-expand-row
 * @summary Expandable row within a Data Table.
 * @slot Default - Content area for the table row.
 * @fires {CustomEvent<{ expanded: boolean }>} adc-table-row-expando-beingtoggled - The custom
 * event fired before the expanded state this row is being toggled upon a user gesture.
 * Cancellation of this event stops the user-initiated action of toggling the expanded state.
 * @fires {CustomEvent<{ expanded: boolean }>} adc-table-row-expando-toggled - The custom event
 * fired after the expanded state this row is toggled upon a user gesture.
 * @attr {"left"|"right"} [icon-position="left"] - The position of the icon in relationship to the table.
 * @attr {boolean} [divider=false] - `true` if the table row should have a divider.
 * @attr {boolean} [expanded=false] - `true` if the table row should be expanded.
 */
export class DataTableExpandRow extends HostListenerMixin(DataTableRow) {
  /**
   * Handles `click` event on the expando button.
   */
  private _handleClickExpando() {
    this._handleUserInitiatedToggleExpando();
  }

  /**
   * Handles `mouseover`/`mouseout` event handler on this element.
   * @param event The event.
   */
  @HostListener('mouseover')
  @HostListener('mouseout')
  // @ts-expect-error: The decorator refers to this method but TS thinks this method
  // is not referred to
  private _handleMouseOverOut(event: MouseEvent) {
    const { selectorExpandedRow } = this
      .constructor as typeof DataTableExpandRow;
    const { nextElementSibling } = this;
    if (nextElementSibling?.matches(selectorExpandedRow)) {
      (nextElementSibling as DataTableExpandedRow).highlighted =
        event.type === 'mouseover';
    }
  }

  /**
   * Handles user-initiated toggle request of the expando button in this table
   * row.
   * @param expanded The new expanded state.
   */
  private _handleUserInitiatedToggleExpando(expanded = !this.expanded) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      detail: {
        expanded,
      },
    };

    /**
     * @ignore
     */
    if (
      this.dispatchEvent(
        new CustomEvent(
          (
            this.constructor as typeof DataTableExpandRow
          ).eventBeforeExpandoToggle,
          init
        )
      )
    ) {
      this.expanded = expanded;
      /**
       * @ignore
       */
      this.dispatchEvent(
        new CustomEvent(
          (this.constructor as typeof DataTableExpandRow).eventExpandoToggle,
          init
        )
      );
    }
  }

  @property({ reflect: true, attribute: 'icon-position' })
  iconPosition: IconPosition = ICON_POSITION.LEFT;
  @property({ type: Boolean, reflect: true }) divider = false;
  @property({ type: Boolean, reflect: true }) expanded = false;

  _renderFirstCells(): TemplateResult {
    const { _handleClickExpando: handleClickExpando } = this;
    return html`
      ${this.iconPosition === ICON_POSITION.LEFT
        ? html`
            <div
              class="adc-table-expand-button--wrapper font-sans font-regular text-base line-height-6"
            >
              <button
                class="adc-table-expand--button"
                aria-label="row-expand-button"
                @click="${handleClickExpando}"
              >
                <adc-icon
                  icon="navigation:chevron-down"
                  part="expando-icon"
                  class="adc--table-expand__svg"
                ></adc-icon>
              </button>
            </div>
            <slot></slot>
            ${super._renderFirstCells()}
          `
        : html`
            <slot></slot>
            ${super._renderFirstCells()}
            <div
              class="adc-table-expand-button--wrapper font-sans font-regular text-base line-height-6"
            >
              <button
                class="adc-table-expand--button"
                aria-label="row-expand-button"
                @click="${handleClickExpando}"
              >
                <adc-icon
                  icon="navigation:chevron-down"
                  part="expando-icon"
                  class="adc--table-expand__svg"
                ></adc-icon>
              </button>
            </div>
          `}
    `;
  }

  updated(changedProperties: PropertyValues): void {
    if (changedProperties.has('expanded')) {
      const { selectorExpandedRow } = this
        .constructor as typeof DataTableExpandRow;
      const { expanded, nextElementSibling } = this;
      if (nextElementSibling?.matches(selectorExpandedRow)) {
        (nextElementSibling as DataTableExpandedRow).expanded = expanded;
      }
    }
  }

  /**
   * A selector that will return the corresponding expanded row.
   */
  static get selectorExpandedRow(): string {
    return 'adc-table-expanded-row';
  }

  /**
   * The name of the custom event fired before the expanded state this row is
   * being toggled upon a user gesture. Cancellation of this event stops the
   * user-initiated action of toggling the expanded state.
   */
  static get eventBeforeExpandoToggle(): string {
    return 'adc-table-row-expando-beingtoggled';
  }

  /**
   * The name of the custom event fired after the expanded state this row is
   * toggled upon a user gesture.
   */
  static get eventExpandoToggle(): string {
    return 'adc-table-row-expando-toggled';
  }
}

try {
  customElements.define('adc-table-expand-row', DataTableExpandRow);
} catch (error) {
  // do nothing
}
