import '@aileron/icon';
import { AileronElement } from '@aileron/shared/aileron-element';
import { FocusMixin } from '@aileron/shared/focus';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import {
  TABLE_SORT_CYCLE,
  TABLE_SORT_CYCLES,
  TABLE_SORT_DIRECTION,
} from './table';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';

type SortDirection =
  (typeof TABLE_SORT_DIRECTION)[keyof typeof TABLE_SORT_DIRECTION];
type SortCycle = (typeof TABLE_SORT_CYCLE)[keyof typeof TABLE_SORT_CYCLE];

/**
 * Data table header.
 * @element adc-table-header-cell
 * @summary Individual cell within a Data Table header. Styles the text and provides a sort button.
 * @slot Default - Text area for the table header cell.
 * @csspart sort-button Styles for the sorting button.
 * @csspart label-text Styles for the header text.
 * @fires {CustomEvent<{ oldSortDirection: SortDirection; sortDirection: SortDirection }>} adc-table-header-cell-sort -
 * The custom event fired before this header cell is sorted upon a user gesture. Cancellation of
 * this event stops the user-initiated sort.
 * @attr {'Ascending' | 'Descending' | 'None'} [sort-direction='ascending'] - Sort the rows by Ascending, Descending, or None.
 * @attr {boolean} [sort-active=false] - true if the table header cell is sorted.
 * @attr {"bi-states-from-ascending" | "bi-states-from-descending" | "tri-states-from-ascending" | "tri-states-from-descending"} [sort-cycle=undefined] -
 * Sets what kind of direction is able to be used.
 */
export class DataTableHeaderCell extends FocusMixin(AileronElement) {
  static styles = [AileronElement.styles || [], styles];

  /**
   * Handles `click` event on the sort button.
   * @param event The event.
   */
  private _handleClickSortButton() {
    const nextSortDirection = this._getNextSort();
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      detail: {
        oldSortDirection: this.sortDirection,
        sortDirection: nextSortDirection,
      },
    };
    const constructor = this.constructor as typeof DataTableHeaderCell;
    /**
     * @ignore
     */
    if (
      this.dispatchEvent(new CustomEvent(constructor.eventBeforeSort, init))
    ) {
      this.sortActive = true;
      this.sortDirection = nextSortDirection;
    }
  }

  /**
   * Handles `slotchange` event.
   * @param event The event.
   */
  private _handleSlotChange() {
    this.requestUpdate();
  }

  /**
   * @returns The next sort direction.
   */
  private _getNextSort() {
    const {
      sortCycle = TABLE_SORT_CYCLE.TRI_STATES_FROM_ASCENDING,
      sortDirection,
    } = this;
    if (!sortDirection) {
      throw new TypeError(
        'Table sort direction is not defined. ' +
          'Likely that `_getNextSort()` is called with non-sorted table column, which should not happen in regular condition.'
      );
    }
    const directions: any = (this.constructor as typeof DataTableHeaderCell)
      .TABLE_SORT_CYCLES[sortCycle];
    const index = directions.indexOf(sortDirection);
    if (index < 0) {
      if (sortDirection === TABLE_SORT_DIRECTION.NONE) {
        // If the current sort direction is `none` in bi-state sort cycle,
        // returns the first one in the cycle
        return directions[0];
      }
      throw new RangeError(
        `The given sort state (${sortDirection}) is not found in the given table sort cycle: ${sortCycle}`
      );
    }
    return directions[(index + 1) % directions.length];
  }

  @property({ type: Boolean, reflect: true, attribute: 'sort-active' })
  sortActive = false;
  @property({ reflect: true, attribute: 'sort-cycle' }) sortCycle?: SortCycle;
  @property({ reflect: true, attribute: 'sort-direction' })
  sortDirection: SortDirection = TABLE_SORT_DIRECTION.ASCENDING;

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'columnheader');
    }
    super.connectedCallback();
  }

  render(): TemplateResult {
    const { sortDirection } = this;
    if (sortDirection) {
      const sortIcon =
        sortDirection === TABLE_SORT_DIRECTION.NONE
          ? html` <adc-icon icon="small:sort"></adc-icon> `
          : html`
              <adc-icon
                icon="navigation:chevron-down"
                class="adc--table-sort__icon"
              ></adc-icon>
            `;
      return html`
        <button
          part="sort-button"
          class="adc--table-sort"
          title="${ifDefined(
            this.textContent === null ? undefined : this.textContent
          )}"
          @click=${this._handleClickSortButton}
        >
          <span part="label-text" class="adc--table-header-label"
            ><slot @slotchange=${this._handleSlotChange}></slot
          ></span>
          ${sortIcon}
        </button>
      `;
    }
    return html`<slot></slot>`;
  }

  /**
   * The name of the custom event fired before a new sort direction is set upon
   * a user gesture. Cancellation of this event stops the user-initiated change
   * in sort direction.
   */
  static get eventBeforeSort(): string {
    return 'adc-table-header-cell-sort';
  }

  /**
   * Mapping of table sort cycles to table sort states.
   */
  static TABLE_SORT_CYCLES = TABLE_SORT_CYCLES;
}

try {
  customElements.define('adc-table-header-cell', DataTableHeaderCell);
} catch (error) {
  // do nothing
}
