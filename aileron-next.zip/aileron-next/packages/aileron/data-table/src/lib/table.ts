import { AileronElement } from '@aileron/shared/aileron-element';
import { forEach } from '@aileron/utilities/foreach';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { PropertyValues, TemplateResult } from 'lit';

/**
 * @ignore
 */
export const ICON_POSITION = {
  LEFT: 'left',
  RIGHT: 'right',
} as const;

/**
 * @ignore
 */
export const TABLE_SIZE = {
  DEFAULT: '',
  SHORT: 'short',
  TALL: 'tall',
} as const;

/**
 * @ignore
 */
export const TABLE_SORT_DIRECTION = {
  NONE: 'none',
  ASCENDING: 'ascending',
  DESCENDING: 'descending',
} as const;

/**
 * @ignore
 */
export const TABLE_SORT_CYCLE = {
  BI_STATES_FROM_ASCENDING: 'bi-states-from-ascending',
  BI_STATES_FROM_DESCENDING: 'bi-states-from-descending',
  TRI_STATES_FROM_ASCENDING: 'tri-states-from-ascending',
  TRI_STATES_FROM_DESCENDING: 'tri-states-from-descending',
} as const;

/**
 * @ignore
 * Mapping of table sort cycles to table sort states.
 */
export const TABLE_SORT_CYCLES = {
  [TABLE_SORT_CYCLE.BI_STATES_FROM_ASCENDING]: [
    TABLE_SORT_DIRECTION.ASCENDING,
    TABLE_SORT_DIRECTION.DESCENDING,
  ],
  [TABLE_SORT_CYCLE.BI_STATES_FROM_DESCENDING]: [
    TABLE_SORT_DIRECTION.DESCENDING,
    TABLE_SORT_DIRECTION.ASCENDING,
  ],
  [TABLE_SORT_CYCLE.TRI_STATES_FROM_ASCENDING]: [
    TABLE_SORT_DIRECTION.NONE,
    TABLE_SORT_DIRECTION.ASCENDING,
    TABLE_SORT_DIRECTION.DESCENDING,
  ],
  [TABLE_SORT_CYCLE.TRI_STATES_FROM_DESCENDING]: [
    TABLE_SORT_DIRECTION.NONE,
    TABLE_SORT_DIRECTION.DESCENDING,
    TABLE_SORT_DIRECTION.ASCENDING,
  ],
} as const;

/**
 * Data table.
 * @element adc-table
 * @summary Table component for displaying tabular data.
 * @attr {'' | 'short' | 'long'} [size=''] - Determines the physical size for child row components.
 */
export class DataTable extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  @property({ reflect: true }) size = TABLE_SIZE.DEFAULT;

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'table');
    }
    super.connectedCallback();
  }

  updated(changedProperties: PropertyValues): void {
    if (changedProperties.has('size')) {
      // Propagate `size` attribute to descendants until `:host-context()` gets
      // supported in all major browsers
      forEach(
        this.querySelectorAll(
          (this.constructor as typeof DataTable).selectorRowsWithHeader
        ),
        (elem) => {
          elem.setAttribute('size', this.size);
        }
      );
    }
  }

  render(): TemplateResult {
    return html`<slot></slot>`;
  }

  static get selectorRowsWithHeader(): string {
    return 'adc-table-header-row,adc-table-row';
  }
}

try {
  customElements.define('adc-table', DataTable);
} catch (e) {
  // do nothing
}
