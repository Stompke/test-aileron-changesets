import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Data table body.
 * @element adc-table-body
 * @summary Body container for the data table.
 * @slot Default - Content area for the table body.
 */
export class DataTableBody extends AileronElement {
  static styles = [AileronElement.styles || [], styles];

  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'rowgroup');
    }
    super.connectedCallback();
  }

  render(): TemplateResult {
    return html`<slot></slot>`;
  }
}

try {
  customElements.define('adc-table-body', DataTableBody);
} catch (e) {
  // do nothing
}
