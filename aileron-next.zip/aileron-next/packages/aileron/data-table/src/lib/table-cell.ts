import { AileronElement } from '@aileron/shared/aileron-element';
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import styles from './styles.css?inline';
import type { TemplateResult } from 'lit';

/**
 * Data table cell.
 * @element adc-table-cell
 * @summary Table cell for displaying content in the data table.
 * @slot Default - Content area for the table cell.
 */
export class DataTableCell extends AileronElement {
  static styles = [AileronElement.styles || [], styles];
  connectedCallback(): void {
    if (!this.hasAttribute('role')) {
      this.setAttribute('role', 'cell');
    }
    super.connectedCallback();
  }

  /**
   * True if the table header / row should render a divider.
   */
  @property({ type: Boolean, reflect: true }) divider = false;

  render(): TemplateResult {
    return html`<div class="font-sans font-regular text-base line-height-6">
      <slot></slot>
    </div>`;
  }
}

try {
  customElements.define('adc-table-cell', DataTableCell);
} catch (e) {
  // do nothing
}
